# Changelog

Cross-package, user-facing release notes for Relaycast. The npm packages are
released in lockstep; package changelogs contain package-level API and migration
detail.

This project follows [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## Package changelogs

- [`@relaycast/engine`](packages/engine/CHANGELOG.md)
- [`@relaycast/sdk` (TypeScript)](packages/sdk-typescript/CHANGELOG.md)
- [`@relaycast/types`](packages/types/CHANGELOG.md)
- [`relaycast` (Rust SDK)](packages/sdk-rust/CHANGELOG.md)
- [Relaycast Swift SDK](packages/sdk-swift/CHANGELOG.md)

Packages without a separate changelog are covered by the cross-package notes below.

## [Unreleased]

## [8.16.0] - 2026-10-01

### Added

- Create, read, and update workspace metadata across the API and TypeScript, Python, Rust, and Swift SDKs, with shallow merging, null deletion, and size limits and rejection of secret-like keys.

### Fixed

- Python and Rust workspace reads accept public responses without private API-key hashes; Python workspace creation retries safely only when an idempotency key is supplied.

## [8.15.0] - 2026-10-01

### Added

- Server telemetry attributes each event to the cloud user behind the acting agent (`metadata.cloud_user_id`) and groups it by the workspace's cloud org and workspace; events with no known person use `relaycast-ws:<workspace_id>` without a person profile.

## [8.14.0] - 2026-09-30

### Added

- Opted-in node-provider action handlers receive the authenticated invoking agent identity in their handler context, with legacy strict providers retaining the prior wire shape.

## [8.13.1] - 2026-09-30

### Fixed

- Direct-node agents can publish a readable machine address from registration onward while legacy `@direct` addresses continue to deliver.

## [8.13.0] - 2026-09-25

### Added

- `POST /v1/dm` accepts `address` (`agent@machine`) in place of `to`, delivering to the agent only while it is hosted on that machine.
- Agents report their `address`, and received DMs carry the sender's as `message.agent_address`, so agents can reply by address.

## [8.12.0] - 2026-09-24

### Added

- The observer dashboard draws a relayflow run: a channel whose messages carry `metadata.relayflow` run snapshots shows the run's step graph, with each step's state and timing, pinned above the feed.

### Fixed

- Realtime `message.created` events carry the message's `metadata` on workspace and direct-node transports and preserve the server creation time, so structured messages render live without replayed events appearing newer than persisted messages.
- Relayflow observer panels order snapshots by their server-assigned snowflake IDs, render cyclic dependencies without inventing an execution sequence, and expose each step state as text instead of color alone.

## [8.11.7] - 2026-09-22

### Fixed

- Reconnecting brokers recover same-node legacy `default` workers without letting another provider or node claim their identities; adoption rechecks provider liveness and ignores future-dated default heartbeats.

## [8.11.6] - 2026-09-20

### Fixed

- Permanently releasing an agent now dead-letters its active `queued` and `delivered` deliveries immediately, restoring workspace messaging capacity instead of waiting for delivery TTL expiry.

## [8.11.5] - 2026-09-20

### Fixed

- GitHub PR inbound subscriptions follow title changes and receive associated comments and reviews without widening repository or PR scope.

## [8.11.4] - 2026-09-19

### Fixed

- A node that reconnects after its delivery socket dropped now receives every message queued during the outage. Reconnect replay for cursor-aware brokers was scoped to the sessions whose delivery readiness or node routing changed while re-announcing their inventory, so a host that already reported those sessions as delivery-ready replayed nothing: the queued messages stayed in the mailbox until their TTL and the agents were never woken. A heartbeat that refreshes the broker's capability roster between reconnect and re-announcement no longer changes how that reconnect replays.

## [8.11.3] - 2026-09-19

### Fixed

- Binding an agent to a node now adopts one of that node's live providers, marks the agent delivery-ready on cursor-aware providers, and guards against stealing an agent that is active on another live node. A broker-spawned agent that was HTTP-registered first (provider `default`) and then bound through the node-agents fallback kept a provider its node did not serve, so its deliveries were routed to the node but never pushed — the spawned agent was never woken. The bind's binding row, location move and node capacity counters now commit as one atomic unit, so a failure part-way through can no longer leave a node charged for a binding it retired, or holding an active binding it never reserved capacity for. The bind response also returns the agent's `delivery_ack_seq` so cursor-aware providers learn the adopted identity's authoritative delivery cursor.

## [8.11.2] - 2026-09-19

### Fixed

- Preserve server-owned cloud:* tags when a node re-registers

## [8.11.1] - 2026-09-17

- Agent realtime clients reuse their direct node token across reconnect attempts instead of minting a new one per attempt. Minting rotates the token through the workspace's shared write capacity, so a client that could not connect would generate write load with every retry and crowd out ordinary writes — including binding a newly spawned agent to its node.

## [8.11.0] - 2026-09-17

- Fix authenticated requests returning HTTP 429 `plan_limit_exceeded` permanently once a workspace passed its plan's API-call limit: the counter accumulated for the workspace's lifetime instead of resetting each billing period.
- Rate limit `GET /v1/workspace` in its own bucket so credential validation and launch preflight stay reachable while the workspace's other traffic is at its ceiling.
- Put a retry contract on every 429: `Retry-After` and `X-RateLimit-Reset` now distinguish a per-minute throttle that clears in seconds from a plan quota that only clears at the period boundary.
- Add opt-in durable task actions with execution fencing, final-result receipts, and restart reconciliation.
- Keep a node's enrollment-time `cloud:*` tags when its broker re-registers, and stop brokers from adding or removing them. `cloud:` is now a reserved node-tag namespace: `cloud:*` tags in `node.register` are ignored with a server-side warning, and re-enrolling is how to change or clear them.
- `GET /v1/inbox`: unread counts no longer include archived channels, and mentions are matched with the exact `@handle` token contract (escaped `\@x`, email addresses, and prefix/superstring text are not mentions); mention results are limited to live channels the agent has joined or DMs the agent participates in.

## [8.10.1] - 2026-09-13

- Fix deletion getting stuck for agents that never connected, while preserving protection for active agents.

## [8.10.0] - 2026-09-13

- Reject malformed or unsupported inbound webhook requests before admission; `message/send` and `message/stream` require a valid message.

- Enforce workspace delivery capacity across HTTP producers with retryable 429 responses.
- Expose the async workspace capacity resolver through public engine configuration.
- Admit outbound A2A messages durably before transport and recover accepted sends without losing local notifications.
- Send a stable HTTP Idempotency-Key on outbound retries and recovery.
- Bound outbound transport retries and refuse credentialed HTTP, redirects, and invalid JSON/protocol responses.
- Stop A2A recovery after source deletion or target registration/endpoint changes; clear terminal payloads.
- Deduplicate inbound A2A messages, counters, and local effects through concurrent retries and KV failures.
- Refuse new inbound A2A admission atomically when its authenticated registration or token changes.
- Preserve completed inbound A2A retries from published 8.9.1 without duplicate admission.
- Preserve numeric webhook IDs and the request message/response message-or-task fallback when an ID is omitted.
- Preserve authenticated sender rejection notices without duplicating them on replay.
- Keep completed DM/group-DM retries available during policy outages.
- Bound accepted A2A retries to 24 hours; source pruning returns 410 within the window without recreating history.
- Allow fresh inbound key reuse after SQL identity expiry, including a different payload, even when a stale completion cache remains.

## [8.9.1] - 2026-09-11

- Keep channel member-count queries within D1 parameter limits for large workspaces.

- Prevent recipient self-invitations from restoring a released subscription membership.

### Fixed

- Durable message replay preserves exact hyphenated mentions and webhook display names, and raw webhook deliveries use the same payload shape as live messages.
- Subscription joins cannot recreate membership for an agent released during the request.

## [8.9.0] - 2026-09-11

### Added

- Authenticated node registration replies identify the server admission contract so brokers can verify create-only provider binding, channel isolation, and guarded identity cleanup before spawning.

### Fixed

- Engine scheduled maintenance again supports host-owned retention cursors and bounded websocket backlog redrive, allowing hosted deployments to retain schema-free recovery behavior.
- `GET /v1/nodes` no longer fetches a workspace's entire node history to serve a default listing: `name`, `capability`, and a new `status` liveness selector are now pushed into SQL, and `status=online` returns only fresh-heartbeat live nodes. An explicit `history=true` mode adds bounded, non-truncating cursor pagination for reading full history (e.g. `--all`). `active_agents` is now flagged with `active_agents_stale` once a node is offline, so a frozen historical count is never presented as current occupancy. (Fixes [#422](https://github.com/AgentWorkforce/relaycast/issues/422))
- Keyed agent session events now survive lost responses without duplicate events, while conflicting key reuse returns a typed error. A `status.*` event's status mutation and durable completion marker are applied atomically so retries cannot leave a stale agent row behind a successful response.
- Migration `0056_session_event_status_completion.sql` reconciles pre-existing keyed status events without fabricating completion, recovering only rows proven older than the event and conservatively preserving rows touched by later status or liveness writers.

## [8.8.0] - 2026-09-10

### Changed

- Anonymous keyed workspace creation now treats a CSPRNG `Idempotency-Key` as the hosted-safe recovery capability; the deployment derivation secret remains server-only, while self-hosts can opt into shared-secret proof enforcement.

### Added

- Add workspace-admin bulk reclamation for stale, unowned agent identities, with default dry-run reports, resumable pages, a configurable CLI `--limit` of 1–100 rows, and protection for broker associations and retained authorship.

- Rust SDK `WorkspaceBootstrapOptions` supports crash-safe anonymous keyed workspace creation without a deployment secret and opt-in self-host bootstrap proof without exposing it to hosted Relaycast.
- `POST /v1/agents/release-exact` atomically pins broker cleanup to an immutable agent identity and durable idempotency key, so a same-name replacement cannot be released by a retry.

### Fixed

- NPM release reconciliation now waits for all package dist-tags within one bounded propagation window and preserves unrelated Docker lockfile resolutions.

- Rust and TypeScript SDK anonymous keyed workspace bootstrap refuses remote HTTP and redirects, keeping its recovery capability on the intended origin.

## [8.7.0] - 2026-09-09

### Added

- Node credentials can read their own dispatched spawn results, allowing served fleet actions to confirm broker readiness with node-scoped authority.

- Agent registration accepts `auto_join_general: false` on HTTP and node control for isolated workers; recovery preserves existing memberships.

- Node-control `agent.deregister` acknowledges requests with an ID after teardown, allowing brokers to confirm cleanup before deleting owned identities.
- `POST /v1/agents/{name}/subscription-channel` provisions an exact identity-bound delivery channel without rotating recipient credentials.

### Fixed

- Thread replies resolve full hyphenated mentions; subscription setup rejects recipients released during membership creation.
- Verified spawn checks the selected provider heartbeat, and inventory reconciliation honors only canonical `verify_ready` input. Empty explicit targets retain legacy spawn routing.

- Relayfile messages expose provider payloads from Cloud sync envelopes, preserving titles, authors, and terminal PR state for subscribers.

- Subscription routes reject conflicting legacy memberships; agent removal invalidates channels actually removed by the release transaction.

- Agent deletion invalidates cached membership so subscription route checks reflect the released identity.
- Relayfile ingress preserves authenticated provider event semantics and resource references.
- Hyphenated mentions resolve the full handle without waking a prefix agent.
- Raw inbound webhooks now create durable agent deliveries.
- Relayfile ingress and raw inbound hooks reject full mailboxes atomically with retry guidance, preserving unique events without partial delivery.
- Explicit spawn targets are honored when a legacy global node alias exists, preserving its caller allowlist.

## [8.6.1] - 2026-09-09

### Fixed

- NPM releases now preserve every stable and prerelease engine migration byte-for-byte, including the canonical `0045_workspace_create_idempotency.sql` artifact.

## [8.6.0] - 2026-09-09

### Added

- Anonymous bootstrap `POST /v1/workspaces` creates can use an `Idempotency-Key` to recover the same workspace and API key after retries or response loss; digest conflicts, owner-scope crossovers, and terminalized bindings fail closed. The caller must also present `X-Workspace-Bootstrap-Secret` matching the deployment's configured secret — the `Idempotency-Key` is a non-secret correlator, so proving the deployment secret is what authorizes recovering the binding and prevents an unrelated caller who guesses or observes the key from retrieving another caller's workspace credentials. Callers must generate anonymous keys with a CSPRNG; the server enforces only a 32-character structural minimum and rejects shorter keys with `400 workspace_create_idempotency_key_too_weak`.
- Keyed anonymous bootstrap now rejects explicit invalid authorization and requires a stable deployment secret across restarts; unkeyed creates remain compatible.

### Fixed

- Self-hosted Docker and Compose deployments now pass `RELAYCAST_WORKSPACE_BOOTSTRAP_SECRET` into the engine without logging it.

## [8.5.5] - 2026-09-08

### Fixed

- Serialize overlapping reconnect replays and honor acknowledgements and provider handoffs before each send.
- Agent roster reads skip released history and seek live status ranges through a workspace-scoped index.
- Prevent node removal from scanning unrelated retained deliveries and agent records across workspaces.

## [8.5.4] - 2026-09-08

### Fixed

- Maintenance migrations reuse obsolete index space before creating replacements, reducing upgrade storage pressure without deleting history or changing retention.

## [8.5.3] - 2026-09-08

### Fixed

- Fleet delivery replay uses indexed mailbox pages; bounded, resumable retention and lower background dispatch concurrency reduce database pressure without shortening retention policies.
- Replay completion cannot lose a trailing trigger; maintenance recovers corrupt cursors and advances past expired-only redrive windows without scanning unrelated routes.

## [8.5.2] - 2026-09-07

### Fixed

- Batched workspace-event appends allocate sequences with bounded index lookups, avoiding scans of retained event history that can overload busy databases.

## [8.5.1] - 2026-09-07

### Added

- Node operators can delete one workspace-scoped node through `DELETE /v1/nodes/:name` or `relay.nodes.delete()`, with safe online/action guards, an explicit force option, and no automatic replay of ambiguous SDK failures.

### Fixed

- Agent roster status filters now load only matching rows from the database while preserving read-only, TTL-derived presence.

## [8.5.0] - 2026-09-06

### Fixed

- Guarded agent releases now compare the exact issued-token generation before dispatch and completion, so stale cleanup cannot release a same-name takeover.
- Fleet registration now acquires capacity before durable agent writes while preserving `agent_already_exists` precedence, binds cancellation and reservation claims to the exact node/provider/name tuple, and requires invocation correlation when a stale canceled worker is otherwise indistinguishable from its replacement.
- Native spawn rejects a missing or empty agent name before creating an invocation or reserving node capacity.
- Registered agent- and node-action dispatch now atomically persists the exact action, route, and accepted attempt at the socket owner; retries cannot duplicate execution, stale send failures cannot clobber a newer winner, and pruning or timeout recovery cannot retarget or revoke accepted work across same-name replacements.

## [8.4.0] - 2026-09-05

### Added

- Delegated `POST /v1/workspaces` creates now accept an owner-scoped `Idempotency-Key`, recover the same child key after response loss, reject request-digest conflicts, and terminalize bindings on deletion or expiry.

### Fixed

- Keyed (idempotent) agent-action invocations whose host cannot deliver to the handler now fail with 503 `handler_unavailable` instead of 503 `idempotency_unavailable`.
- An agent-action invocation is no longer reported as `handler_unavailable` when its handler reconnected and received it mid-request; the caller sees the live dispatch instead.

## [8.3.1] - 2026-09-03

### Added

- `POST /v1/nodes` accepts `machine_id` and uses it as the enrollment key of last resort, after `node_id` and `name`. A fleet host that persists no `node_id` renames itself on every boot, and each boot used to leave another roster row behind; it now rotates the machine's existing `broker` node instead. `direct` node-of-one delivery hosts are never matched this way, and reuse requires the matched broker to have proved it was alive — by an actual heartbeat frame, tracked in a new `proven_live_at` column, since `last_heartbeat_at` is also written by registration and disconnect cleanup. That proof is cleared whenever enrollment re-issues a row's token, so a row cannot be taken twice before its new holder proves itself. Rows that never heartbeated, rows still live, and rows with a future proof are all left alone, so hosts cold-booting from a shared baked `machine_id` keep separate identities and credentials. An explicit `node_id` still pins identity. Hosts that enroll or register but never heartbeat are not deduped; those rows are reclaimed by the roster reaper. Node roster entries now return `machine_id`.

### Fixed

- Unkeyed agent-action invocations now report `handler_unavailable` and fail their durable row when the owner-side provider send misses, while still acknowledging work that completes between provider acceptance and dispatch bookkeeping.

## [8.3.0] - 2026-09-02

### Added

- `@relaycast/types` declares which node frame carries each event type (`NODE_DELIVER_FRAME_EVENT_TYPES`, `nodeFrameKindFor`), so hosts can tell `deliver`-frame events from `context.update` events without copying the engine's list.

## [8.2.2] - 2026-09-02

### Fixed

- Fleet inventory reconciliation isolates stale or conflicting members, so one bad identity can no longer expire every healthy sibling on the same node and strand their inbound deliveries. A member whose own entry is rejected stays online: it is excluded from renewal and delivery readiness, but the missing-agent sweep no longer mistakes it for a departed agent and emits a false `agent.exited`.
- Never-dispatched pending action invocations are now bounded by absolute age (default 72h), so stale spawn queues can no longer drain into live agents that evict an existing resident under the same name.
- Retried action invocations reuse the original invocation instead of executing a provider action twice, wait for a durable dispatch outcome, and preserve locally completed release routing identity.

## [8.2.1] - 2026-08-24

### Fixed

- Fleet heartbeats and agent reads no longer amplify into workspace-wide D1 maintenance scans; pending delivery views also exclude expired rows before cleanup runs.

## [8.2.0] - 2026-08-21

### Added

- Workspace creation records provenance and explicit internal/external/unknown classification for hosted per-workspace usage reporting without adding message-path writes.

### Security

- Observer tokens receive workspace provenance without request actor, user, machine, or organization identity fields.

## [8.1.3] - 2026-08-20

### Fixed

- Fleet reconnect drains and activity-feed reads no longer perform repeated full-table D1 scans as invocation and DM history grows.

## [8.1.2] - 2026-08-19

### Fixed

- The activity feed now uses the indexed monotonic message order instead of scanning and sorting an entire workspace history.

## [8.1.1] - 2026-08-19

### Fixed

- Scheduled delivery expiry now drains up to 2,500 rows per invocation in bounded D1-safe batches, preventing expired mailbox rows from accumulating faster than the sweep can clear them.

## [8.1.0] - 2026-08-19

### Added

- Fleet nodes can advertise placement-safe `owner/name` repository keys without exposing local checkout paths.

### Security

- A node can no longer smuggle a repository advertisement through its `tags` list. When `node.register` carries `repo_keys` — including as an empty array — that field is the only source of the `repo:<owner/name>` tags placement matches on, and any `repo:` tag supplied in `tags` is dropped. Register messages that omit `repo_keys` stay on the pre-`repo_keys` tag-only path.

## [8.0.7] - 2026-08-19

### Added

- Replay clients can resolve indexed `session_ref` message slices with a live per-workspace retention boundary and fail-closed retained, partial, aged-out, or unknown availability.

### Fixed

- Channel, thread, and group-DM clients now forward replay metadata, and group-DM redelivery preserves it across broker reconnects.

## [8.0.6] - 2026-08-18

### Added

- Workspaces can opt into an explicit expiry at creation or be deleted immediately with their own key, including durable event rows and retryable post-commit cleanup of stored file bytes.

## [8.0.5] - 2026-08-18

### Fixed

- Workspace creation now requires atomic storage for the workspace and default
  channel, and exhausted storage failures no longer expose database internals.

## [8.0.4] - 2026-08-17

### Fixed

- Keep prior agent token authenticatable during rotate-token grace

## [8.0.3] - 2026-08-15

### Fixed

- Removing an agent that has authored messages now succeeds. The agent row is
  retained so its messages keep their author, while the name is freed for reuse
  and the old credential stops authenticating.
- A removed or released agent is no longer a delivery target: its channel and
  direct-message memberships are cleared with it.
- A released agent can no longer be revived to `active` by a late heartbeat, and
  id-scoped updates no longer resolve to a released row.

## [8.0.2] - 2026-08-15

### Fixed

- Tombstone on node-completed release instead of deleting

## [8.0.1] - 2026-08-14

### Changed

- The self-host container now installs `@relaycast/engine` 8.0.0, matching the hosted deployment, and its runbook documents agent-card discovery as working on the standard well-known path rather than as a known defect.

### Fixed

- DM conversation and inbox reads remain available beyond 100 conversations, and the advertised DM-list limit now reaches the server instead of being ignored.

### Security

- Legacy agent identity claims are atomic, and generic agent updates cannot write the reserved `identity_key` metadata field.

## [8.0.0] - 2026-08-10

### Added

- Added a pinned, multi-architecture self-host container and Compose runbook with persistent SQLite/files state, health checks, and mandatory HTTPS deployment-authority validation.
- A2A federation now preserves structured DM metadata end to end, defines a versioned `com.agentrelay.ratify` carrier for proof bundles and signed revocation lists, and supports reciprocal authenticated delivery between registered peers.

### Fixed

- A2A counterparties can discover a self-hosted deployment at the standard `GET /.well-known/agent-card.json`, and `/:workspace/.well-known/agent-card.json` now resolves. Deployments holding more than one workspace still require a selector.

## [7.0.0] - 2026-08-07

### Fixed

- Fleet node rosters now return `load: null` until a direct node, or every constituent provider of a broker node, explicitly reports a genuine normalized capacity-utilization measurement.
- Fleet capacity now treats `max_agents: 0` consistently as unlimited.

## [6.3.2] - 2026-08-02

### Fixed

- 1:1 DM resolution now atomically reserves each deterministic conversation ID for its workspace and participant pair. A collision returns `409 dm_conversation_id_collision` instead of silently aliasing another conversation.

## [6.3.1] - 2026-07-31

### Fixed

- Sending into a 1:1 DM whose participant is marked as departed now restores that participant, instead of resolving the conversation while its roster still shows the departure.

## [6.3.0] - 2026-07-28

### Added

- Callers can attribute requests to a machine, user, and organization via `X-Agent-Relay-Machine-Id` / `-User-Id` / `-Org-Id` / `-Org-Slug` headers (or `agent_relay_*` query params on WebSocket upgrades), so hosted usage is reported per person and per customer rather than only per workspace. Analytics only — never affects authorization. See the README's Telemetry Attribution section.

### Fixed

- Corrected the canonical `deliver` wire fixture in `@relaycast/types` to the `{type, data}` payload the engine actually emits, so SDK authors are not coding against a stale flat shape.
- SDK telemetry identity now reaches WebSocket connections, both the workspace observer stream and agent sockets. `ws_session_started` was previously anonymous for identified callers.

## [6.2.0] - 2026-07-17

### Added

- Durable `agent.exited` event when a node-hosted agent leaves (deregister, missing from an inventory sync, or release), carrying `agent_id`, `agent_name`, `node_id`, the spawn `invocation_id`, and a `reason`; the spawn's caller is notified directly.
- Durable `node.status.online` / `node.status.offline` events on node liveness transitions (offline carries a `reason` like `liveness_timeout`). Wildcard webhook subscriptions (`events: ["*"]`) receive all three new events automatically.
- `POST /v1/agents/disconnect` accepts an optional `deregister` flag; SDK `disconnect()` and `presence.markOffline()` take `{ deregister?: boolean }` to opt into full node teardown.

### Changed

- Agent disconnect is presence-only by default for node-hosted agents: the node binding is kept so a still-running session keeps receiving deliveries, instead of silently re-homing to an offline direct node.

### Fixed

- Node enrollment (`POST /v1/nodes`) now keys on `node_id` when supplied: re-enrolling rotates (and can rename) the same node in place, and a name held by a different node is rejected with `node_name_conflict` (409) instead of silently rewriting the other node.
- Stopped a same-connection node broker `node.register` re-register from silently gating deliveries: already-announced agents keep their delivery readiness, and readiness-gated skips stamp the delivery row with observable retry metadata instead of failing silently.
- Recovered WebSocket node messages whose single live dispatch was lost or failed: instead of letting rows sit queued until the mailbox TTL dead-letters them, the periodic delivery sweep now redrives queued ws-node rows (not just `http_push`), replaying each agent's backlog in ascending order so a later message never outruns an earlier one.
- `POST /v1/actions` now treats re-registering an existing action name as an idempotent refresh (200) of its description, handler, schemas, `available_to`, and `is_active` instead of failing with a 500 unique-constraint error.
- Invoking an agent-handled action whose handler has no live connection fails fast with `handler_unavailable` (503), and invocations whose handler stays continuously unreachable past a bounded TTL are failed with an `action.failed` event instead of staying `pending` forever (a brief handler restart never kills an in-flight invocation).
- The TypeScript SDK no longer rewrites keys inside user-authored JSON: action `input_schema`/`output_schema`, invocation `input`/`output`, and `headers` maps now cross the wire verbatim in both directions.

## [6.1.0] - 2026-07-16

### Added

- Message retention remains opt-in (history is kept forever by default); self-host deployments can now opt in to a deployment-wide message TTL via `RELAYCAST_MESSAGE_TTL_DAYS`.

### Fixed

- Messages posted through an inbound webhook now fire channel message triggers, with the webhook's caller name preserved on the resulting action invocation.
- Allowed Swift clients to decode hosted agent lifecycle statuses and complete realtime connections.

## [6.0.5] - 2026-07-13

### Added

- Exported the provider-attach arbitration policy (`providerAttachDecision`, `PROVIDER_ATTACH_LIVENESS_MS`) from `@relaycast/engine/node-control` so out-of-process socket owners share the engine's attach-conflict decision instead of copying it.

### Fixed

- Provider attach accepts an unbound provider instead of reporting a false live-instance conflict.

## [6.0.4] - 2026-07-13

### Fixed

- Kept inbox and delivery reads independent from scheduled cleanup while large expired-delivery backlogs drain in bounded batches.

## [6.0.3] - 2026-07-12

### Fixed

- Preserved monotonic per-agent delivery sequences across retention and pruning.
- Negotiated authoritative delivery cursors when node brokers reconnect, preventing duplicate or missed replay.

## [6.0.2] - 2026-07-11

### Fixed

- Logged node teardown failures with their original stack instead of silently swallowing them.

## [6.0.1] - 2026-07-11

### Fixed

- Prevented provider-attach races from dropping node capabilities.
- Serialized self-hosted SQLite writes to avoid transaction deadlocks.
- Logged rejected node-control messages and message-trigger dispatch failures.
- Allowed restarted providers to replace stale bindings while rejecting live duplicates.
- Dispatched node-scoped message-trigger actions to the owning provider.
- Rescheduled node-scoped actions according to the owning provider's liveness and queue policy.

## [6.0.0] - 2026-07-09

### Added

- Allowed one logical node to host multiple named providers with provider-owned capabilities and node-scoped actions.
- Added node provider clients for the TypeScript, Python, and Swift SDKs.
- Added provider disconnect hooks and aggregate node-state cleanup in the engine.

### Fixed

- Minted scoped observer tokens for realtime streams.

## [5.1.1] - 2026-07-08

### Added

- Added Relayfile inbound integration ingress and delivery to node agents.

## [5.1.0] - 2026-07-02

### Added

- Added a durable workspace event log for the observer plane.

## [5.0.12] - 2026-07-02

### Fixed

- Correctly recognized D1 observer-token name conflicts as conflicts instead of internal errors.

## [5.0.11] - 2026-07-01

### Added

- Added action events, a persisted observer feed, and improved observer navigation.

### Fixed

- Accepted `ot_live_` observer tokens at dashboard login.
- Allowed observer tokens to read workspace metadata.

## [5.0.10] - 2026-07-01

### Added

- Added optional egress proxying for `http_push` delivery.

## [5.0.9] - 2026-07-01

### Fixed

- Fixed `http_push` webhook dispatch on Cloudflare when redirects are rejected.

## [5.0.8] - 2026-06-30

### Fixed

- Delivered ephemeral reactions, receipts, and presence events to `http_push` nodes.

## [5.0.7] - 2026-06-28

### Added

- Emitted `message.created` for inbound webhook triggers.

### Fixed

- Prevented stale TypeScript SDK build output from being published.

## [5.0.6] - 2026-06-27

### Added

- Preserved inbound webhook payloads in message metadata.

## [5.0.5] - 2026-06-26

### Added

- Exported node invocation helpers from the engine.

## [5.0.4] - 2026-06-26

### Added

- Added Python SDK parity for node events.
- Exported agent disconnect handling from the engine.

## [5.0.3] - 2026-06-26

### Added

- Exported the engine's node-control handler.

## [5.0.2] - 2026-06-26

### Changed

- Routed agent fanout events through node streams.

## [5.0.1] - 2026-06-25

### Changed

- Made realtime delivery node-only.

## [5.0.0] - 2026-06-25

### Breaking

- Made the engine cast-only; SDK clients now own base URL defaults.

### Added

- Made nodes first-class delivery hosts for agents across direct WebSocket, fleet WebSocket, and HTTP-push transports.
- Added agent-to-node bindings, HTTP-push authentication and acknowledgement modes, delivery retries, and redacted node configuration.
- Added matching node delivery contracts to the TypeScript, Python, Rust, and Swift SDKs.

Earlier releases are available on the [GitHub releases page](https://github.com/AgentWorkforce/relaycast/releases).

[Unreleased]: https://github.com/AgentWorkforce/relaycast/compare/v8.16.0...HEAD
[8.16.0]: https://github.com/AgentWorkforce/relaycast/compare/v8.15.0...v8.16.0
[8.15.0]: https://github.com/AgentWorkforce/relaycast/compare/v8.14.0...v8.15.0
[8.14.0]: https://github.com/AgentWorkforce/relaycast/compare/v8.13.1...v8.14.0
[8.13.1]: https://github.com/AgentWorkforce/relaycast/compare/v8.13.0...v8.13.1
[8.13.0]: https://github.com/AgentWorkforce/relaycast/compare/v8.12.0...v8.13.0
[8.12.0]: https://github.com/AgentWorkforce/relaycast/compare/v8.11.7...v8.12.0
[8.11.7]: https://github.com/AgentWorkforce/relaycast/compare/v8.11.6...v8.11.7
[8.11.6]: https://github.com/AgentWorkforce/relaycast/compare/v8.11.5...v8.11.6
[8.11.5]: https://github.com/AgentWorkforce/relaycast/compare/v8.11.4...v8.11.5
[8.11.4]: https://github.com/AgentWorkforce/relaycast/compare/v8.11.3...v8.11.4
[8.11.3]: https://github.com/AgentWorkforce/relaycast/compare/v8.11.2...v8.11.3
[8.11.2]: https://github.com/AgentWorkforce/relaycast/compare/v8.11.1...v8.11.2
[8.11.1]: https://github.com/AgentWorkforce/relaycast/compare/v8.11.0...v8.11.1
[8.11.0]: https://github.com/AgentWorkforce/relaycast/compare/v8.10.1...v8.11.0
[8.10.1]: https://github.com/AgentWorkforce/relaycast/compare/v8.10.0...v8.10.1
[8.10.0]: https://github.com/AgentWorkforce/relaycast/compare/v8.9.1...v8.10.0
[8.9.1]: https://github.com/AgentWorkforce/relaycast/compare/v8.9.0...v8.9.1
[8.9.0]: https://github.com/AgentWorkforce/relaycast/compare/v8.8.0...v8.9.0
[8.8.0]: https://github.com/AgentWorkforce/relaycast/compare/v8.7.0...v8.8.0
[8.7.0]: https://github.com/AgentWorkforce/relaycast/compare/v8.6.1...v8.7.0
[8.6.1]: https://github.com/AgentWorkforce/relaycast/compare/v8.6.0...v8.6.1
[8.6.0]: https://github.com/AgentWorkforce/relaycast/compare/v8.5.5...v8.6.0
[6.0.3]: https://github.com/AgentWorkforce/relaycast/compare/v6.0.2...v6.0.3
[6.0.2]: https://github.com/AgentWorkforce/relaycast/compare/v6.0.1...v6.0.2
[6.0.1]: https://github.com/AgentWorkforce/relaycast/compare/v6.0.0...v6.0.1
[6.0.0]: https://github.com/AgentWorkforce/relaycast/compare/v5.1.1...v6.0.0
[5.1.1]: https://github.com/AgentWorkforce/relaycast/compare/v5.1.0...v5.1.1
[5.1.0]: https://github.com/AgentWorkforce/relaycast/compare/v5.0.12...v5.1.0
[5.0.12]: https://github.com/AgentWorkforce/relaycast/compare/v5.0.11...v5.0.12
[5.0.11]: https://github.com/AgentWorkforce/relaycast/compare/v5.0.10...v5.0.11
[5.0.10]: https://github.com/AgentWorkforce/relaycast/compare/v5.0.9...v5.0.10
[5.0.9]: https://github.com/AgentWorkforce/relaycast/compare/v5.0.8...v5.0.9
[5.0.8]: https://github.com/AgentWorkforce/relaycast/compare/v5.0.7...v5.0.8
[5.0.7]: https://github.com/AgentWorkforce/relaycast/compare/v5.0.6...v5.0.7
[5.0.6]: https://github.com/AgentWorkforce/relaycast/compare/v5.0.5...v5.0.6
[5.0.5]: https://github.com/AgentWorkforce/relaycast/compare/v5.0.4...v5.0.5
[5.0.4]: https://github.com/AgentWorkforce/relaycast/compare/v5.0.3...v5.0.4
[5.0.3]: https://github.com/AgentWorkforce/relaycast/compare/v5.0.2...v5.0.3
[5.0.2]: https://github.com/AgentWorkforce/relaycast/compare/v5.0.1...v5.0.2
[5.0.1]: https://github.com/AgentWorkforce/relaycast/compare/v5.0.0...v5.0.1
[5.0.0]: https://github.com/AgentWorkforce/relaycast/compare/v4.2.0...v5.0.0
