# Session Catalog — shallow coding-agent session discovery

**Answer "which coding-agent sessions have been found, newest first?" in
milliseconds, without indexing a single transcript.**

`ai-hist sync` builds the deep index: every message, tool call, file edit and
full-text row. That is the right thing for search, and the wrong thing for a
session picker — it reads every transcript end to end. The **session catalog**
is the shallow half: it enumerates provider sessions cheaply, extracts only the
metadata needed to *identify* a session, and caches the result in the `sessions`
table so the next listing touches no provider file at all.

The two layers coexist. Discovery never blocks or downgrades a full sync, and a
fully indexed session keeps its richer state when discovery re-reads it.

The catalog is one ledger, not separate local and remote catalogs. A session
may have a `local` presence, a `remote` presence, or both. Its presences are
stored in `session_presences`, while callers still receive one session row.
Collection commands select a location with exactly one of `--local`,
`--remote`, or `--all`; omitting a scope flag means `--local`. `--all` is the
deduplicated union, so the same `(source, session_id)` is never returned twice
just because it has both presences. Combining scope flags is an invalid
argument; provider `--source` filters remain orthogonal to location scope.

---

## The two operations

After those two catalog operations, targeted hydration acquires the richest
available evidence for one selected identity:

```ts
const sessions = await listSessionCatalog({ limit: 100 });
await hydrateSession({ source: sessions[0].source, sessionId: sessions[0].sessionId });
```

Hydration requires the catalog row and never invokes discovery or global sync.
It upgrades `discoveryState` to `full` when the acquisition it was asked for
was indexed through its recorded source stamp. `full` is therefore a statement
about discovery being complete for that request, not that a live coding
session has ended, and not that every evidence kind exists: kinds the request
never acquired -- including ones declined by an option such as
`includeRelated: false` -- are described by `coverage` and `capability` below,
which is where a consumer looks to find out what was left out. A remote
connector that could not return its evidence at all stays `shallow` and reports
its capability explicitly. File providers validate the saved locator against
the expected provider root; OpenCode uses session-keyed queries against its
live read-only database.

`capability` and `coverage` answer a different question from `discoveryState`,
and hydration contract 3 made the local path compute both rather than assert
them. `coverage` lists the evidence kinds the selected provider's parser can
produce; `capability` is `full` only when that list contains every kind in
`FULL_SESSION_KINDS` (`history`, `session_event`, `tool_call`, `file_edit`,
`relationship`), and `partial` otherwise, with a `HYDRATION_PARTIAL_COVERAGE`
diagnostic naming the missing ones. A zero count for a *covered* kind means
this session has none of it; a kind absent from `coverage` means nothing
looked. So a completed Cursor hydration reports:

```json
{
  "capability": "partial",
  "coverage": ["history"],
  "diagnostics": [{ "code": "HYDRATION_PARTIAL_COVERAGE", "message": "cursor evidence covers history; this hydration produces no session_event, tool_call, file_edit, relationship" }]
}
```

Coverage is narrowed by the request as well as by the provider.
`includeRelated: false` asks for the selected thread alone, and hydration
honours that literally -- Claude subagent sidecars are not walked and Codex
child rollouts are not read -- so `relationship` drops out of `coverage` and a
Claude or Codex session hydrated that way reports `partial`. That is the
difference between "this session has no delegation" and "nothing looked"; the
diagnostic says which by naming `include_related`.

Codex child acquisition reads the selected session's date directory and the
following date in both the active and archived rollout stores, which finds
children spawned across midnight or moved between stores without making an
old session scan years of newer rollouts. If later date directories exist in
either store, the
bounded search may miss delayed descendants; the result omits `relationship`
from `coverage`, reports `partial`, and includes
`HYDRATION_BOUNDED_RELATIONSHIPS`. A full sync can index relationships across
the archive.

A source plugin declares its own `coverage` the same way, and the same
distinction applies to it: `covered_kinds` names what the acquisition
*examined*, so a complete export of a session that has no file edits still
covers `file_edit` and reports `full`. A connector also receives
`includeRelated` and must omit `relationship` from both its coverage and its
records when it is `false` -- otherwise a `scope: 'all'` merge would union the
kind back in and report `full` despite the opt-out.

`discoveryState` stays `full` for that row: it records that the session was
indexed through its recorded source stamp, which is what the unchanged
short-circuit reads. A parser upgrade still forces a re-parse, because the
stored `parser_version` is checked independently of `discoveryState`.

Codex child rollouts, and Claude subagent transcripts whose records carry a
per-child `agentId`, retain their provider-native IDs and are linked through
`session_relationships`: their events are indexed under the child's own
session id rather than flattened into the parent, and delegated task prompts
are not stored as human prompt history. Claude evidence from a provider
version that does not name the child is recorded as an unlinked relationship —
never as a synthesized identity — and its output stays attributed to the
parent. The hydration stamp covers every file that evidence came from — the
selected transcript, each subagent transcript, and the
`agent-<agentId>.meta.json` describing it — so a metadata sidecar that arrives
or changes on its own still re-hydrates the session. Set
`includeRelated: false` or use CLI `--no-related` to acquire only the selected
thread.

| | `ai-hist sessions list` | `ai-hist sessions discover` |
|---|---|---|
| Reads | the cached ledger only | configured provider locations, with bounded reads |
| Provider I/O | none | head/tail of the newest candidates |
| Writes | nothing (read-only handle when the schema is current) | upserts `sessions` rows |
| Output | one JSON object | JSONL session, diagnostic, and summary records |
| Use it for | every repaint of a session picker | refreshing the catalog |

Use **`list`** whenever you are rendering: it is a single indexed query, it
cannot contend with a running `sync`, and it still works when the provider
files have been deleted.

Use **`discover`** when the catalog may be stale — on app launch, on a manual
refresh, or on a timer. It is safe to run beside `ai-hist sync`.

```bash
# Refresh from local provider locations (the default).
ai-hist sessions discover
ai-hist sessions discover --local

# Run every configured discovery adapter: local adapters plus any
# configured remote connectors (see source-plugins.md).
ai-hist sessions discover --all --limit 20

# Read back what the catalog holds — no provider file is opened.
ai-hist sessions list
ai-hist sessions list --remote --limit 100 --source codex --source claude
ai-hist sessions list --all --limit 100

# Page backwards by recency (keyset, not OFFSET).
ai-hist sessions list --limit 50 --before-ms 1781949900000

# Machine-readable forms.
ai-hist sessions list --json          # one JSON object
ai-hist sessions discover --json      # JSONL: sessions, diagnostics, summary
```

---

## The output contract

Both operations carry `contract_version` — currently **4**
(`SESSION_CATALOG_CONTRACT_VERSION`). It is bumped whenever the shape or the
meaning of a row changes in a way a consumer must notice, so parse it and fail
loudly on a version you do not know rather than guessing.

### `sessions list --json`

One object, never a bare array, so the version travels with the payload:

```jsonc
{
  "contract_version": 4,
  "scope": "local",
  "sessions": [
    {
      "source": "codex",
      "session_id": "0198c2ad-codex",
      "cwd": "/Users/you/Projects/api",
      "git_branch": "feature/retries",
      "first_activity_ms": 1782039600000,
      "last_activity_ms": 1782039603000,
      "first_prompt": "make the backoff configurable",
      "last_assistant_text": null,
      "models": ["gpt-5-codex"],
      "originator": "codex_cli_rs",
      "agent_version": "0.148.0",
      "repo_url": "git@github.com:acme/api.git",
      "initial_commit": "abc1234def",
      "workspace_roots": ["/Users/you/Projects/api"],
      "raw_path": "/Users/you/.codex/sessions/2026/06/21/rollout-codex.jsonl",
      "source_stamp": "v2:1788042670103317900:569",
      "discovery_state": "shallow",
      "project_key": "github.com/acme/api",
      "project_key_method": "remote",
      "locations": ["local"],
      "from_cache": true
    }
  ],
  "next_cursor": {
    "last_activity_ms": 1782039603000,
    "source": "codex",
    "session_id": "0198c2ad-codex"
  }
}
```

Keys are `snake_case`. `models`, `workspace_roots`, and `locations` are always
arrays (possibly empty); every other absent value is `null`, never an invented
placeholder or an empty string.

`project_key` is the canonical project identity: the `origin` remote
canonicalized to `host/owner/repo`, or the working directory when no remote
resolves. **Group by it rather than by `cwd`** — two checkouts, two worktrees
or two subdirectories of one repository share a key but never share a path, and
a path-keyed rollup splits them. `project_key_method` says how the key was
arrived at, and the three are not interchangeable:

| `project_key_method` | meaning |
| --- | --- |
| `remote` | canonicalized `origin` remote; comparable across machines |
| `path` | no remote resolved, so the key is the directory and is only meaningful on the machine that produced it |
| `inherited` | adopted from the delegating parent session, because the child's own directory resolved to nothing canonical |

The rules match burn's `crates/relayburn-sdk/src/reader/git.rs` vector for
vector, so `burn --group-by project` and a RelayHistory rollup agree on the
same checkout. No `git` subprocess is involved: git's configuration is read
directly, in the scopes and precedence git itself uses — system
(`$GIT_CONFIG_SYSTEM` or `/etc/gitconfig`, unless `$GIT_CONFIG_NOSYSTEM`), then
global (`$GIT_CONFIG_GLOBAL`, else **both** `$XDG_CONFIG_HOME/git/config` and
`~/.gitconfig`, in that order — git reads both, and `git config --global
--list` showing only the latter is about where git *writes*), then the
repository's own, following a linked worktree's
`gitdir:` pointer. `include.path` and `includeIf` (`gitdir:`, `gitdir/i:`,
`onbranch:`) are expanded at the position of their own line, so a value written
before an include is overridden by it and one written after it wins — as git
resolves them — and `url.<base>.insteadOf` rewrites are applied
longest-prefix-first, as `git remote get-url` does. The outer scopes matter as
much as the repository's own: the rewrite that makes `gh:Org/Repo.git`
resolvable is almost always configured once in `~/.gitconfig` for the whole
machine.

For a linked worktree, `config` is read from the shared directory `commondir`
names while `HEAD` is read from the worktree's own git directory, and
`includeIf` conditions are evaluated against that same per-worktree directory.
A worktree exists to be on a different branch from the checkout it shares a
repository with, so asking the shared directory would answer about the wrong
tree. When the shared config enables `extensions.worktreeConfig`, that
worktree's `config.worktree` is read after the shared config, as git reads it.

Both spellings of a subsection are understood: `[remote "origin"]` and the
legacy `[remote.origin]` name the same remote, with git's differing case rules
— the quoted subsection is case-sensitive, the dotted header folds entirely,
so `[remote.ORIGIN]` is `origin` while `[remote "ORIGIN"]` is a different
remote.

A remote's URL is a list, not a single value: git accumulates every
`remote.<name>.url` it reads, across scopes as well as within a file, and the
remote *is* the head of that list — `git remote get-url origin` prints it while
`git config --get remote.origin.url` prints the last. The canonical key follows
`get-url`, so a repository with a mirror configured after its origin keys to
the origin. An IPv6 authority keeps its brackets (`[2001:db8::1]/acme/app`), so
an address is never cut at the first colon of its own body.

One thing is deliberately left out: `includeIf "hasconfig:remote.*.url:"` is
not evaluated, because its answer depends on how much configuration has been
read so far. It cannot turn a resolvable remote into a wrong one — it only
leaves a rewrite unapplied, which falls back to a path key.

Both are `null` while a session's identity has not been resolved yet — a
database that predates the columns migrates without inventing keys, and the
next sync or hydration fills them. `null` means "not resolved", never "no
project".

A key is resolved from the working directory, or from a remote the provider
recorded (Codex's `session_meta.payload.git.repository_url`). A `path` key is
never final: every sync reconsiders it, so a session whose checkout was deleted
picks up the canonical key as soon as a recorded remote makes one available. A
`remote` key is never downgraded.

Filter a listing to one project with `ai-hist sessions list --project <key>`
(SDK: `listSessionCatalogPage({ projectKey })`). It is an exact match on the
key, not a path or a prefix. `ai-hist stats` groups `top_projects` by the key
and reports `grouped_by`; `--by-cwd` (SDK: `stats({ byCwd: true })`) restores
the per-directory grouping.

For this cache-only operation, top-level `scope` is the filter applied to the
ledger. `locations` contains observed presences only; legacy rows that predate
presence tracking may therefore have an empty array while still appearing in
the compatibility-preserving default local view.

`next_cursor` is the continuation for the next page, or `null` once the catalog
is exhausted (the page came back short of its limit). See
[Pagination](#pagination).

### `sessions discover --json`

JSONL, one object per line (the `events` command's precedent). Three line
types, in this order:

```jsonc
// 0..n session rows, in global recency order (newest first)
{"type": "session", "source": "codex", "session_id": "0198c2ad-codex", "from_cache": false, /* …same fields as above… */ }

// 0..n non-fatal failures — one provider or one malformed session
{"type": "diagnostic", "source": "grok", "locator": "/Users/you/.grok/sessions/…/chat_history.jsonl", "error": "…"}

// exactly one closing summary — emitted even when every provider failed,
// so a consumer always sees the reason before the non-zero exit
{
  "type": "summary",
  "contract_version": 4,
  "scope": "local",
  "locations_run": ["local"],
  "discovered": 2,
  "skipped_unchanged": 0,
  "providers": {
    "claude":   {"candidates": 1, "discovered": 1, "skipped_unchanged": 0, "failed": false},
    "codex":    {"candidates": 1, "discovered": 1, "skipped_unchanged": 0, "failed": false},
    "cursor":   {"candidates": 0, "discovered": 0, "skipped_unchanged": 0, "failed": false},
    "grok":     {"candidates": 0, "discovered": 0, "skipped_unchanged": 0, "failed": false},
    "opencode": {"candidates": 0, "discovered": 0, "skipped_unchanged": 0, "failed": false},
    "relay":    {"candidates": 0, "discovered": 0, "skipped_unchanged": 0, "failed": false}
  },
  "exempt_sources": [
    {"source": "trajectory", "reason": "derived trajectory records, not provider sessions"}
  ],
  "counters": {
    "candidates_enumerated": 2,
    "shallow_reads": 2,
    "skipped_unchanged": 0,
    "files_opened": 2,
    "bytes_read": 978,
    "provider_queries": 0,
    "records_inspected": 0
  }
}
```

`counters` is the run's bill of work, and it is the honest way to check that
discovery stayed cheap. `bytes_read` counts explicit reads from file-backed
providers only; SQLite does not report exact filesystem bytes, so OpenCode
leaves it at zero instead of substituting the database file size.
`provider_queries` counts OpenCode's bounded data queries (schema-capability
introspection is excluded), and `records_inspected` counts the rows those data
queries return. `shallow_reads` is `0` on a rescan where nothing changed.
Summary `scope` echoes the requested acquisition scope, and `locations_run`
enumerates the connector locations that actually executed — `["local"]` on a
machine with no remote connector configured, `["local", "remote"]` when an
`all` run also executed one. `providers` groups source adapters rather than
locations, so under `all` a source served by a local adapter and a remote
connector reports their merged tallies; row `locations` still report observed
presences.

Diagnostics are their own lines and never appear inside the `summary` object,
so a consumer that only wants the tally can read the last line and stop. In
human (non-`--json`) mode they go to stderr instead, leaving stdout clean:

```text
  2026-06-21 11:00  codex    local        shallow  0198c2ad-codex   /Users/you/Projects/api  make the backoff configurable
  2026-06-20 10:05  claude   local        shallow  3f6c1b7a-claude  /Users/you/Projects/api  add a retry to the http client
  2 session(s): 0 discovered, 2 unchanged (0 file(s) opened, 0 shallow read(s)); requested scope: local, connector locations run: local
```

A provider that fails contributes a `diagnostic` and nothing else; the run
continues and exits `0`. The command fails only when **every** selected
provider failed.

---

## Field semantics

Every value is one of three things, and the distinction is part of the
contract:

| Field | Kind | Notes |
|---|---|---|
| `source` | observed | `claude`, `codex`, `cursor`, `grok`, `muse`, `opencode`, `relay` |
| `session_id` | observed | provider-native; `(source, session_id)` is the primary key, so the same native id under two providers is two rows |
| `cwd` | observed | working directory the provider recorded |
| `git_branch` | observed | last branch the provider recorded |
| `first_activity_ms` | observed | `null` when the provider records no timestamps at all |
| `last_activity_ms` | observed, or filesystem-derived | file mtime for providers that record no timestamps |
| `first_prompt` | **derived** | bounded excerpt (≤ 4096 chars) of the first *substantive* human turn; provider control/meta/sidechain turns are skipped. For remote rows it is the provider's own session/task title — the listing's only human-readable identifier, which both providers derive from the opening prompt |
| `last_assistant_text` | observed | **only** written by full indexing — always `null` on a shallow-only row |
| `models` | observed, best effort | model ids seen inside the bounded read; empty means "not seen cheaply", not "no model" |
| `originator` | observed | the client that started the session (codex only) |
| `agent_version` | observed | agent CLI version |
| `repo_url` | observed | remote URL, when the provider records one |
| `initial_commit` | observed | commit the session started from |
| `workspace_roots` | observed | extra workspace roots, when the provider records them |
| `raw_path` | observed | provider file this row came from; the session/task URL for remote rows; `null` for database-backed sources |
| `source_stamp` | internal | change marker; see [rescan behaviour](#rescans-and-source-stamps) |
| `discovery_state` | internal | `"shallow"` or `"full"` |
| `locations` | derived | sorted presences from `session_presences`: `"local"`, `"remote"`, or both |
| `from_cache` | per-response | `true` when the row was served without re-reading the source |

Absent metadata stays `null`. Nothing is ever invented to fill a column.

### What the catalog deliberately does not have

Except for targeted remote hydration — full Claude teleport evidence or the
partial Codex cloud diff — these require a full `ai-hist sync` through an
available provider connector:

- per-message events (`session_events`) and tool calls; file edits are partial
  for a Codex cloud row whose available diff has been hydrated
- token usage and cost
- session → commit links
- full-text search over transcripts
- the full transcript body, and `last_assistant_text`

`discovery_state` tells you which you have: `"full"` means a full ingest has
run for that session, `"shallow"` means catalog metadata only. Full ingest
always wins — a shallow rescan refreshes a `full` row's metadata and stamp but
never downgrades its state. Local connectors provide full sync today. Claude
remote rows can become full through targeted teleport-evidence hydration;
Codex remote rows remain shallow after their available diff is indexed because
the CLI exposes no transcript export (see [Remote connectors](source-plugins.md)).

### Product boundary

Discovery reports *which sessions exist* and identifying metadata. It does not
infer project membership, work status, health, risk or success, and it does not
summarize outcomes.

### Scope and connector availability

Scope filtering is consistent across catalog listing, search, recent history,
statistics, packs, and resume selection: `local` selects sessions with a local presence, `remote` selects those
with a remote presence, and `all` returns their deduplicated union. These are
cache-only queries over the same ledger.

Discovery and sync are acquisition operations. Local adapters are always
available; remote acquisition runs through provider connectors —
`claude-web` for claude.ai/code web sessions and `codex-cloud` for Codex
cloud tasks — that are configured by the provider CLI's own stored sign-in
(see [Remote connectors](source-plugins.md)). Explicit remote acquisition
on a machine with no connector configured returns an error rather than
silently doing local work. `--all` means every configured adapter: the local
adapters plus whichever connectors are configured.

The discovery summary preserves the requested scope and reports the executed
locations separately in `locations_run`, so `--all` reports `scope: "all"`
with `locations_run: ["local"]` on a machine without connectors. That is
different from each row's observed `locations`. A remote-only session can be
selected by resume search, but it cannot yield a usable local resume command;
materialize it locally first. Sessions with both presences remain locally
resumable.

Direct `session` and `events` lookups already name a `(source, session_id)` and
therefore remain scope-independent.

---

## Per-provider capability matrix

What each adapter can actually extract from a cheap read. `✓` = populated when
the provider recorded it; `–` = the provider does not expose it to a shallow
read.

This table covers *shallow discovery only*. The full-evidence picture — which
record types each source captures, stores and exposes after `ai-hist sync` —
is the capture matrix in [ADR: relayhistory owns session
sourcing](decisions/2026-09-19-relayhistory-owns-session-sourcing.md#capture-matrix)
([#161](https://github.com/AgentWorkforce/relayhistory/issues/161)), which this
table must stay consistent with. That per-source matrix is the contract of
record for what a harness's sessions carry. burn is moving to reading evidence
only through this crate: from burn 5.0.0
([burn #562](https://github.com/AgentWorkforce/burn/issues/562)) it parses no
harness logs of its own, and from then on a record type the matrix does not
mark captured is missing for every consumer, not just for `ai-hist`.

| Source | `session_id` | `cwd` | `git_branch` | `first_activity` | `last_activity` | `first_prompt` | `models` | `originator` | `agent_version` | `repo_url` | `initial_commit` | `workspace_roots` |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **claude** | ✓ | ✓ | ✓ | ✓ | ✓ (tail) | ✓ | ✓ (head) | – | ✓ (record `version`) | – | – | – |
| **codex** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **cursor** | ✓ (dir name) | ✓ (decoded path) | – (never) | ✓ (injected `<timestamp>`) | ✓ (injected `<timestamp>`, else mtime) | ✓ | ✓ (if a build writes `message.model`) | – | – | – | – | – |
| **grok** | ✓ | ✓ | ✓ | ✓ (`updates.jsonl`, else `summary.json`) | ✓ (`updates.jsonl`, else `summary.json`) | ✓ | ✓ | – | – | – | – | – |
| **muse** | ✓ (metadata `stream.id`) | ✓ (`workspace_root`) | – (never) | ✓ (metadata `recorded_at`) | ✓ (tail `recorded_at`) | ✓ (first `started` prompt) | ✓ (metadata, then `model_completed`) | – | ✓ (`build.semver`) | – | – | – |
| **opencode** | ✓ | ✓ (directory / message `path.cwd`) | – | ✓ | ✓ | ✓ | ✓ (`providerID/modelID`) | – | – | – | – | – |
| **relay** | ✓ | – (never) | – | ✓ (synced min ts) | ✓ (synced max ts) | ✓ (earliest synced prompt) | – | – | – | – | – | – |

### Session markers

Not every provider record is a message. Compaction and summary boundaries,
system rows, non-text content blocks and agent lifecycle events all describe a
session without being a turn in it, and the normalized `session_events` model
has no `kind` for any of them. They are recorded in `session_markers` instead
of being dropped, and read with `session_markers_page` — the same
`(ts_ms IS NULL, ts_ms, id)` keyset the tool call and file edit pages use.

`kind` is the classified vocabulary below; `subkind` is the provider-native
type verbatim. A record type no classifier knows yet is stored as
`kind = "unknown"` with its real name in `subkind`, so it is recoverable
later.

`payload_json` is always bounded — every string at 128 characters and every
container at 32 entries, recursively — so an `image` or `document` block
contributes its size and never its bytes. How it is *built* depends on whose
keys they are. Where this parser classifies the record it names the fields it
keeps, which is the tighter contract. Where the payload is the provider's own
document and its keys are theirs — Grok's `signals` sidecar, a compaction
checkpoint — the document is bounded whole instead: enumerating the provider's
keys would silently drop whatever it adds next, which is the failure this
table exists to end. Either way the bound is the promise the column makes, and
it holds for every kind.

| `kind` | claude | codex | grok | muse | `subkind` examples |
|---|---|---|---|---|---|
| `compaction_boundary` | ✓ `type:"system"`, `subtype:"compact_boundary"` | ✓ top-level `compacted`, `context_compacted` | ✓ | – | `compact_boundary`, `compacted` |
| `summary` | ✓ `type:"summary"` | – | – | – | `summary` |
| `subagent_notification` | ✓ system rows with `parent_tool_use_id`; tool results carrying `toolUseResult.agentId` | ✓ `subagent_*` | – | – | `subagent_completed`, `tool_use_result_agent_id`, `subagent_message_complete` |
| `task_started` | – | ✓ | – | – | `task_started` |
| `task_complete` | – | ✓ | – | – | `task_complete` |
| `turn_diff` | – | ✓ | – | – | `turn_diff` |
| `stream_error` | – | ✓ | – | – | `stream_error` |
| `tool_begin` | – | ✓ any `*_begin` | – | – | `exec_command_begin`, `patch_apply_begin`, `mcp_tool_call_begin` |
| `review_mode` | – | ✓ | – | – | `entered_review_mode`, `exited_review_mode` |
| `fork_replay_boundary` | – | ✓ one per replayed span in a forked rollout: `parent_id` is the fork parent, `turn_id` the child turn that closed it, `payload_json` carries `first_line`, `last_line`, `replayed_lines`, `closed_by` (`turn_id`, `task_started.started_at`, `undecided`, or null while the span is still open), `inherited_total_tokens`, and `inherited_baseline` (`pending`, `applied`, `dropped`) with `inherited_baseline_basis` (`last_token_usage`, `regression`, `no_evidence`) | – | – | `session_meta` |
| `unsupported_block` | ✓ any content block with no event `kind`, plus thinking signatures | – | – | – | `image`, `document`, `redacted_thinking`, `server_tool_use`, `thinking_signature` |
| `encrypted_reasoning` | – | ✓ `response_item/reasoning` | ✓ an opaque reasoning trace with no summary | ✓ `reasoning_committed` with only `encrypted_content` | `reasoning` |
| `tool_replacement` | ✓ `_meta.replaces` / `_meta.collapsedCalls` | – | – | – | `tool_result` |
| `system` | – | – | ✓ a system preamble, in `text` | – | – |
| `synthetic_turn` | – | – | ✓ a turn the harness wrote, in `text` | – | – |
| `signals` | – | – | ✓ | – | – |
| `prompt_context` | – | – | ✓ | – | – |
| `local_notice` | ✓ an `assistant` record whose model is `<synthetic>`: a notice Claude Code wrote itself (API error, expired login), text in `text`, `error` and `is_api_error_message` in `payload_json` | – | – | – | `synthetic` |
| `unknown` | ✓ any unclassified record type, plus a `user`/`assistant` record that produced no event at all | ✓ any unclassified payload type, including `agent_reasoning_raw_content` and `agent_reasoning_section_break` | – | – | the provider type, verbatim |
| `turn_end` | – | – | – | ✓ run `terminal` (`completed`, `interrupted`, …) in `text` | `terminal` |
| `session_start` | – | – | – | ✓ `session.opened.observed`, `resume` in the payload | `session.opened.observed` |
| `session_resumed` | – | – | – | ✓ | `session.resumed` |
| `session_end` | – | – | – | ✓ `exit_reason` in `text` | `session.end` |
| `model_switch` | – | – | – | ✓ a later metadata record, the new model in `text` | `runtime.session.metadata` |

`text` is the provider's own readable prose for a marker, and `payload_json`
its structure; a marker may carry either, both or neither. Grok records a
system preamble and a synthetic turn as prose, which is why the column exists
rather than that prose being flattened into JSON that no longer reads as prose.
Where a `kind` is written by more than one provider, the writers populate the
same columns for it, so `compaction_boundary` reads the same whether Claude,
Codex or Grok produced it.

Every provider line leaves a row behind: an event, a marker, or both. A record
type is silent here only when some other part of the parser is known to store
it — a claim that is checked, not assumed, by
`every_codex_line_leaves_an_event_or_a_marker_behind`. A record's outer `type`
is classified independently of whether it also carries message content, so a
future record type that happens to carry some is not filed away as an ordinary
text event with its native type recorded nowhere.

The invariant is enforced by *counting the rows a record produced*, not by
predicting them from the shape of its content. Content can be present and still
reach nothing — `""`, `[]`, or blocks that are all blank — and each such shape
is one more rule to miss. A Claude record that wrote no row falls back to
`unknown` carrying its provider type, and a Codex line measured against
SQLite's own `total_changes` does the same: a blank `agent_message` or a
`*_end` with no `call_id` is stored by nothing, whatever the handler list says.

One Codex span is accounted for as a whole rather than line by line: the
parent history a forked rollout replays before its own first turn. Those lines
are the parent's evidence, already indexed under the parent, so they write
nothing under the child, and the single `fork_replay_boundary` marker above
stands for all of them. The span opens only at the parent's own `session_meta`
reappearing in a rollout that named that parent in `forked_from_id` or
`source.subagent.thread_spawn.parent_thread_id`, and closes at the first turn
it can attribute to the child or cannot order at all; the rule is
`codex::ForkReplayGate`, which shallow discovery applies too, so a fork's
`first_prompt` is its own. See [architecture](architecture.md) for the full
rule.

Codex keeps one explicit exception list, for lines that are state updates
rather than records and whose information is stored elsewhere: `session_meta`
and `turn_context` populate the catalog, `token_count` is folded into the
adjacent assistant event's `token_json`, `thread_settings_applied` carries the
model forward, a `*_delta` is a fragment of an event recorded whole, and an
assistant `message` is the mirrored twin of the `agent_message` that stores the
text.

A **user** message is deliberately not on that list, and the reason is the
lesson the list itself taught. Codex writes a user turn in two representations
and a deduplicator stores one row for the pair — but only when it accepts the
turn. It refuses blank text and content with no `input_text` part, such as an
image-only turn (an application-injected control wrapper is accepted and stored
as a `codex_context_wrapper` row, so it writes). Exempting user messages
by type alone therefore asserted a row had been written when none had, and
those lines vanished. The exemption is now *earned*: it applies to a mirrored
twin, where the deduplicator reports that its partner really did write, and
every other user line is settled by measurement like anything else.

That is the general shape to keep: an exception list must be oriented so a
wrong entry costs a redundant marker rather than a vanished line, and an entry
that asserts "something else stored this" has to be checked against what was
stored.

Markers are evidence, so they are removed with the rest when a complete remote
snapshot replaces a session: a marker left behind would tell a caller that
something is still there which the provider has stopped sending.

They also have to *survive* that path. A remote Claude snapshot is parsed by
the same local parser into a temporary database and then projected back out as
evidence records, so whatever the projection list omits is written during
normalization and discarded before anything durable sees it. Markers are in
that list — `PARSED_SESSION_KINDS`, everything this crate's parser writes —
which is deliberately separate from `FULL_SESSION_KINDS`, the set a remote
connector must supply for its snapshot to count as complete. A source plugin
cannot derive markers, so requiring them there would silently demote every
third-party connector to partial.

A compaction boundary states no size of its own, so a Claude
`compaction_boundary` payload carries `tokens_before_compact` taken from the
`cache_read_input_tokens` of the assistant message immediately before it.

`session_events.raw_kind` names the provider-native record or block an event
came from. Two very different records normalize to `kind = "tool_result"` — a
`tool_result` content block (`raw_kind = "tool_result_block"`) and a Claude
`type: "system"` subagent notification
(`raw_kind = "system_subagent_notification"`) — and `raw_kind` is what keeps
them apart without widening the `kind` vocabulary readers switch on.
Tool-result fidelity is a separate capability. The columns live on the
`session_events` rows whose `kind` is `tool_result`, and every one of them is
null when the provider does not record it — never a stand-in zero or a guessed
status, because a fabricated measurement reads exactly like a real one:

| Source | `payload_bytes` / `payload_hash` | `payload_truncated` | `call_index` / `event_index` | `result_status` | `event_source` | `error_signal` | `subagent_session_id` / `agent_id` |
|---|---|---|---|---|---|---|---|
| **claude** | ✓ (raw `content`) | ✓ (harness markers) | ✓ | ✓ | `tool_result`, `subagent_notification` | `tool_result.is_error`, `subagent_status` | ✓ (system subagent notifications) |
| **codex** | ✓ (raw `output`) | ✓ (harness markers) | ✓ | ✓ (settled at `task_complete`) | `function_call_output` | `exit_code`, `patch_apply`, `mcp_err` | – (no notification rail) |
| **cursor** | ✓ (raw block `content`) | ✓ (harness markers) | ✓ | ✓ | `tool_result` | `tool_result.is_error` | – (no notification rail) |
| **grok** | ✓ (raw line `content`) | ✓ (harness markers) | ✓ | ✓ (`unknown` with neither signal) | `function_call_output` | `tool_result.is_error`, `tool_status` | – (no notification rail) |
| **opencode** | ✓ (raw part `output`) | ✓ (harness markers) | ✓ | ✓ | `function_call_output` | `exit_code`, `tool_status` | – (no notification rail) |
| **muse** | ✓ (result `text`) | ✓ (harness markers) | ✓ | ✓ (`tool_batch.effect.terminal`, joined by call id) | `function_call_output` | `tool_batch.effect`, `exit_code` (`bash`) | – |
| **relay** | – | – | – | – | – | – | – |

`payload_bytes` is the raw UTF-8 length of what the provider handed back —
a string payload as-is, any other JSON payload stable-stringified with sorted
keys — measured before the `text` column is materialized, and `payload_hash`
is the first 16 hex characters of that payload's sha256. Both match
relayburn's `stable_stringify` / `content_hash`, so a value measured on either
side compares equal rather than merely looking alike. `payload_truncated`
records that the *harness* had already cut the output, which is the difference
between "this tool returned 8 KB" and "this tool returned far more and 8 KB is
a floor".

Codex reports how a call ended out of band (`exec_command_end`,
`patch_apply_end`, `mcp_tool_call_end`), so its result rows are written with
`result_status = 'unknown'` and settled when the turn closes at
`task_complete`. End of file is **not** a turn boundary: a live rollout's last
turn can still receive the `exec_command_end` that fails one of its calls after
the bytes a sync read, so a partial read records the failures it saw and leaves
anything else `unknown`. Only `task_complete` can call a result a success.

Cursor, Grok and OpenCode measure through the same
`ToolResultFacts::from_payload` helper, so the columns mean the same thing for
them. `event_source` says where the result was recorded, and that decides
whether it is a block of a user turn: a Cursor result is a Claude-shaped
`tool_result` block inside a message record, so it is `tool_result`; a Grok
`tool_result` chat line and the `output` of an OpenCode tool part are records
of their own (OpenCode's lives on the assistant message), so they are
`function_call_output`, like Codex's, and are not counted among a user turn's
blocks. `tool_status` is the provider's own terminal status on the call — an
OpenCode part's `state.status: "error"`, or a failed or cancelled `status` on
Grok's last ACP update for the call. OpenCode's non-zero `metadata.exit` is
named `exit_code` in preference to it, and Grok's own `is_error` on the result
line in preference to the ACP status. A Grok result with neither signal is
`unknown`, not `completed`: `updates.jsonl` can be missing, and a result line
alone does not say the call succeeded.

A result with nothing displayable in it — a silent command's empty string, a
structured payload carrying no text — is still recorded. `payload_bytes = 0` is
a measurement; dropping the row would lose the call's linkage and its place in
the ordering too.

Because the columns are nullable and the schema migration marks itself
complete, an upgraded install would otherwise keep skipping unchanged
transcripts on the sync fast path and leave every historical tool result null.
Plain `sync` therefore runs one backfill pass per provider, recorded in the
sync state, during which a transcript whose indexed tool results have no
`event_index` is re-read. Selecting files that way is narrower than
invalidating the whole stamp map, which would re-read the entire archive.

The generation is recorded only after a pass that both completed and covered
everything it discovered: every rollout root the database has indexed from was
reachable, and every transcript it found was read. A provider read that fails
is propagated rather than defaulted to an empty string, because an I/O or
UTF-8 failure reduced to `""` is indistinguishable from a file that genuinely
holds nothing. The walk indexes the rest of the tree and then reports the
failure, so the sync is classified as failed for that source rather than
reporting a complete cache it does not have.

Only a file that the walk would otherwise *skip* next time holds the pass
open — one whose recorded stamp still matches, which is the case where nothing
about the file will change to reopen it. A file with no stamp, or a stamp that
has moved, is revisited by the walk itself, so keeping the generation pending
would buy it nothing while keeping the per-session probe live, which re-reads
any session carrying a contributed null row on every sync.

The pass is bounded by a recorded generation rather than by "some row is still
null", and that distinction matters: `session_events` is keyed by
`(source, session_id)`, local and remote observations of one session share
that identity, and an adapter may contribute a tool result with no fidelity at
all. Re-reading the local transcript never populates a row that came from
somewhere else, so a null-row condition could stay true forever and re-read an
unchanged file on every sync without ever repairing it.
Evidence coverage is the hydration-side version of that matrix: what each
local parser writes, and therefore the `coverage` a completed local hydration
reports. It is declared per adapter (`ShallowSessionProvider::evidence_kinds`),
so a provider that grows a parser flips one entry and the reported capability
follows.

| Source | `history` | `session_event` | `tool_call` | `file_edit` | `relationship` | `capability` |
|---|---|---|---|---|---|---|
| **claude** | ✓ | ✓ | ✓ | ✓ | ✓ | `full` |
| **codex** | ✓ | ✓ | ✓ | ✓ | ✓ when the bounded child search is complete | `full` or `partial` |
| **cursor** | ✓ | ✓ | ✓ | ✓ | – (never: a `Task` block names no child transcript) | `partial` |
| **grok** | ✓ | ✓ | ✓ | ✓ | ✓ | `full` |
| **muse** | ✓ | ✓ | ✓ | ✓ | ✓ | `full` |
| **opencode** | ✓ | ✓ | ✓ | ✓ | ✓ | `full` |
| **relay** | – | – | – | – | – | targeted hydration unsupported |

### Per-message raw facts on `session_events`

The envelope facts a harness records per message or per API request, kept
verbatim on every event so a consumer can group, price and time turns without
re-reading the transcript. `stop_reason` is the provider's own wire string,
never a normalized enum, and its *absence* is the signal that a turn is still
in flight.

| Source | `request_id` | `stop_reason` | `agent_version` | `is_sidechain` | `is_meta` | `turn_id` |
|---|---|---|---|---|---|---|
| **claude** | ✓ (`requestId`) | ✓ (`message.stop_reason`) | ✓ (`version` / `sourceVersion`) | ✓ (`isSidechain`) | ✓ (`isMeta`) | – |
| **codex** | – | – | – | – | – | ✓ (`turn_context.turn_id`, carried to the next `turn_context`) |
| **opencode** | – | ✓ (`step-finish.reason`, pending event-level parity) | – | – | – | – |
| **muse** | ✓ (`response_id`) | ✓ (the step's `finish_reason`) | ✓ (`build.semver`) | – | – | ✓ (the run's `run_id`) |
| **cursor**, **grok**, **relay** | – | – | – | – | – | – |

A null is "the provider did not record it", which is not the same as `false`
or as an empty string: a Claude record with no `isSidechain` key stores null,
while `"isSidechain": false` stores `0`.

Because of that, none of the six can answer "was this row indexed before the
facts existed?" -- a real record legitimately has no `request_id`, no
`stop_reason` and no `turn_id`, and Codex records none of the other three.
`raw_facts_version` answers it instead: the local parser stamps it on every
event it writes, so a full sync can pick out the transcripts whose rows predate
the facts and re-read them. It is bookkeeping rather than a provider fact and is
not part of the session-event evidence spec, so a row an installed source
adapter contributed is permanently unstamped.

That is why the column selects files but does not bound the work. Local and
remote observations of one session share `(source, session_id)`, so a contributed
row would otherwise hold an unchanged local transcript off the stamp fast path on
every sync while never being stamped itself. What ends the work is a per-provider
generation recorded in the sync state (`claude_raw_message_facts`,
`codex_raw_message_facts`), written only after a walk completes **and only when
every archive root the state already names was present on that run**, so the
backfill runs exactly once, an interrupted sync retries it, and a walk that
could not read the files it was meant to repair does not retire it. That check
is per file, not per root: a mount point exists whether or not anything is
mounted on it, and a partially mounted archive returns some of the paths the
state names and not others. A path this run did not see withholds the
generation **and** loses its stamp, so if it comes back it is read afresh rather
than skipped on a stamp nothing watched. Dropping the stamp is also what bounds
the deleted-file case: it costs one further sync, after which the path is no
longer one the state knows about. Removing the entry from the in-memory map is
not enough to achieve that — the checkpoint merge folds a run's keys over
what is on disk and has no way to express a delete, so a dropped path would
come back on every write. The run carries the removals as an instruction the
merge applies and then discards. A transcript that is enumerated but cannot be
read counts as unobserved too, not as an empty one — the parsers read with
`unwrap_or_default()`, so without that check a file that became unreadable
between the walk and the read would be stamped as seen. A root the state never knew about — an install
with no `.codex/archived_sessions` — is not a missing archive and does not hold
the pass open. Claude reaches a subagent
sidecar's rows through `session_relationships.evidence_locator`, because a
sidecar never gets a `sessions` row of its own.

Delegation is a separate capability, reported on every relationship result as
`capabilities.stableChildIdentity`:

| Source | Stable child identity | Agent type | Spawn time | Evidence locator |
|---|---|---|---|---|
| **codex** | always | ✓ | ✓ | ✓ |
| **opencode** | always | – | ✓ | ✓ |
| **claude** | sometimes | ✓ | ✓ | ✓ |
| **grok** | sometimes | ✓ | ✓ | ✓ |
| **muse** | always | ✓ | ✓ | ✓ |
| **cursor**, **relay** | never | – | – | – |

OpenCode is `always` because a subagent session is a session in its own right
and its own record names the parent, in `session.parentID`. Nothing is
inferred from file names or ordering, so the edge is recorded with
`evidence_kind = "opencode_parent_id"` and `identity_status = "observed"`.

OpenCode is the one source whose four columns do not move together, which is
the point of reporting them separately: it names the parent and the spawn
time and keeps the evidence locator, but records no *type* for the child, so
`childAgentType` and `childAgentName` are always null and the capability says
so rather than promising a field the adapter never writes.

Grok is `sometimes` for the same shape of reason: a `subagents/` metadata
entry that records a child session id links to a child session in the normal
sessions tree, and one that does not is stored as unlinked evidence. The id is
never taken from the entry's file name. A `Task` call inside the transcript
names no child at all. See ["grok"](#grok).

Muse is `always` because every subagent writes its own
`subagent/<id>/session.jsonl` beside the parent, and that log's metadata
record names the child session. The edge is recorded with `evidence_kind =
"muse_subagent_log"`; the agent type, name and model come from the parent's
`task_stream_linked` (or `memory_reminder_child_session_linked`) record for
that log. See ["muse"](#muse).

Cursor is `never` for a different reason from grok, opencode and relay: it does
record the spawn — a `Task` / `functions.Subagent` tool call, preserved as a
`tool_calls` row — but the block names no child transcript, so there is no
identity to link. See ["cursor → Delegation"](#cursor).

Claude is `sometimes` because a subagent transcript carries the *parent's*
`sessionId` on every record; the child's own identity is the per-child
`agentId`, which only newer provider versions emit. When it is present the
child is indexed under it; when it is absent the delegation is recorded as
unlinked evidence and the child id is left null — it is never taken from the
`agent-<id>.jsonl` file name.

How each adapter works:

- **claude** — `$CLAUDE_CONFIG_DIR/projects/**/*.jsonl` (default
  `~/.claude/projects/**/*.jsonl`). Head for identity, `cwd`,
  branch, `version`, models and the first human prompt; tail for the last
  timestamp and the final branch. Meta rows, slash-command wrappers, bash
  wrappers and sidechain (subagent) turns are skipped when picking
  `first_prompt`. A subagent *sidecar* — a separate file whose records all
  carry the parent's `sessionId` — is not a session of its own: it is detected
  in the head read and skipped, so a session is emitted once per run and its
  row keeps pointing at its own transcript. A transcript whose complete records
  parse as nothing is reported as a diagnostic rather than published under its
  file name; an empty one is simply not a session yet. The subagent workflow
  journal, `<session>/subagents/**/journal.jsonl`, is excluded by name before
  anything opens it — here and in the full sync walk alike. It records
  workflow orchestration (`started` / `result` lines), not a conversation, and
  no session, event, marker, cursor or continuity row is derived from it.
  `$CLAUDE_CONFIG_DIR/transcripts/` is deliberately **not** a Claude root —
  not enumerated, synced, hydrated or watched. Claude Code does not write
  there; oh-my-opencode's Claude-hook compatibility layer does
  ([`transcript.ts`](https://github.com/code-yeongyu/oh-my-openagent/blob/dev/packages/omo-opencode/src/hooks/claude-code-hooks/transcript.ts)),
  one `<OpenCode ses_* id>.jsonl` per *OpenCode* session, as `user` /
  `tool_use` / `tool_result` lines with top-level `content` and `tool_name` /
  `tool_input` / `tool_output`, and no `sessionId`, `uuid`, `cwd`, model or
  usage. A user's census of 5,004 such files in
  [tokscale#487](https://github.com/junhoyeo/tokscale/issues/487) found no
  `assistant` line and `usage` in only 15. This is characterized from those
  sources, not from a local copy of the directory. The session is already
  indexed, with full evidence, by the **opencode** adapter from OpenCode's own
  store; reading the copy as `claude` would publish each one twice under two
  sources with no project identity
  ([#208](https://github.com/AgentWorkforce/relayhistory/issues/208)). The
  accepted residual: a user who deletes their OpenCode store but keeps the
  wrapper transcripts gets those sessions indexed from neither.
- **codex** — `rollout-*.jsonl` under `$CODEX_HOME/sessions` and
  `$CODEX_HOME/archived_sessions` (defaulting under `~/.codex`). The first line
  is a `session_meta` record, which
  makes codex the richest source: originator, `cli_version`, git remote, initial
  commit, workspace roots and model all come from it. Subagent threads are real
  rollouts but not user sessions, so they are excluded — exactly as the full
  sync excludes them — and remembered in `discovery_skips` so a rescan does not
  re-read them.
<a id="cursor"></a>

- **cursor** — `~/.cursor/projects/<encoded-path>/agent-transcripts/<id>/<id>.jsonl`.
  The session id is the directory name and `cwd` is decoded from the project
  directory name; neither appears inside the file. The head read takes the
  first human prompt and the first readable turn time, the tail read takes the
  last assistant prose and the last readable turn time, and `models` comes from
  `message.model` for the builds that write one — an empty list means "not seen
  cheaply", never "no model". Full details, and what Cursor does **not** write,
  are below.

  ### Cursor record shapes

  Cursor publishes no schema for this file, so the shapes below were
  characterized from public descriptions of real transcript corpora rather than
  from Cursor's documentation. **Sources are cited per field, and nothing here
  was verified against a real Cursor install on the machine this was written
  on** — see "Verification status" at the end of this section.

  A record is a bare object with the role at the **top level**:

  ```jsonl
  {"role":"user","message":{"content":[{"type":"text","text":"<timestamp>Wednesday, Sep 16, 2026, 3:37 PM (UTC-4)</timestamp>\n<user_query>ship it</user_query>"}]}}
  {"role":"assistant","message":{"content":[{"type":"text","text":"Reading the file."},{"type":"tool_use","name":"Read","input":{"path":"CHANGELOG.md"}}]}}
  {"role":"assistant","message":{"content":[{"type":"turn_ended","status":"success"}]}}
  ```

  There is no `message.role` and no record `type` — reading the role from the
  Claude Code nesting finds nothing and labels every turn as unknown. Older
  rows carry `message.content` as a bare string with no framing at all.

  | Field | Status | What RelayHistory does |
  |---|---|---|
  | top-level `role` | **Corroborated** by several independent adapters | Drives `session_events.role`; `user` turns also become `history` rows |
  | `message.content` as an array of blocks | **Corroborated** | Each block becomes one `session_events` row |
  | `message.content` as a bare string | **Corroborated** (the shape the pre-existing parser was written against) | Normalized into one synthetic `text` block |
  | `{"type":"text","text"}` | **Corroborated** | `session_events.kind = 'text'` |
  | `{"type":"tool_use","name","input"}`, **no `id`** | **Corroborated**; one report of `"id": null` in the CLI | `session_events.kind = 'tool_use'` plus a `tool_calls` row, keyed on the record's byte offset because there is no provider id |
  | `{"type":"turn_ended","status"}` | **Corroborated** | Skipped: it is a marker, and no `session_events.kind` honestly fits it |
  | `<timestamp>…</timestamp>` in the human turn's text | **Corroborated**; a localized human string, e.g. `Wednesday, Sep 16, 2026, 3:37 PM (UTC-4)` | Parsed explicitly (English month, 12- or 24-hour clock, required `(UTC±H[:MM])`), **only out of a human turn's own `text` blocks**. The records answering that turn inherit it |
  | `<user_query>…</user_query>` in the human turn's text | **Corroborated** | Stripped, so the stored prompt is what the person typed |
  | `message.model` | **Not written** by any reported build | Recorded if a build ever writes it; otherwise `models` is empty and the matrix says unavailable |
  | `message.usage` | **Not written** by any reported build | Same: recorded when present, never synthesized |
  | `{"type":"tool_result",…}` | **Not written** — "not one line of tool output is persisted" | Parsed when present; the observed corpus produces none |
  | `{"type":"thinking",…}` | **Not written** by any reported build | Parsed when present |
  | record `timestamp` field | **Not written** | Preferred over the injected tag when present |
  | `sessionId`, `cwd`, `gitBranch` inside the file | **Not written** | Taken from the path layout instead; `git_branch` stays null |
  | `parentMessageId`, `isSidechain`, `message.id` | **Not written** (an early adapter assumed these and was rejected against a real corpus) | `message.id` is used if present; the rest are not read |

  Tool names come in three dialects across Cursor versions and served models,
  and all three are classified: the unprefixed set (`Read`, `Grep`, `Glob`,
  `Shell`, `AwaitShell`, `Write`, `StrReplace`, `Delete`, `EditNotebook`,
  `ReadLints`, `TodoWrite`, `Task`, `SwitchMode`, `WebSearch`, `WebFetch`,
  `GetMcpTools`, `CallMcpTool`, `FetchMcpResource`, `GenerateImage`), the
  `functions.*` namespaced set used by GPT-served models (including
  `functions.ApplyPatch`, `functions.rg` and `functions.Subagent`), and an older
  snake_case set (`edit_file`, `search_replace`, `run_terminal_cmd`,
  `codebase_search`). `Write`, `StrReplace`, `ApplyPatch`, `Delete` and
  `EditNotebook` (plus their namespaced and snake_case spellings) produce
  `file_edits` rows. `ApplyPatch` is the awkward one: its `input` is the patch
  **text**, not an object, so the file paths come out of the patch headers and
  the line counts come from the same `count_patch_text` the Claude parser uses.
  One patch routinely rewrites several files, so it produces **one `file_edits`
  row per file**, each keyed `<tool_use_id>#<path>` and carrying only that
  file's slice of the patch — the same shape the Codex `patch_apply_end` path
  uses — under a single `tool_calls` row whose `target` names the first file.
  `StrReplace` carries old/new strings rather than a diff, so its edit is
  recorded with no line counts rather than guessed ones. `Shell` records only
  the command string, so no file is attributed to it.

  ### Identity and re-reads

  Because Cursor writes no record uuid and no `tool_use` id, every
  `session_events.event_uid`, `tool_calls.tool_use_id` and
  `file_edits.tool_use_id` is derived from the record's **byte offset** in the
  file. An offset is stable across an incremental read, a whole-file re-parse
  and a re-hydration, and it resets exactly when Cursor rewrites the file —
  which is also when the byte cursor resets. This is what makes a repeat read
  upsert in place instead of duplicating.

  Stability *within* a generation is not enough, though, because a rewrite
  reuses those offsets for different records. Any read that starts at offset 0
  — a first sight of the file, a Cursor rewrite, or the one re-read a retired
  state key forces after a parser upgrade — is therefore a **rebuild**: it
  clears the session's `history`, `session_events`, `tool_calls` and
  `file_edits` together, inside the writing transaction, before indexing.
  Upserting on top would leave every row the previous, longer generation wrote
  past the new end of the file, so the session would keep tool calls and edits
  it never made. Targeted hydration always re-reads the whole transcript, so it
  always rebuilds.

  `history` additionally cannot be upserted even within a generation: a
  prompt's identity is `(source, timestamp_ms, prompt)`, and a turn with no
  readable time is stamped with a file mtime that moves on every append. Plain
  `sync` therefore inserts prompts only for records at or after the offset it
  resumed from, except on a rebuild, where it re-inserts all of them.

  Only newline-terminated records are indexed, matching `CompleteJsonlReader`
  and `complete_jsonl_records`. A record Cursor has flushed but not yet
  terminated is left alone: publishing it would put evidence at a byte offset
  the checkpoint does not consider consumed.

  For the same reason, indexing stops at the byte position the scan consumed
  through. Cursor writes continuously, so it can append between the scan and
  the whole-file read; those bytes are past the checkpoint this run commits, so
  indexing them would publish evidence the next sync reads again from the
  checkpoint — and an untimed prompt re-read after the mtime moved is a
  duplicate, not an upsert. The append is picked up by the next sync instead,
  from the offset that still points at it.

  An incremental read also leaves the timestamps of records it is merely
  re-reading alone. The mtime moves on every append, and it is the fallback
  stamp for a record with no recorded time, so re-deriving it for an older
  record would silently redate evidence stored under a different one — and
  since `history` rows before the resumed offset are deliberately not
  rewritten, the event would end up disagreeing with the prompt of its own
  turn. Only records at or past the resumed offset take the current mtime;
  earlier untimed records keep the stamp they already have.

  A transcript that cannot be read — it vanished between the scan and the
  index, or it is not valid UTF-8 — **fails** the sync. It is not indexed as an
  empty session. That matters because the rebuild has already deleted the rows
  it is about to recreate: swallowing the read error would commit an empty
  session and advance the byte checkpoint past content nobody read. The error
  rolls the whole transaction back, including the checkpoint, so the next sync
  retries the same offset.

  A rebuild also **replaces** both ends of `sessions.first_activity_ms` /
  `last_activity_ms`, and `sessions.last_assistant_text`, rather than merging
  into them. The usual merge widens the window and keeps whatever prose it
  already had, which is right for an incremental read that saw only the tail —
  but a `MAX()` can never retract an endpoint an earlier, prompt-only parser
  derived from the file mtime, because a real recorded timestamp is almost
  always smaller than it; and a rebuild that has just re-read the whole source
  and found no assistant prose would otherwise leave the catalog quoting a
  reply the transcript no longer contains.

  ### Timestamps

  No prompt or event is stamped with the file mtime unless its turn carried no
  readable time. When that happens, targeted hydration reports a
  `CURSOR_TIMESTAMP_FROM_MTIME` diagnostic naming the fallback; it is never
  silent. Shallow discovery reports `first_activity_ms` from the first readable
  turn time and leaves it `null` when the build wrote none, and
  `last_activity_ms` falls back to the mtime.

  A **human turn** opens a new turn, so it replaces the inherited time even
  when it has none of its own; everything answering that turn inherits. An
  undated human turn that kept the previous turn's time would be dated to a
  conversation that had already ended, and — worse — would look dated, so the
  mtime fallback would never fire and the diagnostic would never be reported
  for a transcript that plainly needed it.

  The `role` alone does not identify a human turn. Cursor writes tool results
  back as **user-role** records, and a user record carrying only a
  `tool_result` — or only a marker such as `turn_ended` — answers the turn that
  is already open rather than starting a new one. A user record is treated as a
  human turn only when it carries a `text` block; the rest inherit, unless they
  carry a recorded time of their own. Treating every user record as a new turn
  sent tool results to the mtime, dating a result hours after the call it
  answers and putting the two halves of one exchange in disagreement.

  The tag is a clock only where Cursor's client puts it: in the text a person
  submitted. It is not a field, so the same characters can appear in an
  assistant reply — a model explaining this format, quoting the turn it is
  answering, or reading a log back — and that is prose. Scanning every role's
  blocks for it let such a reply supply a turn time, which re-dated that record
  and every record after it until the next turn, and suppressed the mtime
  fallback that should have fired. Shallow discovery ran the same scan, so the
  same prose also moved `first_activity_ms` and `last_activity_ms` and re-sorted
  the session in the catalog. Both paths now share one rule
  (`cursor::injected_turn_time`): the tag is read only from a `text` block of a
  **`user`** record. A record `timestamp` field, when a build writes one, is a
  real provider field and is believed whatever the role.

  What no rule can separate, because nothing in the record does, is a person
  who pastes a transcript containing the tag — the same ambiguity recorded
  below for Cursor's hooks and rules, which inject turns structurally identical
  to human prompts.

  The session's activity window covers every record a pass stamps **and stores
  evidence for**, not only the ones that carried a recorded time. An undated
  turn still produces events, at the mtime, so leaving it out of the window made
  `sessions.last_activity_ms` claim a recency older than the session's own
  newest event — and the session then sorted behind siblings that were
  genuinely older. Where a time was recorded it is still the one used, so a
  fully dated session reports its recorded times rather than the file mtime.

  Two kinds of record stay out of the window. One that stores nothing — a
  `turn_ended` marker is the whole record — has no event to be the recency
  *of*, and on a re-read it also has no stored event to recover its original
  time from, so it fell back to the *current* mtime and dragged the window to
  "now" on every single sync. And a record before the resumed offset whose
  original stamp cannot be recovered at all is stamped with a guess; a guess is
  not evidence of when anything happened, so it does not set the window either.

  ### Delegation

  Cursor's `Task` / `functions.Subagent` calls are recorded as ordinary
  `tool_calls` rows, so the spawn is visible. The block carries **no child
  transcript id**, so there is nothing to link to and
  `relationship_capabilities("cursor").stableChildIdentity` stays `never`;
  targeted hydration reports `CURSOR_SUBAGENT_SPAWN_UNLINKED` when a transcript
  contains such a call. Third-party reports describe subagent sidecars at
  `agent-transcripts/<parent>/subagents/<child>.jsonl`, but that layout is
  **unverified here** and no relationship row is written on the strength of it.

  ### Verification status

  Cursor was not installed on the machine this adapter was written on, so no
  real `~/.cursor/.../agent-transcripts/*.jsonl` was read. The fixtures under
  `crates/ai-hist/tests/fixtures/cursor/` reproduce the shapes described by the
  sources below; `extended-unverified.jsonl` is named so nobody mistakes it for
  evidence about Cursor.

  Sources consulted (all public, September 2026):

  - [agitHQ/agit PR #165](https://github.com/agitHQ/agit/pull/165) — the
    strongest source: an adapter built to a shape histogram over **104 real
    transcripts** (60 sessions + 44 subagents; 5,335 records, 11,162 content
    blocks) from **Cursor IDE 3.13.25**. Origin of "bare `{role, message}`,
    id-less `tool_use`, `turn_ended`, no `tool_result`/`thinking`/`timestamp`/
    `model`/`usage`", and of `ApplyPatch` taking patch text directly.
  - [agitHQ/agit PR #118](https://github.com/agitHQ/agit/pull/118) — the
    rejected predecessor. Useful as a negative result: it assumed an
    Anthropic-shaped `{role, type, message:{id, model, usage}, parentMessageId,
    isSidechain, timestamp}` record and was rejected because *none* of those
    fields exist in a real transcript.
  - [clickety-clacks/engram issue #19](https://github.com/clickety-clacks/engram/issues/19)
    — independent confirmation of `role` + `message.content[]` with `text` and
    `tool_use` blocks and no top-level `type`/`session_id`.
  - [ArcadeAI/safeword issue #4594](https://github.com/ArcadeAI/safeword/issues/4594)
    — independent confirmation that `role` is top-level and `message` has no
    `role`, measured against a real 564 KB transcript (76 user, 333 assistant).
  - [nixfred/infomarchy PR #34](https://github.com/nixfred/infomarchy/pull/34)
    — the `<timestamp>` tag, its exact wording
    (`Wednesday, Sep 16, 2026, 3:37 PM (UTC-4)`), the warning that `Date.parse`
    drops the offset on some builds, the `turn_ended` end-of-turn marker, and
    that hooks/rules inject turns indistinguishable from human prompts.
  - [entireio/cli `agent/cursor`](https://pkg.go.dev/github.com/entireio/cli/cmd/entire/cli/agent/cursor)
    — the `Write`/`StrReplace` file-modification pair, and that `Shell` records
    only a command string.
  - [fitchmultz/pi-cursor-sdk evidence, 2026-08-02](https://github.com/fitchmultz/pi-cursor-sdk/blob/main/docs/evidence/cursor-system-prompts-2026-08-02/README.md)
    — the full 19-tool inventory in both the unprefixed and `functions.*`
    dialects.
  - [cavi-ai/secure-agent PR #104](https://github.com/cavi-ai/secure-agent/pull/104)
    and [microsoft/AI-Engineering-Coach PR #264](https://github.com/microsoft/AI-Engineering-Coach/pull/264)
    — independent confirmation of "no timestamps, no tool results, no token
    usage, no model ID", and of the `subagents/` sidecar directory.
  - [kenn-io/agentsview issue #1627](https://github.com/kenn-io/agentsview/issues/1627)
    — reports `"id": null` on `tool_use` blocks in the CLI JSONL and absent
    tool results.

  **Checklist for a maintainer who has Cursor installed.** Run a short agent
  session, then against
  `~/.cursor/projects/*/agent-transcripts/<id>/<id>.jsonl`:

  1. `jq -r 'keys|join(",")' … | sort -u` — confirm the top-level key set is
     exactly `role,message` (and record any extra key).
  2. `jq -r '.message|keys|join(",")' … | sort -u` — confirm `content` is the
     only key, or capture `id`/`model`/`usage` if your build writes them.
  3. `jq -r '.message.content[]?.type' … | sort | uniq -c` — capture the real
     block-type histogram; confirm whether `tool_result` or `thinking` ever
     appear.
  4. `jq -r '.message.content[]? | select(.type=="tool_use") | .name' … | sort | uniq -c`
     — capture the real tool-name dialect for your model.
  5. `jq -r '.message.content[]? | select(.type=="tool_use") | .id' … | sort -u`
     — confirm ids are absent or null.
  6. `grep -c '<timestamp>' <file>` and eyeball one tag — confirm the wording
     and offset format in your locale.
  7. Delegate to a subagent and check whether
     `agent-transcripts/<id>/subagents/` exists and whether the parent's `Task`
     block names the child.

  Anything that comes back different should replace the matching row in the
  table above, move the fixture out of `extended-unverified.jsonl`, and update
  the capability matrix.
<a id="grok"></a>

- **grok** — `~/.grok/sessions/<encoded-path>/<id>/`. Identity, `cwd` and
  branch come from `summary.json`; the first prompt comes from the head of
  `chat_history.jsonl`, skipping synthetic reminder turns; both activity
  timestamps come from the first and last record of `updates.jsonl` when it is
  there, and from `summary.json`'s `created_at` / `updated_at` when it is not.
  Full hydration reads the whole directory — transcript, update stream,
  signals, compaction checkpoints and subagent metadata — plus whatever the
  Grok home's process-wide `logs/unified.jsonl` usage log gained since the last
  pass. Details below.

  ### What Grok writes, and where relayhistory reads it

  A Grok Build session directory holds `summary.json`, `updates.jsonl`,
  `chat_history.jsonl`, `system_prompt.txt`, `prompt_context.json`,
  `tool_definitions.json`, `plan.json`, `rewind_points.jsonl`, `signals.json`
  and `feedback.jsonl`, plus the directories `compaction_checkpoints/` and
  `subagents/`; tokscale also reads an `events.jsonl` there. RelayHistory
  reads six of those, reads `events.jsonl` only when `summary.json` is absent,
  and ignores the rest. Outside the session directory, the Grok home
  (`GROK_HOME`, else `~/.grok`) holds `logs/unified.jsonl`, one append-only log
  every Grok process writes per-inference usage to; it is read as a second
  Grok source (see "Usage" below).

  **`chat_history.jsonl` has the content; `updates.jsonl` has the time.** Grok's
  own guide calls `updates.jsonl` "the authoritative conversation log that
  drives `/resume`", and `chat_history.jsonl` carries no timestamps at all, so
  the two are joined:

  1. A record that carries its own `timestamp` uses it. The documented Grok
     Build shape has none; an older layout does.
  2. Tool calls and results join **by id** — `tool_calls[].id` and
     `tool_result.tool_call_id` against `toolCallId` on a `tool_call` /
     `tool_call_update` row. Exact.
  3. Prose joins **by ordinal**: the *n*-th non-synthetic `user` record takes
     the time of the *n*-th `user_message_chunk` group, and likewise
     `assistant` prose against `agent_message_chunk` and `reasoning` summaries
     against `agent_thought_chunk`. Consecutive rows of one kind are one group,
     because Grok streams a message in chunks.
  4. What is left takes its turn's `turnStartMs`, then the nearest preceding
     record's time, then `summary.json`'s `created_at`. Every step below an
     exact match is counted and reported as a `GROK_TIMESTAMP_FROM_TURN`
     hydration diagnostic.

  An update kind this parser does not interpret (`plan`, `hook_execution`,
  `retry_state`) is **not** a boundary in that join. Grok interleaves those
  rows into a streaming message, and counting one as a break would split the
  message into two groups — after which every later ordinal join reads one
  group too far and hands the next message somebody else's timestamp. Such a
  row still bounds the session's activity; it just does not divide it.

  **No timestamp is derived from a record's position in the file.** Until this
  landed, Grok prompt *n* was stamped `created_at + n` milliseconds: a
  fabricated ordering, in a ledger whose value is that it does not fabricate.
  A session with no update stream and no record timestamps now gives its
  events the one time Grok did record, and says so, rather than spreading them
  a millisecond apart.

  ### Record shapes

  | Field | Status | What RelayHistory does |
  |---|---|---|
  | `chat_history.jsonl` line = `{"type", "content"}` | **Corroborated** by Grok's own user guide and three independent adapters | One `session_events` row per record |
  | types `system`, `user`, `assistant`, `tool_result`, `backend_tool_call`, `reasoning` | **Corroborated** | `user` → user/text + `history`; `assistant` → assistant/text; `reasoning` → assistant/thinking; `tool_result` → tool_result; `system` → a `system` marker |
  | `user` prompt wrapped in `<user_query>…</user_query>` | **Corroborated** | Stripped, so the stored prompt is what the person typed |
  | `synthetic_reason` on a `user` record | **Corroborated** | Kept out of `history` (unchanged) **and** out of `session_events`; recorded as a `synthetic_turn` marker carrying the reason, because nobody typed it |
  | `assistant.model_id` | **Corroborated** | `session_events.model`, and `sessions.models_json` |
  | `assistant.tool_calls[] = {id, name, arguments}` | **Corroborated**; explicitly *not* an OpenAI `function` wrapper | One assistant/tool_use event and one `tool_calls` row each, keyed on the provider's `id` |
  | `tool_result = {tool_call_id, content}` | **Corroborated** | A tool_result event paired to the call by id |
  | `tool_result.is_error` | **Inferred** — the failure signal is documented on the ACP `tool_call_update` `status` | Both are read; either marks `tool_calls.is_error` |
  | `reasoning.summary` / `reasoning.encrypted_content` | **Corroborated** ("reasoning is encrypted_content") | The summary is the thinking text; an encrypted-only record becomes an `encrypted_reasoning` marker and is never given invented text |
  | `updates.jsonl` envelope `{timestamp, method, params:{sessionId, update:{sessionUpdate,…}, _meta:{eventId, agentTimestampMs}}}` | **Corroborated** by three independent adapters | The timing source for the join; `eventId` also becomes the event's identity |
  | `params._meta.eventId` is **not unique** | **Stated by tokscale** ("Grok reuses it across usage records", `sessions/grok.rs`) | The first message group carrying an id keeps `ev:<id>`; each later one is `ev:<id>#<n>` (`#1`, `#2`, …), so two messages never share an identity and an append never renames a stored one |
  | `params.update._meta.modelId` | **Read by tokscale** (`extract_model_id`); not seen in a public sample | The turn's model: written as `model` in the turn's `token_json` and added to `sessions.models_json` |
  | `turn_completed.usage.modelUsage` with one key | **Read by tokscale** | The turn's model when no row carried `_meta.modelId`; a map with several keys names no single model |
  | envelope `method` `session/update` **or** `_x.ai/session/update` | **Corroborated** | Both read; the method is not required to be either |
  | kinds `user_message_chunk`, `agent_message_chunk`, `agent_thought_chunk`, `tool_call`, `tool_call_update`, `plan`, `turn_completed`, `hook_execution`, `retry_state` | **Corroborated** | The first five and `turn_completed` are read; the rest are counted and reported as `GROK_UPDATES_ROWS_UNREAD` |
  | `timestamp` in epoch **seconds**, `agentTimestampMs` in **milliseconds** | **Corroborated** | A field named `…Ms` is read as milliseconds; a bare `timestamp` is scaled if it is below 10¹² |
  | `turnStartMs` | **Stated in [#167](https://github.com/AgentWorkforce/relayhistory/issues/167)** from burn #489; not seen in a public sample | Read from `params.update`, `params._meta` or the envelope; the turn's fallback time |
  | `turn_completed.totalTokens` | **Stated in #167**, and corroborated as a `turn_completed`-borne total | `token_json = {"context_total_tokens": n, "source": "updates.jsonl"}` on the turn's last assistant message |
  | `turn_completed.usage.{inputTokens, outputTokens, cachedReadTokens, reasoningTokens, costUsdTicks, modelUsage}` | **Reported by two community adapters for recent builds** and read in production by tokscale (`sessions/grok.rs`, commit `d8fd670`), which fixes its semantics: `inputTokens` includes `cachedReadTokens`, `outputTokens` includes `reasoningTokens`, `totalTokens` is input + output | Stored verbatim under `usage` in the turn's `token_json`, beside the context snapshot; normalized as `per-request` usage. See "Usage" below |
  | `summary.json` `info.id`, `info.cwd`, `info.model`, `git_root_dir`, `head_branch`, `created_at`, `updated_at` | **Corroborated** | Identity, project, branch, model and the fallback timestamps |
  | `summary.json` `current_model_id`, `model_id` | **Read by tokscale** as its model fallback; whether they sit at the top level or under `info` is **unverified**, so both are tried | The session's model when no transcript record or turn named one, after `info.model` |
  | `events.jsonl` `model_id`, `session_id`, `ts` (first 500 lines) | **Read by tokscale** as the fallback when `summary.json` is missing; that the file exists on current builds is **unverified** | Only when `summary.json` is absent: `model_id` is the model fallback and the earliest `ts` the `created_at` fallback. `session_id` is **not** taken as identity — the directory name already is the session id, and a file appearing later must not rename the session. Lines that do not parse are skipped: this is a metadata fallback, not evidence |
  | `summary.json` parent-session references for forked/restored sessions | **Corroborated** (named in the guide, field spelling unknown) | **Not read yet** — no field name to read |
  | `signals.json` `contextTokensUsed`, `turnCount`, `compactionCount` | **Stated in #167**; the guide says the file holds "token usage and tool/turn counters" | A `signals` marker whose `detail_json` is the file verbatim |
  | `signals.json` `totalTokensBeforeCompaction` | **Read by tokscale** (`effective_total_from_signals`) | Named in the `signals` marker's text beside `contextTokensUsed`, and kept verbatim in its payload. Not reconciled against anything: reconciling totals across a compaction is accounting, which is burn's. tokscale also reads a model id from this file, under a key nothing public names, so it is not read |
  | `<GROK_HOME>/logs/unified.jsonl` per-inference rows | **Read in production by tokscale** (`parse_grok_unified_log_file_with_prefix`); the row's field spellings are **inferred** — nothing public shows a row | See "Usage" below |
  | `prompt_context.json` | **Corroborated** ("inputs the system prompt was rendered from") | A `prompt_context` marker with the path, SHA-256 and size. The AGENTS.md body is never copied into the database |
  | `compaction_checkpoints/<entry>` | **Corroborated** as a directory; the entry's own fields are **unverified** | One `compaction_boundary` marker per entry, timed from `created_at`/`timestamp`/`turnStartMs` or the entry's numeric file name, with the parsed file in `detail_json` |
  | `subagents/<entry>` | **Corroborated** as "per-subagent metadata; child sessions live in the normal sessions tree"; the entry's own fields are **unverified** | One `session_relationships` row per entry, `evidence_kind = "grok_subagent_dir"` |
  | `system_prompt.txt`, `tool_definitions.json`, `plan.json`, `rewind_points.jsonl`, `feedback.jsonl` | **Corroborated** as present | Not read |

  Tool names observed by burn #489 are `Shell`, `Read`, `Write`,
  `StrReplace`/`Edit`, `Grep`, `Glob`, `Task`, `WebSearch`/`WebFetch` and
  `CallMcpTool`. `Write`, `StrReplace`, `Edit` and their snake_case and
  `functions.`-namespaced spellings produce `file_edits` rows; the edit is
  recorded when the call is made, as it is for Claude, so a call that later
  failed is a `file_edits` row whose `tool_calls` row carries `is_error`.
  `Shell` records only its command, so no file is attributed to it.

  ### Usage: a context proxy, plus per-turn usage when the build writes it

  Older Grok builds log **no per-turn input/output token counts** (burn #489).
  The token fact every build records is `updates.jsonl`'s `totalTokens`, stored as
  `{"context_total_tokens": n, "source": "updates.jsonl"}` on that turn's last
  assistant event — its last message, or, for a turn answered entirely with
  tool calls, its last tool use — so a consumer can see both the number and
  what it is. It is a context-window snapshot: it
  **decreases** after a compaction, and summing it across turns is meaningless.
  A session with no turn carrying a breakdown therefore reports
  `GROK_USAGE_CONTEXT_PROXY_ONLY`. Nothing here estimates tokens — that is
  burn's job, from its own estimator and `xai` pricing.

  Recent builds *do* write a `turn_completed.usage` breakdown (`inputTokens`,
  `outputTokens`, `cachedReadTokens`, `reasoningTokens`, `totalTokens`,
  `costUsdTicks`, `modelUsage`). Two community adapters reported it and
  tokscale reads it in production, so it is recorded — verbatim, under `usage`
  in the same `token_json`, beside the snapshot and never added to it — and
  `crate::usage` normalizes it as `per-request` usage (see
  `docs/usage-accounting.md`). A `usage` object holding only `totalTokens` is
  still the snapshot under another name. A session where only some turns carry
  a breakdown reports `GROK_USAGE_PARTIAL` instead; one where every turn does
  reports no usage caveat.

  **Per-inference usage from `logs/unified.jsonl`
  ([#212](https://github.com/AgentWorkforce/relayhistory/issues/212)).**
  Recent builds write every inference's token breakdown to one process-wide,
  append-only log in the Grok home, `<GROK_HOME>/logs/unified.jsonl`
  (`~/.grok/logs/unified.jsonl` when `GROK_HOME` is unset). It is a second
  Grok source:

  - It is read **incrementally**, from a byte cursor in `transcript_cursors`
    (the machinery of #173), by every sweep after the session directories and
    by every Grok hydration — `unchanged` ones included — in an `IMMEDIATE`
    transaction of its own, before the hydration's stamp check (the session's
    stamp never moves when the log grows). An unchanged log reads zero bytes;
    a trailing line with no newline waits for one. The file is in the sweep's
    stat-only fingerprint and is a watch root of its own, so an append to it
    wakes live capture.
  - The log is every session's, so a log that cannot be read — unreadable, or
    replaced mid-read — never fails a session's hydration: it is reported as
    `GROK_UNIFIED_LOG_UNREADABLE` for that run (not checkpointed), the cursor
    stays put, and the next pass retries. A sweep notes it and keeps the
    source out of its cached fingerprint.
  - Each usage row is copied into `grok_unified_usage`, the durable copy —
    the bytes are never read again — and then **materialized** onto the
    session it names as one `role = "assistant"`, `kind = "text"` event with
    no text, `raw_kind = "unified_log_usage"`, its own `request_span`, the
    row's model, and `token_json = {"usage": <counters>, "source":
    "logs/unified.jsonl", "pid", "event_id"}`. One inference is one
    `per-request` record, normalized with the same counter lists as
    `turn_completed.usage`. `costUsdTicks` is kept verbatim and never read as
    a cost. Only rows with no event yet are inserted, so an append attaches
    its own rows and leaves every stored event — and the change feed —
    untouched. A row later than the session's `last_activity_ms` extends it.
    A later shallow rescan still replaces the directory's activity bound, so
    compaction can move that end backward; when the log's latest row is later
    than the directory, that time is restored, and a model only the log named
    is appended to the directory's list. A model the directory no longer
    names stays off the row.
  - Rows attach **by session id**, assumed to equal `summary.json`'s
    `info.id` (unverified). A row for a session that is not in the catalog yet
    is **retained** and attached when that session is indexed; one that names
    no session at all is counted and not attached, because guessing a session
    from the pid would be invention.
  - **Retention.** `grok_unified_usage` keeps every row it is given, including
    rows whose session is not in the catalog — or no longer is. The log is
    never re-read, so a row deleted here is usage lost for good if the session
    is indexed (again) later. Each sweep that reads new bytes reports how many
    stored rows have no catalogued session ("retained for sessions not
    indexed"), so the backlog is visible; the rows are small (one counter
    object each).
  - A row is keyed on a digest of **the whole normalized row**, not on
    `eventId`: tokscale records that Grok reuses `eventId` across usage
    records, so an id key would collapse distinct inferences. The same row
    read twice (after a rotation) lands on the same key.
  - **Precedence per turn, never addition.** A turn's `turn_completed.usage`
    is stored with the turn's window (`turn_start_ms`, `turn_end_ms`). When a
    log row's time falls inside that window, the log has that turn's spend,
    so the breakdown is moved to `turn_usage`, which nothing normalizes —
    whether the session was indexed before or after the rows arrived. A turn
    the log does not reach (a log that started mid-session, or was rotated
    away) keeps its breakdown as `usage`, so it is neither counted twice nor
    dropped. A turn whose stream recorded no window cannot be placed either,
    so a timed log row never covers it and it keeps its own `usage`. A log
    row with no time cannot be placed in a turn, so its
    presence covers every turn: a demoted breakdown is still there as
    `turn_usage`, while an inference counted twice could not be told apart.
    The context snapshot is never usage in any case. Its turn window is stored
    beside it even when the turn wrote no breakdown, so a log row inside that
    window covers the turn.
  - Hydration's usage caveat for a session the log reaches is decided per
    turn: none when the log covers every turn; `GROK_USAGE_MIXED_SOURCES`
    when every turn has usage but some of it comes from `turn_completed.usage`
    (each turn still counted once); `GROK_USAGE_PARTIAL` when some turn has
    neither. A session the log does not reach keeps the caveat its
    `updates.jsonl` earns. Cached diagnostics are cleared when new rows
    attach, so an `unchanged` read rebuilds them from the stored rows and
    from the turn census the replacing read recorded. A turn that census
    counts and that left no token row still counts: it is covered when a
    timeless log row is stored, and otherwise it is one of the turns
    `GROK_USAGE_PARTIAL` names. `capability` stays `full` either way — usage
    is not an evidence kind (hydration contract 3).

  The row shape is **inferred**. tokscale reads a session id, a pid, a model
  and per-inference input/output/cache counters, and keys rows on
  `event_id`/`eventId`/`id`/`uuid`/`ctx.event_id`, but nothing public shows
  the spellings, so the parser looks for each field at the top level and then
  under `ctx`: the session as `session_id`/`sessionId`, the process as `pid`,
  the model as `model_id`/`modelId`/`model`, the time as `ts`/`timestamp`,
  and the counters in a `usage` object — or, failing that, at the row's top
  level, projected down to the counter keys so the rest of the log line is
  never stored as usage — with the same key lists `turn_completed.usage` is
  read with. A row that names a pid and a model and carries no counters (a
  process start or a model change) sets that process's model for its later
  rows that name none; the per-pid memory rides in the cursor. tokscale's
  per-subagent scoping by `(pid, generation, session_id)`, with a conflict
  state when evidence disagrees, is **not** implemented: its field names are
  not public, and a row's own session id already scopes it. A terminated row
  that is not JSON is counted and passed over rather than holding the cursor —
  the log is Grok's process log, not a session's evidence, and one bad line
  must not stop every later inference being read.

  ### Identity and re-reads

  `chat_history.jsonl` writes no record id. An event that joined to an update
  is keyed on that update's ACP `eventId` (`ev:<id>`), which survives the
  rebuild Grok performs on a format upgrade; an event that did not is keyed on
  its record index (`r<n>`), which does not. Tool calls and results are keyed
  on the provider's own call id (`tool:<id>`, `result:<id>`). Grok reuses an
  `eventId` across records: the first message group in stream order to carry
  an id keeps `ev:<id>`, and each later one is suffixed with its repeat number
  (`ev:<id>#1`, `ev:<id>#2`, …). Keying both on `ev:<id>` upserted the second
  message over the first; suffixing only the repeats means an append that
  reuses an id never renames a message already stored. A session indexed
  before this is re-read once, by `sync` (the `grok_events_v4` state key) and
  by hydration (parser version 14). A `logs/unified.jsonl` usage event is
  keyed `unified:<digest>` and is rebuilt, not cleared, by each replacing
  read.

  **A Grok read is a replacement, not a merge.** Grok rewrites
  `chat_history.jsonl` in place on a format upgrade or a compaction, and prunes
  `compaction_checkpoints/` and `subagents/`, so the directory is a snapshot of
  what the session *currently* says happened. Every read therefore clears this
  session's Grok-owned evidence — `session_events`, `tool_calls`, `file_edits`,
  `session_markers`, `history` and the relationships whose evidence is this
  session's own `subagents/` directory — inside the same transaction that
  rebuilds it. Upserting alone would leave a tool call that is no longer in the
  transcript, a checkpoint whose file was deleted, and every row whose `r<n>`
  identity shifted when the file was rewritten, sitting in the database
  forever with nothing to distinguish them from live evidence. A relationship
  another session recorded about *this* one is not this session's to delete,
  and is left alone. "Clears" means the local share only: a row a remote
  observation also supplied stays, as the remote side's (see
  [evidence location](#evidence-location)).

  The change stamp covers **every file the read consumes**: the transcript, the
  summary and the update stream each keep a readable marker, and
  `signals.json`, `prompt_context.json` and the sorted contents of
  `compaction_checkpoints/` and `subagents/` are folded into one digest (so a
  session with many checkpoints does not grow an unbounded stamp).
  `events.jsonl` joins that digest only when `summary.json` is absent, which
  is also when its head is read. While the summary is present the file grows
  with the session and is not consumed, so an append to it leaves the stamp
  where it is. Discovery, plain `sync` and targeted hydration all take the
  same stamp from the same function, so none of them can call a session
  unchanged on evidence the others would have re-read — a new checkpoint
  written after the last update row is new evidence, and is read as such.

  Every read in this path answers in three states: **absent** (nothing to
  record), **malformed but present** (the file's existence is itself evidence,
  so the marker is written with no detail rather than deleted), and
  **unreadable** (an error). `summary.json` is the one exception to the middle
  state, because it carries **identity** rather than detail — see below. A file the read consumes and cannot read is never
  an absent one: an unreadable `updates.jsonl` taken as "no stream" would replace exact
  event times with fallbacks and drop the token snapshots, and an unreadable
  sidecar directory taken as "no entries" would delete the checkpoints already
  stored — both while the metadata stamp, still perfectly readable,
  checkpointed that loss as the session's settled state. Only `NotFound` is
  absence. Plain `sync` isolates such a session, names it, counts it, and
  fails the source outright when nothing in the store could be read.

  A hydration that parses nothing still reports what Grok does not record: the
  provider diagnostics are stored with the hydration checkpoint and replayed on
  an `unchanged` result. An `unchanged` reader is looking at exactly the rows a
  parsing reader saw, so it is told the same things about them — above all that
  a token count it can see is a context proxy and not billing usage. A
  checkpoint written before those were persisted has none stored, and the usage
  caveat is rebuilt from the stored `token_json` and, when `logs/unified.jsonl`
  reaches the session, from the turn census the replacing read recorded.

  Grok hydration reports `capability: "full"` because its parser covers every
  evidence kind. The usage caveat travels with it as
  `GROK_USAGE_CONTEXT_PROXY_ONLY` (no turn carried a breakdown) or
  `GROK_USAGE_PARTIAL` (some did) on parsed and cached reads alike:
  `updates.jsonl`'s running context total is stored as a labelled proxy, never
  as usage. Capability is defined by
  `coverage` (hydration contract 3); usage is not one of those kinds, so a
  `partial` result that covered every kind would be a contract mismatch the
  SDK rejects. The diagnostic is what tells a cost report not to add the
  proxy up.

  **A finished JSONL row that does not parse fails the read.** Grok ingestion
  *replaces* a session's evidence rather than appending to it, so a row that is
  silently skipped is a turn deleted from the stored transcript — and the
  change stamp saved after it would checkpoint that deletion as the session's
  settled state, so no later run would look again. Both `chat_history.jsonl`
  and `updates.jsonl` therefore treat a newline-terminated row that is not JSON
  as a scan error: the session is named and counted, its previous transaction
  stands untouched, and its stamp is left behind for the next run. The single
  exception is the last line of a file when it has no newline — a record still
  being written. That one is parsed if it parses (not every writer terminates
  its final line, and discarding a whole record over a missing newline loses
  evidence just as surely) and ignored if it does not. Discovery's bounded
  head/tail scans stay lenient by design: a bounded tail read can legitimately
  begin mid-record, and discovery never deletes evidence.

  **An unchanged stamp is not on its own proof a session is indexed.**
  `.sync-state.json` sits beside `history.db`, so deleting or rebuilding the
  database leaves the state file behind, and a stamp read alone would answer
  "already done" for a session with no rows at all — for a finished session,
  forever. Plain `sync` records the session id beside each stamp and re-reads
  the directory when the evidence is gone, the same guard the Codex and Claude
  walks apply. "The evidence" means what Grok actually writes, and that is
  every table this ingestion drives: not every session produces
  `session_events` — one made only of `system` lines, synthetic turns or
  encrypted reasoning is stored entirely as markers, and one whose transcript
  is empty but whose `subagents/` directory names a child has only a
  relationship. Asking about a subset re-reads such a session on every run for
  ever, which is the thing the guard exists to prevent. The state entry
  records whether the indexing run wrote any evidence at all; a session that
  wrote none is checked against its **catalog row**, which every ingestion
  writes and which for such a session is the whole of what indexing produced.
  Skipping it without asking anything is what let an empty session disappear
  permanently when `history.db` was rebuilt. The catalog row is deliberately
  *not* the check for a session that did write evidence — discovery writes
  catalog rows too, so it would stand over missing rows.

  **A malformed `summary.json` fails the read; only an absent one falls back
  to the directory name.** `info.id` becomes the session id, which keys every
  evidence row and scopes every delete a replacing read performs, so it is the
  one sidecar where "malformed but present is evidence" does not hold. A
  summary caught mid-write used to fall back to the encoded-cwd folder name:
  the transcript was stored under `local-folder`, and once the file was
  repaired the next read stored the same session under `grok-123`, leaving the
  first set of rows keyed to an id no read would ever name again — and so
  never deletable, because deletes are scoped by the id that produced them.
  Absence keeps the fallback: a session directory with no summary at all is a
  real shape, and its folder name is the only identity there is.

  **The shallow read strips the `<user_query>` envelope, because the full read
  does.** Discovery writes `sessions.first_prompt` and hydration writes
  `history.prompt` from the same typed prompt, so a wrapper stripped in one
  and kept in the other shows the XML envelope in the catalog and the typed
  text in the transcript, for one session, with nothing to say which is the
  prompt. Both go through `unwrap_user_query`.

  **Replacing one session never deletes another session's prompt.** Because
  `history` is keyed `(source, timestamp_ms, prompt)` with no `session_id`, a
  prompt two sessions both contain is one row, attributed to whichever was
  indexed first. Deleting the replaced session's rows outright took that
  shared row with it, so an unchanged session's prompt vanished from search —
  permanently, since its own files never change again. A row the replaced
  session no longer owns is therefore **re-attributed** to a session whose
  stored `session_events` still carry that prompt at that millisecond, and
  only what is left is deleted. Re-attribution rather than skipping: skipping
  would leave the row filed under a session that no longer contains the
  prompt, which is untrue and also undeletable, since the only session that
  could clean it up is the one that no longer evidences it.

  **Markers are exported like any other evidence.** `session_markers` is a
  change-feed kind and an export kind, so the feed and a local export of a
  Grok session carry its compaction boundaries alongside its events. The kind
  is `session_marker`, in `SUPPORTED_KINDS` and in the TypeScript
  `HistoryEvidenceKind`.

  **One rule decides what a JSONL row is, in `ingest::jsonl`.** Two passes read
  the same files — the parse, which turns rows into evidence, and the count,
  which reports `records_parsed` — and when they each decided for themselves
  they disagreed: the parse read a valid final record with no trailing
  newline, while the count stopped at the missing newline without testing it,
  so a transcript ending in an unterminated record reported one record fewer
  than had just been read, and that figure was checkpointed. Both now call
  `jsonl::classify`. The count still streams, because an `updates.jsonl` must
  not be held in memory; only the rule is shared.

  **Repeated prompts at one timestamp are one `history` row.** `history` is
  keyed `UNIQUE(source, timestamp_ms, prompt)`, without `session_id`, so two
  turns with the same text at the same millisecond collapse. Grok makes this
  visible rather than causing it: a session with no `updates.jsonl` and no
  per-record times has exactly one real timestamp, `created_at`, so two
  `continue` turns collide where another provider's per-record clock would
  separate them. Spacing them out by a millisecond each is the synthesized
  `first_ts + index` ladder this work deleted, and is not an option — a
  fabricated time is worse than a collapsed rollup. The transcript, keyed per
  record, keeps both turns; the prompt rollup keeps one. Widening that key is a
  change to a table every provider shares and is tracked separately.

  A hydration's `source_bytes` and `records_parsed` describe the whole
  directory, not the transcript: an `updates.jsonl` is routinely the largest
  file in a busy session, and reporting the transcript alone understates the
  read by orders of magnitude. Records are the complete JSONL records of
  `chat_history.jsonl` and `updates.jsonl`, plus **one per whole-file JSON
  sidecar** — `summary.json`, `signals.json`, `prompt_context.json` and each
  `compaction_checkpoints/` and `subagents/` entry — because a sidecar is one
  document, and counting it as zero would make a directory of fifty
  checkpoints look like no work at all. A `.jsonl` entry inside those
  directories is counted by record, as the older layout writes subagent
  transcripts that way. The same directory walk produces the numbers and the
  change stamp, so the two can never describe different sets of files.

  ### Delegation

  `relationship_capabilities("grok").stableChildIdentity` is **`sometimes`**,
  for the same reason as Claude's: a `subagents/` entry that records a child
  session id is a linked delegation, and the child session lives in the normal
  sessions tree; one that does not is stored as unlinked evidence, and the
  child id is never taken from the file name. A `Task`-style call in the
  transcript names no child at all — it is a `tool_calls` row, reported as
  `GROK_SUBAGENT_SPAWN_UNLINKED`, and it never invents a relationship row.

  A linked edge records whether the child is **addressable** —
  `child_has_events`, which `session_tree` reads rather than probing — and
  that is a fact about the child, read from its indexed events. Because a
  parent can be read before its child exists in the index at all, indexing a
  Grok session also refreshes the edges that point *at* it, in both
  directions.

  ### Verification status

  Grok was **not installed** on the machine this adapter was written on, so no
  real `~/.grok/sessions/**` directory was read. The fixtures under
  `crates/ai-hist/tests/fixtures/grok/` reproduce the shapes the sources below
  describe. Everything marked **Corroborated** above is stated by at least one
  source that read a real session; everything marked **Stated in #167** comes
  from burn #489's format research, which this repo did not re-derive;
  everything marked **unverified** is a shape nobody public has published.

  A maintainer with Grok Build installed can confirm or correct all of it in a
  few minutes:

  ```sh
  S=~/.grok/sessions/<encoded-cwd>/<session-id>

  # 1. Which record types and fields chat_history.jsonl really writes.
  jq -r '.type' "$S/chat_history.jsonl" | sort | uniq -c
  jq -r 'to_entries[].key' "$S/chat_history.jsonl" | sort | uniq -c
  # 2. Tool calls: {id, name, arguments}, or something else?
  jq -c 'select(.tool_calls) | .tool_calls[0]' "$S/chat_history.jsonl" | head -3
  # 3. Does a tool_result carry is_error?
  jq -c 'select(.type=="tool_result") | {keys: keys}' "$S/chat_history.jsonl" | head -3
  # 4. Which sessionUpdate kinds the stream carries, and how often.
  jq -r '.params.update.sessionUpdate' "$S/updates.jsonl" | sort | uniq -c
  # 5. Does turnStartMs exist, and where?
  jq -c 'select(.params._meta.turnStartMs or .params.update.turnStartMs) | {meta: .params._meta, update: .params.update}' "$S/updates.jsonl" | head -2
  # 6. THE IMPORTANT ONE: what a turn_completed actually carries.
  jq -c 'select(.params.update.sessionUpdate=="turn_completed") | .params.update' "$S/updates.jsonl" | head -3
  #    If that prints inputTokens/outputTokens, the build writes the per-turn
  #    breakdown this parser now records under `usage`. Check that inputTokens
  #    includes cachedReadTokens and totalTokens is input + output (#212).
  # 7. What signals.json, a compaction checkpoint and a subagent entry hold.
  jq -c . "$S/signals.json"
  jq -c . "$S/compaction_checkpoints/"* | head -2
  jq -c . "$S/subagents/"* | head -2
  # 8. Does summary.json name a parent for a forked or restored session?
  jq -c 'with_entries(select(.key|test("parent|fork|restore";"i")))' "$S/summary.json"
  # 9. Which model keys summary.json writes, and where (#212).
  jq -c '{current_model_id, model_id, info_keys: (.info | keys)}' "$S/summary.json"
  # 10. Does events.jsonl exist, and what does its head carry?
  head -3 "$S/events.jsonl" | jq -c 'keys'
  # 11. The unified log: its row keys, whether its session id equals
  #     summary.json's info.id, and whether eventId repeats across usage rows.
  U=${GROK_HOME:-~/.grok}/logs/unified.jsonl
  jq -c 'keys' "$U" | sort | uniq -c | sort -rn | head
  jq -r '.session_id // .sessionId // .ctx.session_id // empty' "$U" | sort -u | head
  jq -r '.eventId // .event_id // empty' "$U" | sort | uniq -d | head
  # 12. Does an update carry _meta.modelId inside params.update?
  jq -c 'select(.params.update._meta.modelId) | .params.update._meta' "$S/updates.jsonl" | head -2
  ```

  Sources consulted (all public, September 2026):

  - [`xai-org/grok-build`, `docs/user-guide/17-sessions.md`](https://github.com/xai-org/grok-build/blob/main/crates/codegen/xai-grok-pager/docs/user-guide/17-sessions.md)
    — the vendor's own description of the session directory: every file name
    above, `updates.jsonl` as "the authoritative conversation log that drives
    `/resume`", `prompt_context.json` as "inputs the system prompt was rendered
    from", `signals.json` as "token usage and tool/turn counters",
    `subagents/` as "per-subagent metadata; child sessions live in the normal
    sessions tree", and "per-turn token and cost totals are available through
    `grok usage`".
  - [tenequm/pond #171](https://github.com/tenequm/pond/issues/171) — an
    adapter built on `updates.jsonl` *because* `chat_history.jsonl` "lacks
    per-row timestamps and undergoes in-place rebuilds"; the envelope shape,
    the chunk-coalescing rule, and correlating tool calls by ACP id.
  - [DrazThan/hermon #105](https://github.com/DrazThan/hermon/issues/105) —
    `tool_calls` as `{id, name, arguments}` "not OpenAI-style wrappers",
    `tool_result` as `{type, tool_call_id, content}`, and percent-decoded
    project directories.
  - [ferraroroberto/app-launcher #1012](https://github.com/ferraroroberto/app-launcher/issues/1012)
    — the envelope verbatim, both `method` spellings, and the kind list
    `user_message_chunk` / `agent_thought_chunk` / `agent_message_chunk` /
    `turn_completed` / `hook_execution`.
  - [princess-pi/wtft #184](https://github.com/princess-pi/wtft/issues/184) —
    `updates.jsonl` as the authoritative parse source, one turn spanning many
    events, and `costUsdTicks` at 10¹⁰ ticks per USD.
  - [telemetry-dev/stats #8](https://github.com/telemetry-dev/stats/pull/8) and
    [BrokkAi/mjolnir #989](https://github.com/BrokkAi/mjolnir/issues/989) — the
    `turn_completed.usage` breakdown recent builds are reported to write.
  - [junhoyeo/tokscale](https://github.com/junhoyeo/tokscale) (commit
    `d8fd670`, `crates/tokscale-core/src/sessions/grok.rs`) — reads that
    breakdown in production and fixes its semantics (`inputTokens` includes
    `cachedReadTokens`, `outputTokens` includes `reasoningTokens`), which is
    what this parser's normalization follows.
  - [paperboytm/spool #512](https://github.com/paperboytm/spool/issues/512) and
    [Ishannaik/agent-sweep #219](https://github.com/Ishannaik/agent-sweep/pull/219)
    — independent confirmation of the directory layout and of
    `{type, content}` records, the latter verified against a real Windows
    install.
  - [AgentWorkforce/burn #489](https://github.com/AgentWorkforce/burn/issues/489),
    via [#167](https://github.com/AgentWorkforce/relayhistory/issues/167) — the
    original format research: no per-turn `input_tokens`/`output_tokens`, a
    `totalTokens` context proxy that decreases on compaction, the models
    `grok-composer-2.5-fast` and `grok-build`, and the tool-name list.

<a id="muse"></a>

- **muse** — Muse Code (Meta's `muse` CLI) keeps one append-only log per
  session at `$XDG_DATA_HOME/muse/sessions/YYYY/MM/DD/<session-id>/session.jsonl`
  (`~/.local/share/muse/sessions/…` when `XDG_DATA_HOME` is unset, on every
  platform). Record interpretation lives in `crates/ai-hist/src/ingest/muse.rs`
  so discovery, sync and hydration read it the same way.

  Every line is an envelope `{id, stream: {kind, id}, sequence, recorded_at,
  payload_type, payload}`, and `recorded_at` is **microseconds** on every
  record, so no time here is inferred. Identity is the `stream.id` of the
  `runtime.session.metadata` record — searched for rather than assumed to be
  line one, because a permission frame can precede it — never the directory
  name. That record also gives `workspace_root` (the `cwd`), `model_id` and
  `build.semver`.

  The conversation is `payload_type: "runtime.session"` with
  `payload.kind: "run"`, keyed by `payload.event.kind`: `started` (the typed
  prompt, one `history` row), `reasoning_committed`,
  `assistant_message_committed`, `assistant_tool_calls_committed` (`args` is a
  JSON *string*), `tool_result_batch_committed`, `model_completed` (per model
  step: `model`, `usage`, `finish_reason`) and `terminal`. `payload.kind:
  "task"` is execution bookkeeping and is not read. A call's outcome is the
  separate `tool_batch.effect.terminal` record, joined by call id; the result
  text carries no error flag of its own. Only records on the session's own
  stream are read: subagent and reminder task streams are mirrored into the
  parent file under a different `stream.id`, and reading them would present
  every child objective as a prompt somebody typed.

  Usage is recorded as Muse wrote it: each `model_completed.usage` object
  (`input_tokens` inclusive of the cached prefix, `cache_read_tokens` /
  `cached_tokens`, `cache_write_tokens`, `output_tokens`, `reasoning_tokens`)
  goes verbatim into `token_json` on the assistant row that step committed,
  with its `model` and `finish_reason`, and normalizes as `per-request`. Muse
  does not write the two in one order — a step that calls tools logs
  `model_completed` *before* its calls, a step that answers in prose logs it
  *after* the reply, and one step can commit readable reasoning and then its
  tool calls. A step is what lies between the model being called and the
  next `started`, `tool_result_batch_committed` or `terminal` in its run; its
  first assistant record owns its usage, in whichever direction the step
  wrote the two. A step that committed
  nothing keeps its usage off every row and is reported as
  `MUSE_USAGE_UNATTACHED`. Only newline-terminated records are read, so a
  live session's half-written last line waits for the next read, and Muse is
  one of the sources the sweep's destination marker guards: rows lost under
  an unchanged stamp are restored by the next `sync`.
  Reasoning Muse kept only encrypted is an `encrypted_reasoning` marker
  (`MUSE_REASONING_ENCRYPTED`).

  A sync or hydration reads the whole file and **replaces** the session's
  local evidence, so a re-read after the log grew adds exactly the new turns
  and duplicates nothing, while a row a remote observation also supplied is
  left to the remote side (see [evidence location](#evidence-location)).

  **Subagents.** Every child agent — a `subagent_spawn` worker, or a reminder
  child when Muse is set to save those — writes
  `subagent/<child-dir>/session.jsonl` beside its parent, and may nest its own
  `subagent/` below that. These are never enumerated as sessions. Reading a
  session reads its whole tree: each child is indexed under the session id
  its **own** metadata record names (never the directory name) and linked to
  its parent as `delegated`, with `spawn_depth`, the parent's
  `task_stream_linked` `display.role` (`worker`, `reminder`, …) as
  `child_agent_type`, its `display.label` as `child_agent_name`, a concrete
  `display.model` (else the child's own `model_id`) as `child_model`, and the
  task id as `evidence_ref`. As for a Codex subagent rollout, a child's
  `history` rows and catalog row are removed — its objective is not a prompt
  anybody typed — and its events stay addressable through the edge
  (`sessions tree`, `related_session_ids`). The change stamp covers every
  child log, so a background subagent that keeps writing after the parent's
  last record is still re-read; a child whose log disappears loses its edge
  and its evidence. A reminder linked by `memory_reminder_child_session_linked`
  but saved only in memory (Muse's default for reminders) has no log and no
  edge. `MUSE_SUBAGENT_LOG_MISSING` reports `subagent_spawn` calls with no log
  to link, and `MUSE_SUBAGENT_LOG_UNIDENTIFIED` a log with no session
  metadata. The shapes were characterized from a transcript
  the real CLI wrote (`tests/fixtures/muse/cli-capture`, from
  [xhluca/session-migrate](https://github.com/xhluca/session-migrate)) and
  cross-checked against the published [Muse Code
  SDK](https://github.com/meta-models/muse-code-sdk) and independent readers.

- **opencode** — **two storage layouts**, because both are in the field.
  RelayHistory prefers `opencode.db` when the host has it and falls back to the
  legacy JSON tree when it does not; it never reads both, because a host that
  upgraded has a stale tree sitting beside a live database.

  | Layout | Location | Environment override |
  |---|---|---|
  | SQLite (current releases) | `~/.local/share/opencode/opencode.db` and every channel database beside it (`opencode-stable.db`, `opencode-nightly.db`, ...) | `OPENCODE_DB` pins one file |
  | Legacy JSON tree (older installs) | `~/.local/share/opencode/storage` | `OPENCODE_STORAGE_DIR` |

  OpenCode writes one SQLite store per release channel: `latest` and `beta`
  use `opencode.db`, every other channel `opencode-<channel>.db` in the same
  directory, and all of them are read (`-wal`, `-shm` and `-journal` sidecars
  are not stores). A session present in more than one store is catalogued,
  synced and hydrated from the first that holds it — `opencode.db`, then the
  channel stores in name order — so it is one session with one `raw_path`.
  Ownership is decided over everything each store holds, including under a
  discovery limit, and hydration refuses a catalogued copy once an earlier
  store holds the session (`SESSION_SOURCE_MISMATCH`; rediscover). A store
  that cannot be opened, or a directory that cannot be listed, is a
  diagnostic against its path; the remaining stores are still read.
  Setting `OPENCODE_DB` names exactly one store and its channel siblings are
  not read; so does `ai-hist sync-opencode --opencode-db <path>`.

  The JSON tree is laid out as `session/<scope>/<sessionId>.json`,
  `message/<sessionId>/<messageId>.json` and `part/<messageId>/<partId>.json`.
  The *payloads* are identical to the `data` columns in the SQLite tables, so
  one normalizer parses both and the evidence a session produces does not
  depend on how it was stored. `crates/ai-hist/tests/opencode_parity.rs`
  asserts that by deriving a JSON tree from the SQLite fixture and comparing
  every row apart from the provenance path.

  A hydrated OpenCode session yields, per assistant message: `session_events`
  of kind `text` for each non-synthetic `text` part, `tool_use` plus a
  `tool_calls` row for each `tool` part (`tool_use_id` = `callID`, `is_error`
  from `state.status == "error"` or `state.metadata.exit != 0`), a
  `tool_result` event from `state.output`, and a `file_edits` row for
  `write`/`edit`/`patch`. Each event carries `model` as
  `"<providerID>/<modelID>"`, `provider` as the bare `providerID`, `token_json`
  as the message's `tokens` object verbatim
  (`{input, output, reasoning, cache:{read, write}}`), and `stop_reason` from
  the message's last `step-finish.reason`. A `compaction` part records a
  `session_markers` row of kind `compaction_boundary`.

  Global sync reads the live store with session-keyed queries and copies
  nothing. The old whole-database `Connection::backup` is now opt-in at both
  compile time (the `opencode-backup` feature) *and* run time
  (`AI_HIST_OPENCODE_BACKUP=1`); on a large store it is hundreds of megabytes
  of I/O for evidence the default path already reads, so it exists only as an
  escape hatch for a provider schema whose indexes make the bounded path slow.

  For the SQLite layout, discovery opens the live store with
  SQLite read-only and `query_only` enforcement, then holds one deferred read
  transaction for the run. Candidate enumeration and every selected-session
  query therefore share one committed SQLite snapshot. In WAL mode OpenCode's
  writer continues normally. Cross-process `SQLITE_BUSY` uses the repository's
  bounded, jittered retry policy (roughly 30 seconds); non-retryable
  `SQLITE_LOCKED` conflicts remain distinct diagnostics. RelayHistory never
  backs up the database or WAL, creates a temporary database, issues provider
  DDL, adds indexes, or runs provider migrations.

  With `--limit N`, one indexed query returns at most N candidate sessions.
  Selected candidates then use the provider's existing `message(session_id,
  …)`, `part(session_id, …)`, or `part(message_id, …)` indexes for prompt and
  model extraction. If those indexes or optional tables/columns are absent,
  discovery still returns session metadata but omits the affected prompt/model
  field rather than scanning a historical table.

  Exact newest-*updated* enumeration uses an existing index ordered by
  `session.time_updated DESC, id ASC`, so the global deterministic tie-break is
  applied before `LIMIT`. Some supported OpenCode schemas do not ship that
  index. On those schemas the bounded safe fallback reads `session` through its
  primary key in ascending order, which matches OpenCode's descending,
  time-encoded generated session IDs and therefore finds newest-created
  sessions. The limitation is that a much older session resumed recently can
  be delayed until OpenCode provides the compound recency index; RelayHistory
  will not mutate the provider database to repair that gap.
- **relay** — a **network** source with no local transcript, and discovery must
  work offline. The adapter therefore derives rows only from `history` rows a
  previous `ai-hist sync` already stored locally; it opens no socket. If nothing
  was ever synced it discovers nothing, which is the correct answer rather than
  a failure. A relay thread has no working directory, so `cwd` is always `null`.

---

## Ordering and limits

The ordering and the limit are **global**, not per provider:

1. Every selected provider adapter in the requested scope enumerates its
   candidates **cheaply** — a directory walk plus `stat`, or one indexed query.
   Database providers may cap their own candidate page at the global limit:
   no single provider can contribute more than that many winners. No file
   content is read.
2. Candidates from all providers are merged and sorted by recency hint,
   descending. Candidates with no recency signal sort last; ties break on
   `(source, locator)` so a run is reproducible.
3. The global `--limit` truncates that merged list.
4. Only the survivors get a bounded shallow read.

So `--limit 3` across two providers returns the three newest sessions
*overall*, not three from whichever provider happened to be enumerated first —
and the cost of a limited request is set by the limit, not by the size of the
archive.

Read budgets per source, so one enormous transcript cannot dominate a run:

| Budget | Value |
|---|---|
| head read | ≤ 256 KB and ≤ 400 complete JSONL records |
| tail read | ≤ 64 KB |
| text excerpt (`first_prompt`) | ≤ 4096 characters |

Files inside the head budget are read once and serve as their own tail. Only
newline-terminated records are parsed: a transcript being appended to right now
has a partial trailing line, and that line is not yet a record.

<a id="pagination"></a>

`sessions list` paginates by recency instead. The catalog's total order is

```sql
ORDER BY last_activity_ms DESC, source ASC, session_id ASC
```

with rows of unknown recency (`last_activity_ms IS NULL`, e.g. a cursor session
whose file has no mtime) last. Recency alone is not a key — one discovery pass
stamps many sessions with the same mtime-derived millisecond — so the cursor
carries the identity columns too:

```jsonc
{"last_activity_ms": 1782039603000, "source": "codex", "session_id": "0198c2ad-codex"}
```

Feed it back as `--after-ms` / `--after-source` / `--after-session-id` (the two
identity flags are required together; omit `--after-ms` to continue through the
undated tail). `--before-ms` still works as a coarse "older than" cutoff, but it
cannot separate rows that share a millisecond, so it is not a paging key; it is
ignored when a cursor is given.

The whole order is carried by `idx_sessions_recency`, or
`idx_sessions_source_recency` when `--source` is given, so a page is an indexed
read with no sort.

---

## Rescans and source stamps

Each connector presence stores a `source_stamp` —
`v{scanner version}:{provider change marker}`:

| Source | Change marker |
|---|---|
| claude, codex, cursor | `{mtime nanoseconds}:{file length}` |
| grok | the chat file's marker, `\|`, the `summary.json` marker, `\|`, the `updates.jsonl` marker, `\|x:`, a digest over `signals.json`, `prompt_context.json` and the sorted entries of `compaction_checkpoints/` and `subagents/` |
| opencode (SQLite) | `{database identity}:{schema version}:{time_created}:{time_updated}` |
| opencode (JSON tree) | `{total bytes}:{file count}:{newest mtime nanoseconds}:{digest}` over the session file, its messages and their parts |
| relay | `{newest synced timestamp}:{synced row count}` |

The OpenCode JSON-tree marker is an aggregate for a reason: the provider
appends a turn by writing *new* files under `message/` and `part/` and does
not touch the session JSON, so a marker over that file alone reports an active
session as unchanged forever. All four components earn their place —
modification time because a birth time cannot see an in-place rewrite, the
file count because a coarse filesystem clock can give an appended turn the
same mtime as the read before it, and the byte total because an in-place edit
can preserve the count. The digest folds each file's name, length and mtime
together with the contents of recently modified files, catching same-length
rewrites that land in the same filesystem clock tick. Discovery and hydration compute it with the same
function, so the catalog and the checkpoint cannot disagree about whether a
session has moved.

On a rescan, a candidate whose stamp matches the stamp for that same location
in `session_presences` is served straight from the catalog: no read, no parse,
`skipped_unchanged` incremented, `from_cache: true` on the emitted row. The
top-level catalog row retains a canonical `source_stamp` summary for backward
compatibility, but connector change detection never relies on that merged
copy. In the benchmark below, a rescan of 450 unchanged sessions performs
**zero** shallow reads.

The `v{N}` prefix is the *scanner* version (`SHALLOW_SCANNER_VERSION`), separate
from `parser_version` (the full-ingest parser generation). Bumping it
invalidates every stored stamp, so a scanner taught to extract a new field
re-reads sources whose bytes never changed. It is at **8**: version 3 shipped
the prompt-only Cursor reader, 4 added that provider's injected turn times,
models and last assistant reply, 5 qualifies OpenCode model IDs with their
provider, 6 derives Claude's `first_prompt` from `ingest::control`, 7
classifies a Codex `guardian_review` thread with a parent as a subagent, and 8
keeps a Codex fork's replayed parent prompt out of its `first_prompt`. Without
these bumps, unchanged sources would keep serving the older
cached shape forever. The cost is one re-read per source, once.

### Transcript byte cursors

Stamps answer *whether* a file changed. They cannot answer *where*, so any
change meant re-reading the whole file — a live Claude session that appends two
kilobytes made relayhistory re-parse every byte written before it, and a fleet
machine's multi-hundred-megabyte transcript made that unaffordable.

Every transcript now carries a **byte cursor**: the offset through which its
database work has committed, the file generation that offset belongs to, and
whatever per-source parser state a resumed pass cannot re-derive from the bytes
it is about to read.

| Where | Key | What it covers |
|---|---|---|
| `session_hydration_checkpoints` / `observation_hydration_checkpoints` | `(source, session_id, location)` | the session's own primary transcript |
| `transcript_cursors` | `(source, locator)` | subagent sidecars, their `agent-*.meta.json`, child Codex rollouts, and the files the global sync walk meets |

Both carry the same four columns. `parser_state_json` is the cursor document
and the source of truth; `committed_offset`, `prefix_hash` and `dev_ino` are
projections of it written in the same statement, so a cursor can be inspected
without parsing JSON. A transcript reached from both directions — hydrated as a
session and also walked by a global sync — holds two independent cursors over
the same bytes. That is deliberate: each is one consumer's own committed
position, and every insert on the path is an idempotent upsert keyed by
provider-native identity, so a region read twice writes the same rows.

A cursor is discarded and the file re-read from zero when

```text
inode changed || mtime < cursor.mtime || size < committed_offset
  || prefix_hash mismatch
```

and the hydration result then carries a `HYDRATION_SOURCE_ROTATED` diagnostic.

`prefix_hash` is **not** the hash of every byte before the offset. It is
SHA-256 over a domain-separated header, the offset itself, the first 64 KiB of
the file and the last 64 KiB before the offset. Hashing the whole prefix would
be stronger, but it costs a read of the entire committed region on every open —
a 200 MB read to discover that one kilobyte arrived, which is the cost cursors
exist to remove. The window catches truncation and regrowth, replacement, a
rewritten head and a rewritten tail. It does not catch an edit strictly between
the two windows that preserves the total length and leaves mtime at or above
the recorded one; no provider in this catalog rewrites a transcript's middle in
place.

### Messages that are still being written

A Claude assistant message is written as several JSONL records over time, one
per content block, and only the last carries a filled-in `stop_reason`. Records
of a message whose `stop_reason` is present and `null` are **held and not
indexed**, and the committed offset backs up to the first byte of the earliest
held message, so the next pass reads it again and indexes it once, complete,
with its usage. The held count is reported as `HYDRATION_IN_PROGRESS_MESSAGES`.

A record with **no** `stop_reason` key at all is treated as finished, not as
streaming: older record shapes and sidechain records omit the field, and
deferring those would hold them back on every pass forever.

Deferral is bounded — 8 MiB or 512 messages held — and past that the oldest
held message is indexed as it stands, reported as
`HYDRATION_IN_PROGRESS_OVERFLOW`. Memory stays bounded and the reader keeps
making progress; the blocks that arrive later land as further rows under their
own record identity rather than as corrections.

Codex has no per-message completion marker, so its cursor commits only at turn
boundaries: the committed offset and parser state advance only at a
`task_complete` record. A turn's token accounting is not final until
the turn is, and committing inside an open turn would freeze a cumulative
baseline mid-turn. The open turn's events are still indexed as they are read —
this is an evidence store, and a live session should be visible before its turn
ends — and re-derived on the next pass from the last committed boundary.

### A record that never got its newline

A transcript's last line may have no `\n`, and nothing in the bytes says
whether that is a record the writer has finished or half of one it is still
writing. The reader used to withhold every such line, which is right for the
second case and silently drops the last record of a complete transcript in the
first — the plugin SDK's 525-record fixture is built with `join('\n')` and
indexed 524.

The rule now: an unterminated trailing record is **indexed if it parses as
complete JSON**, because a half-written line does not. The cursor still
commits past it, so a file nobody has touched compares equal to its cursor and
is skipped outright; `resume_from` in the cursor remembers where that record
began, and if the file later grows the next pass rewinds there and reads it
again rather than resuming after a record it only half saw. Re-reading is
harmless — the row is an idempotent upsert under the same identity.

Codex keeps the older rule and withholds an unterminated line: its rollouts are
newline-terminated, and its cursor already advances only at `task_complete`.

### A message the writer abandoned

Holding a message back is a bet that the provider will finish it. If the file
stops changing the bet has lost, and holding it again on every pass would turn
"deferred" into "lost". A pass that finds the file still where its cursor
left it — same size, same mtime, and a committed prefix that still hashes to
what the cursor recorded — stops deferring and indexes what it held. The hash
is not decoration: a matching size and mtime are not a claim that these are
the same bytes, and a writer that restores timestamps produces a rewrite that
passes the first test and fails the second. A session with records still held is never reported `unchanged`, which is
what lets that pass run at all.

### Identity and metadata resume too

A Claude transcript is walked twice: once for identity and metadata
(`ClaudeMetaFold`), once to index its records. Both resume from the same
cursor document, under separate positions, because the record walk holds
records back for a message still being written and the metadata walk has no
reason to.

They have to resume together. While the metadata walk read the whole file, a
kilobyte appended to a 200 MB transcript still cost a 200 MB read, and
`bytesRead` reported the kilobyte — the shape of a success, computed over one
of the two walks. `bytesRead` is now the total across both.

The same trap caught three more reads, all of them a whole file behind a call
that looked bounded:

| Read | Was | Is |
|---|---|---|
| Codex rollout identity | `read_to_string`, then `lines().next()` | one record from the head |
| Claude sidecar enumeration | every sidecar scanned from byte zero, every hydration | each sidecar's metadata walk resumes from its own cursor |
| A sidecar's first record | `read_to_string`, then `find_map` | a bounded head read |

**Every provider read a hydration cannot avoid is in `bytesRead`.** A counter
that omits one is worse than no counter: it reports the work that was
optimised instead of the work that was done, and the omitted read is exactly
the one nobody is watching. That includes the reads that *find* the related
sessions — each Codex sibling rollout's head record during enumeration, and a
Claude sidecar's head record and metadata document while its evidence is built.

A bounded head read is bounded by a limit on the reader, not by a check
between lines: `read_until` appends until a newline or EOF, so a budget
consulted only before starting another line lets one record the size of the
file allocate the size of the file.

A record is read under a ceiling of its own. `read_until` extends its buffer
until a newline or EOF, so any cap checked *around* the call — the 8 MiB
deferral budget, for instance — can only ever notice an allocation that
already happened. One record over `MAX_RECORD_BYTES` (16 MiB) is drained past
in fixed-size chunks, never held, and reported as
`HYDRATION_OVERSIZED_RECORDS`; a record that large is evidence of corruption
rather than of a long turn.

Record bytes are decoded strictly. `from_utf8_lossy` turns an invalid byte
inside a JSON string into U+FFFD and leaves the syntax valid, so a corrupted
record parsed cleanly and was indexed as though the replacement character were
what the provider wrote. A record that is not valid UTF-8 now takes the same
path as one that is not valid JSON: skipped.

**Releasing deferred records waits out a grace window, not one observation.**
A model pauses between streamed records constantly — thinking, running a tool,
waiting on a network call — and those pauses are routinely longer than the
interval between two hydrations. Releasing on the first pass that sees an
unchanged file therefore fires during ordinary operation and publishes half a
message that nothing will retract. The cursor carries `unchanged_since_ms`,
and records are released only once the file has been still for
`QUIESCENT_GRACE_MS` (two minutes). The asymmetry justifies erring long:
releasing late costs latency on a genuinely abandoned message, releasing early
publishes a partial one.

A cheap "has this changed?" check that compares only size, mtime and inode is
not enough to skip a file. A writer that restores timestamps, or a filesystem
whose clock puts both writes in one tick, produces a rewrite with an identical
stat; the bounded prefix window is validated before a file is skipped, which
costs two seeks and at most 128 KiB and only on files that were about to be
skipped anyway.

A record the reader did not commit does not consume its line index either. The
fallback identity for a record with neither `uuid` nor `message.id` is derived
from that index, so advancing it past a half-written record gave the record a
different identity once it completed than a re-parse from zero would derive —
and the record then existed twice.

### One deferral state machine

Three separate defects turned out to be the same state machine seen from three
sides, so it is written down once:

- **A cursor at offset 0 is still a cursor.** It records the file's identity,
  size and mtime, which is what says whether anything has been appended.
  Reading "offset is zero" as "there is no cursor" meant a pass that held back
  a file's *first* record could never see the file go quiet, and deferred the
  same record forever.
- **An unterminated trailing record goes through the same deferral decision as
  any other record.** Indexing it because it parsed skipped deferral precisely
  at the tail, where a file is most likely to be mid-write.
- **Every transcript that defers gets a pass to release what it held.** The
  session's own cursor is not the only one: each Claude sidecar keeps its
  parser state in its own locator-keyed cursor, and the unchanged shortcut
  consults all of them.

A transcript's two walks share one cursor row, and the record walk never
touches the metadata walk's state — including when the record walk restarts
from zero, because rotation is something the metadata walk detects for
itself.

### What an existing install does on the first sync after upgrading

`HYDRATION_PARSER_VERSION` is 3. A checkpoint written by an earlier generation
has no cursor, and the `claude_sessions*` path → stamp maps that the global sync
walk used are dropped from the sync state file. So the first sync or hydration
after upgrading **reads every transcript once, in full, from offset 0** —
exactly what a stamp-map generation bump always did. From the second pass on,
each file is either skipped on a `stat` and one indexed point query, or resumed
from its cursor.

`codex_rollouts_v5` is deliberately **not** retired. It is the marker for the
selective user-message repair, which is a statement about the parser rather
than about file positions, and it keeps working unchanged beside the cursors.

### `bytesRead`

`hydrateSession` now returns `bytesRead`: what that call actually read from
provider files, across every walk and every file it touched — and, when more
than one source contributed, summed across them rather than taken from
whichever one won the capability rank. About the size of the append for an
incremental pass, the whole file when a cursor was rejected or the parser
generation changed, and small but **not zero** for an `unchanged` one. It is
the number a watch loop reads to tell "the tail grew" from "the whole file was
re-read". `HydrateSessionResult`'s contract version is 3.

Deciding a session is unchanged is not free and does not report as though it
were. Building the stamp reads the Codex root's `session_meta`, one head record
from every sibling rollout, and each Claude sidecar's head and metadata
document; validating the cursors reads two bounded windows per file. Those
bytes are in `bytesRead` on the unchanged path exactly as they are on every
other. A counter that omits the reads a pass could not avoid reports the work
that was optimised instead of the work that was done — and a well-formed zero
is indistinguishable from a pass that really read nothing.

### Skipping a file without reading it

Two places skip a transcript on its stat: the sync walk's
`transcript_unchanged` and targeted hydration's stamp shortcut. Both ask the
same question through `committed_prefix_matches` — are the bytes behind the
cursor still the bytes on disk? — because size, mtime and inode do not prove
byte equality, and a writer that restores timestamps produced a rewrite that
was skipped forever. Neither path advances parser state to answer it, and
hydration pays the window only when the stamp was about to skip the file: a
pass that is going to read the transcript anyway validates the same cursor
inside `TranscriptReader::open`.

### Validating costs provider reads, and they are counted

A pass hashes bounded windows to satisfy itself that the file is the one its
cursor describes: the saved cursor's window and the file's own at `open`, and
the opened region again at `commit` (reused as the stored cursor's hash when
the pass consumed exactly the file it opened). Those are provider reads, so
they are in `bytesRead` like every other — counted inside the digest function,
which is the only place they are spent, rather than added by hand at each call
site. Internally a pass also reports `validation_bytes`, so "how much of this
transcript did we read" and "what did checking it cost" are not one number
hiding the other.

The cost is **bounded by the window, not by the file**: a fixed handful of
digests per walk, each at most 128 KiB, whatever the transcript's size. On the
200 MB transcripts this work exists for it is noise; on a small transcript the
windows can add up to more than the file, which is the accepted trade for a
constant-cost check. A hydration of an unchanged 200 MB transcript reads
kilobytes, not megabytes, and never the file.

### The window is compared on every commit

Not only when the stat moved. A rewrite that preserves length and restores
mtime is exactly the rewrite a stat cannot see — the skip path already assumes
writers do that — so gating the comparison on a moved stat left the one case
nothing else catches free to publish a cursor over stale rows.

### A transcript that moved under any walk is reported

`HYDRATION_SOURCE_REWRITTEN` covers the session's own transcript, its sidecars,
their metadata documents and Codex children, and it covers the metadata walk as
well as the record walk. A pass that recorded no cursor is news; which of the
two walks noticed is an implementation detail.

### The quiescence clock

`unchanged_since_ms` is stamped from the same instant as the size and mtime it
is compared against. A pass stamps it at `open` and re-stats at `commit`, so a
stat that moved during the walk restarts the clock: otherwise the grace window
covered the walk as well, and a full re-parse of a large live transcript — on
its own longer than the window — let the next pass treat a tail that settled
seconds ago as abandoned and release a message that was still streaming.

---

## Concurrency

Discovery deliberately does **not** take the `sync` advisory lock, so a session
picker refreshing itself never has to wait behind a 60-second background sync.

That is safe because every write discovery performs is an idempotent,
stamp-guarded upsert into `sessions`:

- the shallow upsert never nulls a value the catalog already holds, never
  raises `first_activity_ms` above what a fuller pass observed, and never
  downgrades a fully indexed row to `'shallow'` — including a row from a
  database that predates `discovery_state`, whose `NULL` readers interpret as
  `'full'`;
- the full-sync path only ever upgrades a row to `'full'`;
- writes go through the normal busy-retry connection, and the opencode
  provider reads one coherent snapshot from a live read-only connection.

A concurrent `sync` and `discover` therefore converge on the same row rather
than fighting over it.

`sessions list` is classified read-only, so it takes a read-only handle when
the schema is current: it cannot block the writer and cannot be blocked by it.

### Schema

The catalog lives in the existing `sessions` table, extended with
`first_prompt`, `models_json`, `originator`, `agent_version`, `repo_url`,
`initial_commit`, `workspace_roots_json`, `source_stamp` and `discovery_state`,
plus the `idx_sessions_raw_path`, `idx_sessions_recency` and
`idx_sessions_source_recency` indexes — every extra index on `sessions` is one
more btree a discovery upsert must update, so only indexes a query actually
reads exist. A companion
`discovery_skips` table remembers sources already examined and found not to be
sessions (a codex subagent thread, a Claude subagent sidecar), keyed by
`(source, locator)` with the stamp, so a rescan costs a primary-key lookup
instead of re-reading them every run.
Databases created by an older release are migrated in place by a serialized
missing-column check in `init_db`, and `schema_is_current` knows about the new
columns, so a read-only handle over an old database is upgraded instead of
failing with `no such column`.

<a id="evidence-location"></a>

**Evidence location.** Local and remote evidence for one session share its
`(source, session_id)` identity and each table's unique key, so one record is
one row whichever side supplied it. `session_events`, `tool_calls`,
`file_edits` and `session_markers` therefore carry a per-row `location`:
`local`, `remote`, or `both`. A local parser's rows default to `local`, remote
intake (`EvidenceRecord::write`) stamps the observation's location, and an
upsert that meets the other side's row makes it `both`. A side that retires
its evidence — a local whole-session re-read, a remote observation dropping a
record — deletes only the rows it alone backs and hands `both` rows to the
other side, so neither side can remove what the other still evidences. The
column is this database's own bookkeeping: it is not part of any adapter
projection, and is ensured on every open. The `evidence_location_v1` migration
backfills rows written before it existed: a session known *only* remotely was
supplied by remote intake and its rows become `remote`; every other row stays
`local`, which is what a local re-read already assumed of it.

`session_presences` is the location child table. It is keyed by
`(source, session_id, location)`, where `location` is `local` or `remote`, and
is joined to the corresponding `sessions` row by `(source, session_id)`.
Each presence also keeps its connector-specific `raw_locator`, `source_stamp`,
and `discovery_state`, so local and cloud change detection cannot overwrite
one another. Existing identities found in local catalog and evidence tables
are backfilled with a local presence during migration. Scope queries use this
table to select sessions and aggregate their `locations`; they do not duplicate
the session or its events.

`session_events` carries the per-tool-result fidelity columns `tool_use_id`,
`payload_bytes`, `payload_truncated`, `payload_hash`, `call_index`,
`event_index`, `result_status`, `event_source`, `error_signal`,
`subagent_session_id` and `agent_id`, and `session_hydration_checkpoints`
carries `last_tool_result_index`. They are not all TEXT, so they are added by
the `session_events_tool_result_fidelity_v1` marker migration rather than by
the missing-column check that serves the catalog's TEXT columns. The marker is
required, so a database written before this shape is routed through the
writable open instead of being read as current and failing with
`no such column`. Rows indexed before the migration keep their text and report
no measurement.

`session_relationships` is the delegation table, keyed by
`(source, parent_session_id, relationship_uid)`. `relationship_uid` is
`child:<child_session_id>` for an observed child and
`evidence:<evidence_kind>:<evidence_locator>` for unlinked evidence, which
makes repeated ingestion idempotent and gives each unlinked sidecar its own
row. Beside the identity columns (`child_session_id`, nullable, and
`identity_status`) it stores `relationship`, `child_agent_type`,
`child_agent_name`, `child_model`, `spawn_depth`, `evidence_kind`,
`evidence_locator`, `evidence_ref`, `child_has_events`, `spawned_at_ms`,
`created_ms`, and `updated_ms`; re-ingestion refreshes mutable fields and
preserves first-observation time. It is read through
`idx_session_relationships_parent` and `idx_session_relationships_child`;
the sync walk's per-transcript sidecar probe uses
`idx_session_relationships_locator` (`source, evidence_locator`).
Databases written before this shape are rebuilt in place by the
`session_relationships_v2` marker migration, which copies every existing edge
forward as an observed `legacy_hydration` row; the marker is required, so an
unmigrated database is routed through the writable open instead of being read
as current.

---

## Adding a provider

Providers are added **here and nowhere else**. RelayHistory is the single owner
of acquiring, parsing and storing session evidence for every harness;
downstream consumers read it through the `ai-hist` crate's `SessionStore`
facade rather than writing a second parser. See [ADR: relayhistory owns session
sourcing](decisions/2026-09-19-relayhistory-owns-session-sourcing.md). That
matrix has record types as rows and sources as columns, so a new or extended
provider must add or update its source column in the same change, and satisfy
the record types in [`sourcing-contract.md`](sourcing-contract.md).

### One descriptor per harness

Every built-in harness is declared once, as a `LocalSource` descriptor in
[`crates/ai-hist/src/sources/catalog.rs`](../crates/ai-hist/src/sources/catalog.rs).
These per-source tables are derived from it:

| Descriptor field   | Derived from it                                                                    |
| ------------------ | ---------------------------------------------------------------------------------- |
| `id`               | `SOURCE_CHOICES` (declaration order)                                               |
| `discovery`        | `shallow_providers()` (alphabetical by id) and `DISCOVERY_EXEMPTIONS`              |
| `hydration`        | hydration's source validation and the `ingest_selected` dispatch                   |
| `transcript_roots` | `validate_provider_path`, the root check for hydrated and hook-captured locators   |
| `relationships`    | `relationship_capabilities`                                                        |
| `resume`           | `resume_command`                                                                   |
| `fixtures`         | the registry test in `fixture_corpus.rs`                                           |

A new harness starts with:

1. **A descriptor** in `sources/catalog.rs`. Its `discovery` is either a
   `ShallowSessionProvider` adapter (`enumerate` may stat but not read;
   `read_shallow` stays inside the head/tail budgets and returns `Ok(None)` for
   "this candidate is not a session") or `Discovery::Exempt(reason)`. The
   adapter's `evidence_kinds` is the source's declared parser coverage. Its
   `hydration` names the parser for one selected session (a function taking
   `SelectedIngest`), `NoConnector(message)` for a catalog source no local
   parser backs, or `Unsupported`.
2. **A fixture and a snapshot** (below), in the directory the descriptor's
   `fixtures` names, which is the source id.

The descriptor does not yet cover everything. These still need their own
per-source edit:

- the parser itself, the targeted-hydration snapshot branches in
  `source_snapshot` (`hydrate.rs`), and the full-sync pass in `ingest.rs` that
  runs the parser;
- `source_watch_roots` in `ingest.rs`, for anything sync reads beyond the
  adapter's own `watch_roots` (Claude's and Codex's `history.jsonl`,
  trajectory roots);
- the public `Source` enum in `session_store.rs` (`Source::ALL`, `as_str`),
  which is default API; the registry test checks it names exactly the
  descriptors. `Source::capabilities` also adds evidence kinds (session
  markers, prompt history) beyond the adapter's `evidence_kinds`, and states
  each source's message-id origin, by hand;
- `HOOK_HARNESSES`, for a harness whose lifecycle hook hands over a
  transcript path;
- usage normalization (`NORMALIZABLE_SOURCES` and `source_accounting` in
  `usage.rs`), for a harness that reports token usage;
- a `ProviderRoots` field and environment override, if the harness has its own
  root;
- the TypeScript `SOURCES` list, MCP enums and resume command in `sdk-ts`.

Exactly one of the adapter or an exemption is required, so a new source always
carries a decision about whether it is discoverable. Today the only exemption
is `trajectory` ("derived trajectory records, not provider sessions"). It is
enforced at both ends: `sessions discover --source trajectory` fails with that
reason, and `sessions list` filters `trajectory` rows out defensively, so a
trajectory can never be presented as a session.

The exemption list also travels in the `summary` line as `exempt_sources`, so a
consumer can tell "this source has no sessions" apart from "this source is not
discoverable".

A store that holds sessions of an existing source somewhere the built-in parser
does not read needs no change here: a **local source plugin**
(`location: 'local'` with declared `roots`) discovers and hydrates it through
the normalized evidence intake, out of tree. See
[local source plugins](source-plugins.md#local-source-plugins).

### Add a fixture and a snapshot

A provider is not added until its log shape is in the checked-in corpus. Add at
least one fixture under `crates/ai-hist/tests/fixtures/<source>/` (the
directory the descriptor's `fixtures` names), register it in the `CORPUS`
manifest in `crates/ai-hist/tests/fixture_corpus.rs` with the quirk it
encodes, list it in `tests/fixtures/README.md`, and commit the generated
snapshot under `crates/ai-hist/tests/snapshots/<source>/`:

```sh
UPDATE_SNAPSHOTS=1 cargo test -p ai-hist --all-features --test fixture_corpus
```

`every_source_choice_has_a_fixture_or_an_exemption` is the registry test: every
`SOURCE_CHOICES` value is a descriptor, and every descriptor either names a
fixture directory holding at least one staged fixture with a committed
snapshot, or carries a fixture exemption for a source that has no provider log
on disk (`trajectory`, `relay`). `corpus_manifest_covers_every_fixture_file`
and `corpus_readme_lists_every_fixture_and_quirk` stop a fixture from being
added without being described, and `no_orphaned_snapshots` stops a snapshot
from outliving its fixture.

The snapshots are the *current* extraction, gaps included — they are the
review artifact for a parser change, not a statement of intent. Facts a
provider's logs contain that relayhistory does not capture yet are written as
`#[ignore = "closed by #<issue>"]` tests in the same file.

---

## Programmatic access

- **Native (napi)** — `listSessionCatalogPage(options?)` returns
  `{contractVersion, scope, sessions, nextCursor}`;
  `discoverSessions(options?)` runs a shallow scan and returns the rows plus
  the summary. The CLI renders the same collected
  result as JSONL when line-oriented records are more convenient. Both run on
  a blocking worker thread and accept `scope` / `sources` / `limit`, with `beforeMs` and
  `after` (the previous page's `nextCursor`) on the listing.
- **Native (napi), tool-result fidelity** — `getSessionEventsPage(...)` carries
  the columns above on every event; `getSessionUserTurnsPage(source,
  sessionId, options?)` returns one keyset page of user turns, each with the
  ordered `[{kind, toolUseId, byteLen, isError}]` blocks its message carried.
  A block's `isError` collapses five statuses into three states, and keeps
  "known" apart from "not yet known": `true` for `errored` and `cancelled`
  (both terminal, both stated by the provider), `false` for `completed`, and
  `null` only for `running`, `unknown` and rows indexed before the column
  existed. `null` is not "no error" — it is "no answer", and the full
  `result_status` stays on the event for a consumer that needs to tell a
  cancellation from a failure.
  Both are cache-only and derived from `session_events`, so they cannot
  disagree with the transcript. Both reads a page makes — the turn headers and
  each turn's blocks — run inside one deferred read transaction, so a sync
  writing concurrently cannot hand back a header whose blocks have moved or
  vanished behind a cursor that already advanced past it.
  A turn is what arrived on one user message. Each one also names its
  `precedingMessageId` and `followingMessageId` — the nearest messages recorded
  either side of it, from either side of the conversation — so a consumer can
  stitch a turn back into the message stream without re-reading the events.
  Both are `null` only when the session recorded no named message on that
  side; an event the provider left unnamed is passed over rather than nulling
  the field, since it is not a message a consumer could reference and the named
  message behind it still borders the turn. A later block of the same turn is
  never reported as the message that follows it.
  Membership is asserted through `event_source`, never inferred from `role`:
  only `tool_result` means "a block inside a message". A Claude subagent
  notification and a Codex `function_call_output` are both stored with
  `role = 'tool_result'` and both carry their own `message_id`, so grouping on
  role invented turns that never happened — a Codex rollout with one prompt and
  three outputs reported four. Codex has no in-message grouping at all: a Codex
  turn is the prompt alone, and its tool results are read through the event
  APIs, where a standalone result belongs. `approxTokens` is deliberately absent: every
  estimate available here is a bytes-per-token heuristic, and a heuristic
  served beside measured values is indistinguishable from a measurement at the
  call site.
- **Native (napi), markers and capabilities** — through the
  `sessionStoreCall` JSON dispatcher (see
  [architecture](architecture.md)), the SDK reads one keyset page of a
  session's markers — the records the event model cannot carry: compaction
  and summary boundaries, provider `system` rows, non-text content blocks,
  agent lifecycle events — with `getSessionMarkersPage(source, sessionId,
  options?)`, on the same `(tsMs IS NULL, tsMs, id)` order as tool calls and
  file edits, so an undated marker pages last through a null-timestamp
  cursor. `kind` is the classified vocabulary and `subkind` the provider's own
  type; a record no classifier knows is `unknown` with its type intact.
  `getSourceCapabilities(source)` answers, from the provider tables alone,
  the evidence kinds a hydration of that source covers, whether it can ever
  report `full`, and what its records establish about delegation — the same
  table `getSessionRelationships` returns as `capabilities` — so a consumer
  can ask before a first sync.
- **Native (napi), delegation** — `getSessionRelationships(options)` returns one
  session's edges in both directions plus the provider's capabilities;
  `getSessionTree(options)` returns the pre-order descendant tree bounded by
  `maxDepth` / `maxNodes`; `getSessionChildrenPage(options)` returns one keyset
  page of direct children. All three are cache-only, and a missing database is
  an empty result rather than an error — for the tree, the root-only result a
  session with no recorded delegation also returns.
- **TypeScript SDK** — `listSessionCatalog()` / `discoverSessions()` wrap the
  same contract for Node consumers, as do `getSessionRelationships()`,
  `getSessionTree()`, `getSessionChildrenPage()`,
  `getSessionUserTurnsPage()` / `getSessionUserTurns()` / `sessionUserTurns()`,
  `getSessionMarkersPage()` / `getSessionMarkers()` / `sessionMarkers()`,
  `getSourceCapabilities()`, and the `sessionDescendants()`
  / `sessionEventsIncludingDescendants()` iterators; see the SDK's own
  documentation for the exact signatures.
- **MCP** — the stdio server exposes the cache-only listing as a `list_sessions`
  tool, so an agent can enumerate recent sessions without triggering any
  provider I/O, delegation topology as the read-only
  `get_session_relationships` and `get_session_tree` tools, markers as
  `get_session_markers`, and the provider tables as
  `get_source_capabilities`. See the MCP package's documentation for their
  arguments.

Whatever the surface, `contract_version` means the same thing: check it, and
fail loudly on a version you do not know.

---

## Performance validation

The claims above are validated by a benchmark harness rather than by wall-clock
assertions in the test suite:

```bash
cargo test -p ai-hist-cli --test discovery_bench -- --ignored --nocapture
```

It builds a synthetic multi-provider archive in a temp directory, runs both
catalog operations plus a full `ai-hist sync` against it, and prints a
measurement table. Every assertion it makes is an *operation count* — bytes
read, files opened, shallow reads, rows returned — because those hold on any
machine; timings are printed for the reader and never asserted.

Representative multi-provider numbers from one run (debug build,
450-session archive, 14.7 MB):

| Measurement | Result |
|---|---|
| Cached listing, `--limit 20` at 1 000 catalog rows | 0.13 ms |
| Cached listing, `--limit 20` at 20 000 catalog rows + 100 000 history/event rows | 0.13 ms |
| Cached listing, `--limit 2000` at 20 000 rows | 8.6 ms |
| `discover --limit 5` over a 90-session / 6.2 MB archive | 5 shallow reads, 1.6 MB read (26% of the archive) |
| `discover --limit 5` over the same archive grown to 450 sessions / 14.7 MB | 5 shallow reads, **the same 1.6 MB** (11%) |
| `sessions discover` (cold, whole archive) | 11.9 MB read, 450 rows, ~1.7 s |
| `sessions discover` (rescan, nothing changed) | 0 file-backed shallow reads, ~0.08 s |
| `ai-hist sync` (full ingest, same archive) | reads all 14.7 MB, writes 62 451 history/event rows, ~46 s |
| Cached listing after the entire archive is deleted | same 50 rows, 0.41 ms |

The shape is what matters, not the absolute numbers: the cached listing tracks
the rows you asked for and ignores both catalog size and event volume; a
bounded request's cost is fixed by its limit; and a shallow refresh of a whole
archive cost roughly 1/27th of a full ingest of the same archive. OpenCode's
fixed-limit benchmark is documented separately in `benchmarks.md`; its
operation counters stay at 20 candidates, 41 queries, 60 returned records, and
zero claimed bytes for both 1,000- and 10,000-session stores.

Complementary structural coverage lives in the unit tests:
`the_catalog_listing_is_served_by_an_index_not_a_table_scan` (EXPLAIN QUERY
PLAN), `the_catalog_query_reads_only_the_sessions_table`,
`bounded_reads_do_not_grow_with_the_size_of_the_archive`, and
`a_head_read_stays_inside_its_budget_on_a_very_large_transcript`. OpenCode adds
`opencode_selected_session_queries_use_provider_indexes` and the ignored
`opencode_fixed_limit_scaling_report` benchmark.

---

See also: [`getting-started.md`](getting-started.md) (human setup) ·
[`agent-integration.md`](agent-integration.md) (agent-facing surfaces) ·
the `Schema` section of the top-level `README.md`.


### Limited discovery and connector aliases

A limited discovery run is a bounded preview, not a complete inventory of every
connector observation. After its session budget is filled, it may reconcile
additional candidates that explicitly identify an already emitted session. It
does not read every remaining opaque path to discover whether it aliases that
session: doing so would turn a small preview into a full archive scan. Unread
candidates do not withdraw or delete observations from previous scans.

To collect observations from another connector that enumerates opaque paths,
select that connector in a separate discovery call, or run discovery without a
limit. Its observation is then retained independently alongside existing
connectors. The read-budget and source-registry tests cover both behaviors.
