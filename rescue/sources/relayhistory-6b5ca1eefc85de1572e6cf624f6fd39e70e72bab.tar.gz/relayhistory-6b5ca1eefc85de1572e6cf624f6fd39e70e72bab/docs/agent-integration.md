# Agent integration

RelayHistory 1.0 has one production path: the TypeScript SDK, CLI, and MCP
server call the mandatory Rust Node-API engine. Reads are cache-only; provider
I/O happens only when an integration explicitly requests shallow discovery or
full sync.

All collection operations use the same session ledger and a shared scope enum:
`local`, `remote`, or `all`. `local` is the default. Local and remote are
presences of one logical session; `all` is a deduplicated union, not a second
query followed by concatenation.

Use these public operations:

- `listSessionCatalogPage()` / MCP `list_sessions` for bounded cache-only
  session discovery results.
- `discoverSessions()` / MCP `discover_sessions` to refresh shallow provider
  metadata.
- `search()`, `recent()`, `getSession()`, and `getSessionEventsPage()` for
  indexed history reads. `search()`, MCP `search_history` and `ai-hist search`
  share one contract: prompts and session events, filtered by `role`
  (`all`, `user`, `assistant`, `prompt`), with each match's `matchSource`,
  `role` and `kind`. Page them with `searchPage()` / `recentPage()` and the
  returned `nextCursor` (MCP: pass the last row's `timestampMs`, `id` and
  `matchSource` as `after`), and bound them with inclusive `sinceMs` /
  `untilMs`. `beforeMs` is deprecated: it skips rows tied on its timestamp.
- `getSessionRelationships()` / MCP `get_session_relationships` and
  `getSessionTree()` / MCP `get_session_tree` for delegation topology, plus
  the SDK-only `getSessionChildrenPage()`, `sessionDescendants()`, and
  `sessionEventsIncludingDescendants()` for walking large trees. Every event
  keeps the session id of the session that produced it.
- `getSessionToolCallsPage()` / MCP `get_session_tool_calls` and
  `getSessionFileEditsPage()` / MCP `get_session_file_edits` for bounded,
  structured reads of one hydrated session's recorded tool calls and file
  edits. Both name a session by `source` **and** `sessionId`; provider session
  ids collide, and these pages never merge two providers' records.
- `sync()` / MCP `sync` for explicit full local ingestion.
- `createHandoff()` / MCP `create_handoff` and `resumeHandoff()` / MCP
  `resume_handoff` for workspace-scoped agent handoffs.
- MCP `list_relay_agents` to list live Agent Relay participants through the
  local desktop socket. This is presence, not history; it takes optional
  `query`, `where`, and `include_idle` filters and uses no cloud auth.
- MCP `relay_status`, `join_relay`, and `leave_relay` to inspect whether the
  local session hosting the MCP server is reachable, put only that session on the relay (optionally
  with a public name and description), and remove it again. Joining makes the
  session reachable by teammates and agents. These use the same local socket,
  return a non-fatal instruction when desktop is absent, and preserve the
  desktop's `not_allowed` setting guidance.

Pass `scope` to collection operations when the default local view is not
enough. The CLI spelling is the mutually exclusive `--local`, `--remote`, and
`--all` flags. `sessions list`, `search`, `recent`, and `stats` always query the
cached ledger and never contact a provider. Direct `getSession()` and event-page
lookups are identity-based and scope-independent.

Remote discovery and remote sync run through provider connectors
(claude.ai/code web sessions and Codex cloud tasks — see
[Remote connectors](source-plugins.md)). A `remote`-only request on a
machine with no connector configured fails explicitly, and integrations must
surface that error rather than retrying locally; an `all` request runs
whatever is configured and skips remote quietly on absence — `locationsRun`
says what executed. Local sync performs full ingestion; remote sync
refreshes shallow connector rows and `remote` presences, because the remote
listings carry no transcripts. `all` runs local adapters plus every configured
connector. Acquisition result `scope` echoes the request and `locationsRun`
reports which connector locations executed; use session `locations` for
observed presences.

The CLI equivalents are `sessions list`, `sessions discover`,
`sessions hydrate`, `sessions relationships`, `sessions tree`,
`sessions tools`, `sessions edits`, `sessions markers`, `sessions usage`,
`search`, `recent`,
`session`, `events`, `stats`, and `sync`. See
[Session catalog](session-catalog.md) for discovery and pagination contracts
and [Architecture](architecture.md) for the process boundary.

The old cloud push, login, Pair, hook installer, tag, and trajectory convenience
commands were removed in 1.0. They are not available through subprocess or
JavaScript fallbacks; see the [migration guide](native-sdk-migration.md).

## Agent handoffs

`create_handoff(intent)` returns a pointer rather than transcript content. Its
single `intent` field is a complete receiver prompt of this form:

```text
Resume this handoff: call resume_handoff(source=codex, session_id=abc) via the ai-hist MCP, then continue: continue the fix
```

Send that exact value as the Agent Relay DM text and the full pointer as
structured `kind="handoff"` metadata. Do not add a separate message or text
field: the cloud validator requires the DM text to equal the pointer's
`intent`. The receiving agent needs only the prompt and the ai-hist MCP; there
is no handoff skill to install. It calls `resume_handoff` with the embedded
identity and continues the original request using the returned prompts,
events, tool calls, and file edits. If a bounded result has `next_cursor`, pass
that cursor back unchanged for the next page.

Caller intent accepts up to 4,000 characters. Because the generated resume
instruction shares that bound, `create_handoff` keeps the instruction intact
and truncates only an overflowing caller-intent suffix, ending it with `…`.

Before sending the pointer, call `resume_handoff` once yourself as a readiness
check. Agent Relay desktop owns team upload, so this proves the current
workspace can already acquire the session rather than sending a pointer ahead
of its evidence. Resume refreshes the `cloud` connector under the currently
authenticated workspace and rejects cross-workspace or cross-organization
sessions.

## Live capture

Provider transcripts do not live forever. Claude Code cleans up its JSONL
files, so the window in which a session can still be captured losslessly is
bounded — and anything that only learns about a session from a later sweep can
miss that window entirely. Two surfaces close it, and they are complementary:
watch mode notices writes, hooks are told about them.

### `ai-hist watch`

```bash
ai-hist watch                       # fs events, 200ms debounce, 30s backstop
ai-hist watch --debounce-ms 500     # collapse bursts over a longer window
ai-hist watch --interval 30         # polling cadence when fs events are off
ai-hist watch --no-fsevents         # poll only
```

Watch attaches a filesystem watcher to everything a local sweep reads: the
providers' session roots (`~/.claude/projects`, `~/.codex/sessions`,
`~/.codex/archived_sessions`, `~/.cursor/projects`, `~/.grok/sessions`, and the
directory holding the OpenCode database) plus the flat per-harness logs
`~/.claude/history.jsonl` and `~/.codex/history.jsonl` and any `.trajectories`
directory. It then runs one sweep per burst of writes, with a slow poll behind
it. When no root can be watched — a network mount, a container without inotify,
`--no-fsevents` — it falls back to polling at `--interval`.

Startup reports which driver it took **and which roots are not covered yet**. A
root that does not exist cannot be watched, so a provider installed after
`watch` started would otherwise be silently missed; those roots are retried on
every backstop tick, and a loop that started with nothing to watch promotes
itself to filesystem events as soon as one appears. Those retries are on the
*backstop*, not on `--interval`: a `watch --interval 3600` started before a
provider exists picks it up in seconds rather than in an hour, while its
sweeps stay on the hour it was given. Re-deriving the root set is a walk of every project
tree, so it belongs on the backstop and stays there once the watcher is
attached, however short an `--interval` was asked for. Re-checking the
*registrations* is a stat per root, and does not wait for the backstop at all:
a watch the backend reports as lost is re-made when the report arrives, and
retried four times a second until it is back. A directory that is deleted and
recreated — a session's cleanup, then the next session — is otherwise
unwatched for up to the backstop, which is long enough to miss the whole of a
short session. The report arrives while the loop is debouncing more often than
not, so it ends that window and is acted on before the sweep the window was
opening; waiting for the window and then the sweep is the same gap again. The
four-times-a-second retry is per root and lasts only until the roots that were
attached are attached again — a provider that has never been installed stays
pending on the backstop instead of holding the short cadence open for the life
of the run. A root a refresher takes on while its directory does not exist yet
is reported as pending as soon as it is adopted, so `--status` does not claim
coverage the loop does not have. That tick also
re-checks each registration against the directory it was made against — a watch is bound to
the directory object, not to its name, so a root deleted and recreated
(`rm -rf ~/.codex/sessions`, then the next session) has a live name and a dead
watch — and re-registers only the ones that changed. That work is on a
deadline rather than on the tick that found the loop idle: every filesystem
event ends the wait early, so a session writing a few times a second would
otherwise postpone attaching a provider installed beside it for as long as it
kept writing. Every interval the loop takes — `--debounce-ms`, `--interval`,
the backstop — is bounded at seven days where it enters, because a duration
added to an instant panics on a platform that cannot represent the sum, and a
`--debounce-ms` in the billions would otherwise stop capture at the first
change event with no sign that anything was wrong.

A tick that cannot take the store's sync lock has not decided anything about
the change that drove it. Another `ai-hist sync` holding the lock is no
guarantee of cover, because its own source walk may already be past the
provider that just wrote — and a transcript written and cleaned up inside that
window would never be read. Such a sweep is retried 250 ms later and backs off
towards the backstop while the lock stays held; repeated events coalesce into
the one retry, and a sweep that gets through clears it. A forced sweep that
returned an error goes down the same path, for the same reason: a transient
SQLite error or a provider that could not be read is not an answer about the
change, and the wake that carried it has already been consumed.

A root given relatively — `TRAJECTORY_ROOT=trajectory.json` — is resolved
against the working directory when it is built, and every event path is put
through the same resolution before it is matched. Both sides then hold one
spelling: a root that kept a relative name would register successfully, be
reported as watched, and never match the absolute path the watcher reports for
it, so the file would be watched and never seen to change. A root also
remembers what the filesystem says its registration path really is, resolved
once per registration, because the backends disagree: inotify echoes the path
the watch was registered with, while macOS FSEvents always reports the real
one (`/private/var/…`, and the target of any symlink on the way). Either
spelling matches. The backstop also
re-derives the root set, so a project that grows a `.trajectories` directory
mid-run — a root whose *name* could not have been known at startup — is picked
up too.

A root is watched at the depth it asks for: transcript trees recursively,
because a new session is a new file somewhere inside; the directories holding
the flat logs as the single files they are — registered through the parent,
because a watch on the file itself dies with the next atomic rewrite, but
filtered back to the one name so the todo files, shell snapshots and settings
beside them do not each wake a sweep; and a `TRAJECTORY_ROOT`
naming a single JSON file as that one file — registered through its parent,
because an atomic rewrite takes a watch on the file itself with it, but
filtered back down to the one name, since that parent is routinely `$HOME`.
That depth is enforced on the events themselves rather than left to the OS,
because the macOS backend has no shallow mode and delivers the whole subtree
regardless.

A root is reported as *pending* only when a retry is really pending: with
filesystem events off, or unavailable, the loop reports none, because polling
already covers every root at `--interval` and there is no watcher to promote
them to.

`watch --remote` installs no local roots at all. Local provider writes are not
what a remote-only run collects, and letting them drive the loop would fire the
remote connectors on every local keystroke instead of at `--interval`.

Two things make this cheap enough to leave running:

- A tick first folds a **stat-only fingerprint** over everything the sweep
  reads — the transcripts discovery enumerates, the Claude subagent
  `agent-*.meta.json` sidecars beside them, the two flat logs, the trajectory
  records, and a generation for the imported Relay rows, which have no file to
  stat but still change. If it matches the previous sweep's, the tick returns
  without opening a single file. Anything the sweep reads has to be in that
  fold: a source left out would sit behind an unchanged fingerprint and never
  be read again. The value is recorded in `.sync-state.json` beside the
  database, after the sweep's cursors, and only when every source was read —
  including the per-file failures a provider absorbs on its way to a
  successful partial run. A file that could not be read this tick keeps the
  fingerprint stale so the next tick retries it, rather than caching the
  failure in place. Discovery's per-file failures are counted the same way:
  it reads the same files, and its failures are non-fatal, so a candidate it
  could not read must not be checkpointed as one it did. The value is qualified by the sweep's own parser and
  scanner generations, so a stamp written before an upgrade that bumps one
  cannot skip the re-read that bump exists to force.
- A sweep owes more than ingestion — it also repairs a session whose per-file
  stamp matches but whose evidence is gone. So the stamp is paired with a
  **destination generation** recorded after the sweep, one entry per session:
  if a session holds less than it did, the next tick sweeps instead of
  skipping and that session is re-ingested, however unchanged the sources
  look. A finished rollout's bytes never move again, so without this the loss
  would be permanent. Per session rather than in total, because totals cannot
  tell a loss from a coincidence — one row deleted here and one inserted there
  leaves every total intact. Rows arriving between sweeps — the hook fast
  path, hydration — are growth rather than loss and still skip. The marker
  covers only what a sweep can put back: Claude transcripts and Codex
  rollouts, re-read when their session is short — a delegated subagent too,
  reached by its own id through the sidecar's relationship rather than through
  a catalog row it deliberately never has. Each entry covers that session's
  events, tool calls, file edits and catalog row, since the same re-read
  restores all four. `history` rows are
  deliberately outside it — they come from cursor-backed flat logs sitting at
  EOF, which nothing replays, so counting them would disarm the fast path
  forever over a loss no sweep could undo. And a loss the sweep could *not*
  restore leaves the marker and the fingerprint stale: every tick keeps
  sweeping, loudly, rather than recording the shortfall as the new truth.
- A tick woken by a filesystem event **forces** the sweep past that
  fingerprint. An event can arrive before the write is flushed, so the size and
  mtime it would be compared against are not yet trustworthy. The polling
  backstop does not force, so a quiet machine keeps paying only the fingerprint
  walk.

`ai-hist import --watch` remains an alias for the same loop with the defaults.

### `ai-hist ingest --hook claude`

```bash
echo '{"session_id":"…","transcript_path":"/path/to/session.jsonl"}' \
  | ai-hist ingest --hook claude --quiet
```

Reads one Claude Code hook payload from stdin and hydrates exactly the
transcript it names, instead of sweeping every provider root. The path is
checked against Claude's own root before it is read — a hook payload comes from
another process, and an arbitrary path must never become an ingest target.

The payload makes *two* claims — which session fired, and which file holds it —
and both are checked against each other. A delayed, replayed or malformed hook
can pair a live `session_id` with a file belonging to another session; the
transcript's own identity is read before anything is written, and a
disagreement is reported as `mismatched` with nothing ingested, rather than
attributing the lifecycle event to a session it did not come from.

**The command always exits 0.** A hook runs inside the agent's tool call, and a
non-zero exit there fails that tool call. A missing or rotated transcript, an
unparseable payload, a locked database: all are reported on stderr and shrugged
off. `--quiet` silences the reporting, not the shrug. A payload without
`transcript_path` (some releases elide it) falls back to a forced full sweep.

Pass `--json` for a machine-readable report on stdout. **`--quiet` outranks
`--json`**: given both, the command prints nothing at all. A hook told to stay
out of the way must not write a JSON document into the stdout of every tool
call; use `--json` on its own when you want to read the report.

### Wiring the Claude Code hooks

In `~/.claude/settings.json`, or a project's `.claude/settings.json`:

```json
{
  "hooks": {
    "SessionStart": [
      {
        "hooks": [
          { "type": "command", "command": "ai-hist ingest --hook claude --quiet" }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "*",
        "hooks": [
          { "type": "command", "command": "ai-hist ingest --hook claude --quiet" }
        ]
      }
    ],
    "Stop": [
      {
        "hooks": [
          { "type": "command", "command": "ai-hist ingest --hook claude --quiet" }
        ]
      }
    ],
    "PreCompact": [
      {
        "hooks": [
          { "type": "command", "command": "ai-hist ingest --hook claude --quiet" }
        ]
      }
    ]
  }
}
```

`PreCompact` is the one that watch mode cannot replace. Compaction **rewrites
the transcript in place**, and the hook fires *before* that rewrite — it is the
last moment the pre-compaction records still exist on disk. A sweep arriving
afterwards sees only the compacted file, and the earlier evidence is gone for
good. Keep that entry even if you drop the others.

`SessionStart` and `Stop` bracket the session; `PostToolUse` captures tool
errors as they happen rather than after the fact. Re-running any of them over
an untouched transcript is free: hydration compares the source stamp first and
reports `unchanged` without re-reading.

### Codex, OpenCode, Cursor and Grok

Only Claude Code exposes a transcript lifecycle hook to attach to. Codex writes
`~/.codex/sessions/**/rollout-*.jsonl` with no hook surface; OpenCode writes a
SQLite database and exposes none either; Cursor and Grok likewise. For those
providers watch mode *is* the live-capture path — their roots are watched, and
an append wakes the same sweep. `ai-hist ingest --hook <other>` reports the
harness as unsupported and exits 0 rather than pretending. When any of them
grows a lifecycle hook, the payload shape is the only new part: the
single-transcript ingest underneath is provider-agnostic.
