# Release and platform validation

One workflow releases everything: `Publish RelayHistory release`
(`.github/workflows/publish.yml`; the file name is bound to npm OIDC
trusted publishing and must not change -- see "Renaming this workflow" below). All public packages share one version:
the `ai-hist` npm package, `ai-hist-native`, each native platform package, `ai-hist-mcp`,
`@relayhistory/provider-sources` and its
seven platform helper packages, and the `ai-hist` crates.io crate. The SDK checks the current native contract
version at initialization; both halves declare it in source (`sdk-ts/src/native.ts`
and `crates/ai-hist-napi/src/lib.rs`).

## Inputs

| Input            | Default | Meaning                                                             |
| ---------------- | ------- | ------------------------------------------------------------------- |
| `version`        | `patch` | Bump type computed from the highest published core version on npm.  |
| `custom_version` | empty   | Exact version; overrides the bump type.                             |
| `dry_run`        | `false` | Build and validate everything, publish nothing, push nothing.       |
| `plugins`        | `true`  | Also publish the optional history plugins at the same version.      |
| `skip_core`      | `false` | Re-run only plugins for an already published `custom_version`.      |

## What happens, in order

1. `version` resolves the release version once, before anything is built: the
   bump type applied to the highest published core version on npm, or
   `custom_version`. Every other job takes the version from here, because the
   helper matrix has to stamp it into the Rust crates it compiles.
2. `build` builds and tests the native addon on all seven targets, and
   `helpers` builds the provider-sources helper for seven platforms, verifying
   each executable and its glibc floor. `helpers` applies
   `scripts/set-release-version.mjs` first, so the executables report the
   release version. Both jobs run in parallel and upload binaries as artifacts.
3. `publish` applies that version to every manifest and lockfile — the core
   packages and, whatever the `plugins` input, the plugin manifest
   and plugin crate via `scripts/set-release-version.mjs`, so the tag
   always carries what the helper matrix built from — prepares the
   version-only commit, then
   publishes the platform packages,
   `ai-hist-native`, `ai-hist` and `ai-hist-mcp` in that order. The SDK root is
   never published before its platform artifacts, because npm multi-package
   publication is not atomic.
4. `publish-crate` publishes the `ai-hist` crate to crates.io at that same
   version via GitHub OIDC trusted publishing. `rust-lang/crates-io-auth-action`
   exchanges the workflow's OIDC identity for a short-lived crates.io token and
   passes it as `CARGO_REGISTRY_TOKEN` to `cargo publish`. There is no
   long-lived crates.io secret. If the version already exists, the job skips
   rather than failing. `dry_run` runs `cargo publish --dry-run -p ai-hist` and
   publishes nothing. A crates.io-only retry uses `skip_core` with the
   already-published `custom_version`; the job checks out `sdk-ts-v<version>`
   and publishes the crate from that tag.
5. On a real publish, before building and again immediately before publishing,
   the workflow checks for an existing recovery tag. A tagged version must be
   resumed with `skip_core` and its `custom_version`, even if npm still
   returns 404 while processing it. `publish` also checks whether the release
   version became visible on npm while the build matrix ran. Once all npm publish commands
   succeed, it tags the published tree as `sdk-ts-v<version>`. `verify-core`
   waits up to 70 minutes for npm's processing queue, then runs the clean registry
   install and older-glibc CLI smoke tests. `finalize-core` creates the GitHub
   Release only after those tests pass. A separate `persist-version` job rebases
   the version-only commit onto the current branch tip and pushes, so a merge
   that landed during publish does not drop the tag. Crate and plugins depend
   on the verified core, not on that persist. If npm accepts a publish but keeps
   its version in processing beyond the wait, or a later gate fails, rerun with
   `skip_core` and this `custom_version` once npm exposes the packages. The
   tag preserves the exact tree without republishing immutable versions. The
   registry smoke installs `ai-hist` as an ordinary dependency with npm's
   `--libc` set to this runner's family so `ai-hist-native-linux-x64-gnu`
   (or musl) is selected.
6. `plugins` checks out the tagged published tree, packages each helper binary at
   the release version, verifies staged tarballs, verifies the *published* core
   at each plugin's peer minimum, then publishes the seven helpers of each
   plugin before its JavaScript package. Post-publish verification waits for
   all 8 exact-version manifests to become visible on npm, then installs the
   JavaScript packages as ordinary dependencies with npm's `--libc` set to this
   runner's family (`glibc` or `musl`) so the matching platform helper is
   selected, and loads the plugins. Missing versions (`E404`/`ETARGET`) are
   retried up to 60 times, five seconds apart; other lookup errors or invalid
   metadata fail immediately. Exhausted retries include npm's original error
   output.

`scripts/set-release-version.mjs <version>` is the only place that knows what a
plugin release version touches (version, the seven helper pins, the `ai-hist`
peer range `^<version>`, the lockfile coordinates, and the `[package]` version
of each plugin's Rust crate plus that crate's own `Cargo.lock` entry — the
helper executable reports `CARGO_PKG_VERSION`). It is idempotent, and
the helper matrix, the version commit and the plugin job all run it, so what was
compiled, what was committed and what is published cannot diverge.

## Rust crate

The published crate is `ai-hist` on crates.io. It shares the npm version line,
so `sdk-ts-v0.18.8` is also `ai-hist@0.18.8` on crates.io. `ai-hist-cli` and
`ai-hist-napi` stay unpublished workspace members (`publish = false`).

Cargo semver is the Rust contract — there is no separate Rust contract-version
constant. Any change to a public struct field, enum variant, or behaviour a
consumer observes is a minor bump pre-1.0 and gets a `### Rust API` entry in
`CHANGELOG.md`. Default features expose `SessionStore`, evidence structs,
`Source`, and `Error`. Optional features (`delivery`, `opencode-backup`,
`git-hooks`, `unstable-internal`) stay off for embedders.

```bash
cargo add ai-hist
```

```rust
use ai_hist::{SessionQuery, SessionStore};
let store = SessionStore::open(Default::default())?;
let report = store.sync(Default::default())?;
for changed in &report.changed {
    let _evidence = store.session(changed, SessionQuery::default())?;
}
```

The full surface is documented in the embedder guide, [`sourcing-sdk.md`](sourcing-sdk.md).

### Public API snapshot

`crates/ai-hist/public-api.txt` is the crate's default-feature public API as
`cargo public-api` lists it, with blanket, auto-trait and derived impls
omitted. The `public-api` CI job regenerates the listing on a nightly toolchain
and fails on any difference, and fails separately if any line names a
`rusqlite` type. A change to the surface therefore ships with

```bash
cargo install cargo-public-api --locked   # once; needs a nightly toolchain for rustdoc JSON
node scripts/check-public-api.mjs --update
```

and a `### Rust API` changelog entry in the same pull request. The snapshot is
what a reviewer reads to see the contract move; the changelog entry is what an
embedder reads before bumping.

### The out-of-tree consumer

`examples/rust-consumer` is a standalone Cargo project (its own lockfile,
excluded from the workspace) that depends on `ai-hist` from crates.io. The
`rust-consumer` CI job builds it on every pull request with `[patch.crates-io]`
redirected at `crates/ai-hist` and asserts the patch was actually applied; the
`Published crate consumer` workflow (`published-crate-consumer.yml`, nightly
and on dispatch) builds it against the crate crates.io serves, which is the
only check that sees a broken publish.

`scripts/set-release-version.mjs` stamps the example's `ai-hist = "<version>"`
requirement and its lock entry along with everything else, dropping the
previous tarball's checksum for Cargo to refill. Without that, the first
release after a minor bump would leave the pull-request patch silently unused
and the nightly job on the previous release.

## Dry runs

Leave `dry_run` enabled to build, verify and stage everything without
publishing, pushing a commit, creating a Release or attaching assets. The
plugin job applies the release version to its own checkout and prints the
staged tarballs. Dry runs never change the checked-in version baseline.

## Re-running plugins alone

Set `skip_core` with an explicit `custom_version` equal to an already published
core version. `build` and `publish` are skipped. `version` verifies that the
`sdk-ts-v<version>` tag exists before anything builds, and every job that builds
or packages (`helpers`, `plugins`) checks out **that tag**, not the commit the
run was dispatched from — otherwise a re-run would publish newer code under an
older version. Plugin manifests are re-derived from the tag.

Because the re-run builds from the tag, it only works for releases cut by this
workflow: a tag whose tree predates these scripts fails loudly at checkout or
build time rather than shipping something mismatched.

## Claiming a new package name

npm OIDC trusted publishing can publish a new *version* of a package that
already exists, but it cannot *create* a name. This workflow is tokenless, so a
name's very first publish fails:

```
npm error code E404
npm error 404 Not Found - PUT https://registry.npmjs.org/@relayhistory%2fprovider-sources-darwin-arm64
npm error 404 The requested resource '@relayhistory/provider-sources-darwin-arm64@0.18.3'
              could not be found or you do not have permission to access it.
```

The name must exist once, published from a human npm account; CI owns it after
that. This applies to every name a release publishes — each plugin and each of
its per-platform helpers — so **adding a plugin or a supported platform means
claiming its names before the next release**.

From the repository root, signed in to npm:

```bash
node scripts/claim-plugin-package-names.mjs --dry-run   # what is missing
node scripts/claim-plugin-package-names.mjs             # claim it
```

It publishes a placeholder, not the real package: the platform helpers each
carry a cross-compiled binary for their target, so no one machine can build them
all. The real artifacts come from the release that follows.

Placeholders are published at `0.0.0`. A version publishes exactly once, so
claiming a name at a release version would fail the next release with
`EPUBLISHCONFLICT`. `0.0.0` is below every release, is transparently not a real
build, and never resolves — each plugin pins its helpers to its own exact
version, so nothing asks for `0.0.0`.

The script reads names from `scripts/history-package-contract.mjs`, skips
anything already on the registry, and is safe to re-run.

## Renaming this workflow

Don't, unless you are prepared to repoint every package. npm OIDC trusted
publishing binds a package to a repository **and a workflow file name**. Rename
the file and every package whose trusted publisher still names the old file
fails its next publish with:

```
npm error code E404
npm error 404 The requested resource '<package>@<version>' could not be found
              or you do not have permission to access it.
```

That message reads as "no such package". It is npm declining to say whether a
package exists, and the real cause is authorization. **A name that plainly
exists, failing with E404, means the trusted publisher does not match the
workflow that is asking.**

This file was `publish-napi.yml` until the optional plugins were first
published. Every other AgentWorkforce repository publishes from `publish.yml`,
and the mismatch cost a release cycle: the plugins' trusted publishers were set
to `publish.yml` by analogy with the sibling repos, and the E404 that followed
was read as a missing package rather than a wrong workflow name.

If it has to change again, the cutover is not atomic, and the order is:

1. Rename the file and merge, with no release in flight.
2. Repoint every package's trusted publisher to the new file name.
3. Release.

Between 1 and 2 nothing can publish, so keep the gap short. Every package this
workflow publishes is listed at the top of this document.

## Supported matrix

- Node.js: minimum 20; tested 20 and 22.
- Node-API: level 4.
- macOS: 12+, arm64 and x64.
- Linux: glibc and musl, arm64 and x64.
- Windows: Windows 10/11 and Server 2022, x64 MSVC.
- Windows arm64: unsupported until an executable CI test is reliable.

To validate a local artifact:

```bash
cargo test --workspace
cd crates/ai-hist-napi && npm ci && npm run build:debug
node -e "const n=require('./index.js'); console.log(n.nativeContractVersion())"
cd ../../sdk-ts && npm install && npm test && npm pack
```
