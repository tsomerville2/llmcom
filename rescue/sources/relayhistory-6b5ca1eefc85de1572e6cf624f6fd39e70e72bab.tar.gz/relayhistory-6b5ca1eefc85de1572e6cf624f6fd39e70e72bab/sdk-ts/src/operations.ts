import { normalizeHydration } from './normalization.js';
import {
  discoverSourcePlugins,
  hydrateSourcePlugin,
  getSourceObservation,
  camelSourceResult,
  sourceAcquisitionTimeout,
  throwIfSourceAborted,
  sourceConnectorsInScope,
} from './source-plugins.js';
import type { HistoryPluginRegistry } from './delivery-plugins.js';
import type { HistorySource } from './source-contracts.js';

/** The most rows one catalog page returns; native rejects a larger limit. */
const CATALOG_PAGE_MAX = 1000;

/**
 * The scope an acquisition runs installed source plugins at, or `null` when it
 * runs none and the native engine answers alone.
 *
 * `remote` and `all` run the selected plugins, as they always have. `local`
 * (and the default, which is local) runs only `local` connectors, and only
 * when one is registered and not deselected: a request that never asked for a
 * plugin keeps the pure native path, and a remote connector is never invoked
 * for a local request. Deselection here never throws for an unknown id,
 * because local scope ignored `sourceConnectors` before local plugins existed.
 *
 * A local connector that supports none of the requested `sources` is not
 * selected either: it has nothing to add, and selecting it would turn a
 * source filter it does not cover into a request that fails after the native
 * pass already answered. Remote connectors keep their existing selection.
 */
function pluginScope(
  plugins: HistoryPluginRegistry | undefined,
  scope: SessionScope | undefined,
  ids: readonly string[] | undefined,
  sources?: readonly CatalogSource[],
): { scope: SessionScope; selected: HistorySource[] } | null {
  if (!plugins) return null;
  const covers = (connector: HistorySource) =>
    connector.location !== 'local' ||
    sources === undefined ||
    connector.supportedSources.some((source) => sources.includes(source));
  if (scope === 'remote' || scope === 'all') {
    return { scope, selected: sourceConnectorsInScope(plugins, ids, scope).filter(covers) };
  }
  const selected = plugins
    .sourceConnectors()
    .filter(
      (connector) =>
        connector.location === 'local' &&
        covers(connector) &&
        (ids === undefined ||
          ids.includes(connector.id) ||
          ids.includes(`${connector.id}:${connector.instanceId}`)),
    );
  return selected.length ? { scope: 'local', selected } : null;
}
/**
 * RelayHistory's public TypeScript API.
 *
 * Every production operation crosses one mandatory Node-API boundary into the
 * Rust engine. This module owns only input defaults, object normalization,
 * re-exports of local contracts.
 */

import { nativeCall, sessionStoreCall, SESSION_STORE_OPS } from './native.js';
import {
  SESSION_CATALOG_CONTRACT_VERSION,
  SESSION_HYDRATION_CONTRACT_VERSION,
  SESSION_RELATIONSHIP_CONTRACT_VERSION,
  SESSION_EVIDENCE_CONTRACT_VERSION,
  SOURCES,
  FULL_SESSION_KINDS,
  defaultDbPath,
  Source,
  CatalogSource,
  CATALOG_SOURCES,
  isCatalogSource,
  SessionScope,
  SessionLocation,
  NativeContractMismatchError,
  InvalidArgumentError,
  RelayHistoryError,
  ConnectorNotConfiguredError,
  SessionNotFoundError,
  SessionSourceUnavailableError,
  SessionSourceMismatchError,
  HydrationUnsupportedError,
  HydrationFailedError,
} from './sdk-common.js';

export * from './sdk-common.js';
export * from './delivery.js';
export * from './history-export.js';
export { NATIVE_CONTRACT_VERSION, runtimePlatform, validateNativeContract } from './native.js';
export * from './git.js';

export * from './contracts.js';
import type {
  HistoryEntry,
  HistoryPage,
  SearchMatch,
  SearchPage,
  ListOptions,
  SearchOptions,
  SessionOptions,
  CatalogCursor,
  CatalogSession,
  ListCatalogOptions,
  SessionCatalogPage,
  DiscoveryDiagnostic,
  ProviderDiscoverySummary,
  DiscoveryCounters,
  SourceExemption,
  SourceConnectorOptions,
  DiscoverSessionsOptions,
  DiscoverResult,
  SessionRef,
  HydrateSessionOptions,
  HydrationDiagnostic,
  HydrateSessionResult,
  SessionEvent,
  EventCursor,
  EventsPageOptions,
  SessionEventsPage,
  RelationshipType,
  IdentityStatus,
  StableChildIdentity,
  SessionRelationship,
  RelationshipCapabilities,
  RelationshipDiagnostic,
  GetSessionRelationshipsOptions,
  SessionRelationships,
  SessionTreeNode,
  GetSessionTreeOptions,
  SessionTree,
  RelationshipCursor,
  SessionChildrenPage,
  GetSessionChildrenPageOptions,
  SessionDescendantsOptions,
  DescendantEventsOptions,
  JsonValue,
  SessionToolCall,
  SessionFileEdit,
  EvidenceCursor,
  EvidenceCursorInput,
  EvidencePageOptions,
  SessionToolCallsPage,
  SessionFileEditsPage,
  NormalizedUsage,
  UsageAccounting,
  SessionRequest,
  RequestCursor,
  RequestPageOptions,
  SessionRequestsPage,
  SessionUsage,
  SessionUsageOptions,
  UserTurnsPageOptions,
  SessionUserTurnsPage,
  SessionMarkersPage,
  SourceCapabilities,
  ChangesPage,
  ChangesPageOptions,
  CommitChangesOptions,
  CommittedCursor,
  Watermark,
  Stats,
  StatsOptions,
  SyncOptions,
  SyncResult,
} from './contracts.js';

import {
  UnknownRecord,
  RELATIONSHIP_TYPES,
  DEFAULT_TREE_MAX_DEPTH,
  MAX_TREE_MAX_DEPTH,
  DEFAULT_TREE_MAX_NODES,
  MAX_TREE_MAX_NODES,
  nullableString,
  historyEntry,
  historyCursor,
  nativeHistoryCursor,
  searchMatch,
  catalogCursor,
  catalogSession,
  validateNativeLocation,
  validateNativeScope,
  assertCatalogContract,
  tokenUsage,
  sessionEvent,
  assertRelationshipContract,
  parseStoredJson,
  nullableNumber,
  nullableBoolean,
  sessionToolCall,
  sessionFileEdit,
  sessionUserTurn,
  evidenceCursor,
  nativeEvidenceCursor,
  assertEvidenceContract,
  assertUsageContract,
  normalizedUsage,
  usageAccounting,
  usageDiagnostics,
  sessionRequest,
  requestCursor,
  sessionMarker,
  sourceCapabilities,
  changesPage,
  committedCursor,
  catalogSource,
  relationshipType,
  identityStatus,
  stableChildIdentity,
  relationship,
  relationships,
  relationshipCapabilities,
  relationshipDiagnostics,
  treeNode,
  relationshipCursor,
  validateSessionRef,
  evidenceIdentity,
  combineHydration,
} from './normalization.js';
export { validateNativeLocation, validateNativeScope, parseStoredJson } from './normalization.js';

export async function nativeBuildProfile(): Promise<string> {
  return nativeCall(async (native) => native.nativeBuildProfile?.() ?? 'unknown');
}

/**
 * Full-text search over indexed prompts and session events: the same
 * contract, filters and `(timestampMs, id)` order as `ai-hist search`. Each
 * match says where it was found (`matchSource`) and, for an event, its `role`
 * and `kind`.
 */
export async function search(query: string, options: SearchOptions = {}): Promise<SearchMatch[]> {
  const scope = options.scope ?? 'local';
  return nativeCall(async (native) =>
    (await native.search(query, { ...options, scope, after: nativeHistoryCursor(options.after) })).map(searchMatch),
  );
}

/**
 * One page of `search`. Pass the returned `nextCursor` back as `after` to
 * continue; it is `null` once no further match exists. Pages never skip or
 * repeat a match among rows present for the whole walk; rows committed
 * meanwhile appear wherever their `(timestampMs, id)` places them.
 */
export async function searchPage(query: string, options: SearchOptions = {}): Promise<SearchPage> {
  const scope = options.scope ?? 'local';
  return nativeCall(async (native) => {
    const page = await native.searchPage(query, { ...options, scope, after: nativeHistoryCursor(options.after) });
    return {
      matches: Array.isArray(page.matches) ? page.matches.map(searchMatch) : [],
      nextCursor: historyCursor(page.nextCursor),
    };
  });
}

export async function recent(options: ListOptions = {}): Promise<HistoryEntry[]> {
  const scope = options.scope ?? 'local';
  return nativeCall(async (native) =>
    (await native.recent({ ...options, scope, after: nativeHistoryCursor(options.after) })).map(historyEntry),
  );
}

/** One page of `recent`, with the same cursor contract as `searchPage`. */
export async function recentPage(options: ListOptions = {}): Promise<HistoryPage> {
  const scope = options.scope ?? 'local';
  return nativeCall(async (native) => {
    const page = await native.recentPage({ ...options, scope, after: nativeHistoryCursor(options.after) });
    return {
      entries: Array.isArray(page.entries) ? page.entries.map(historyEntry) : [],
      nextCursor: historyCursor(page.nextCursor),
    };
  });
}

export async function getSession(
  sessionId: string,
  options: SessionOptions = {},
): Promise<HistoryEntry[]> {
  return nativeCall(async (native) =>
    (await native.getSession(sessionId, options)).map(historyEntry),
  );
}

export async function listSessionCatalog(
  options: ListCatalogOptions = {},
): Promise<CatalogSession[]> {
  return (await listSessionCatalogPage(options)).sessions;
}

export async function listSessionCatalogPage(
  options: ListCatalogOptions = {},
): Promise<SessionCatalogPage> {
  const scope = options.scope ?? 'local';
  // An empty or whitespace-only key is never a real project and would match
  // nothing; failing loudly beats returning a well-formed empty page that
  // reads as "this project has no sessions".
  if (options.projectKey !== undefined && options.projectKey.trim() === '') {
    throw new InvalidArgumentError(
      'projectKey must not be empty',
      'INVALID_ARGUMENT',
    );
  }
  return nativeCall(async (native) => {
    const page = await native.listSessionCatalogPage({
      ...options,
      scope,
      after: options.after
        ? {
            ...options.after,
            lastActivityMs: options.after.lastActivityMs ?? undefined,
          }
        : undefined,
    });
    const contractVersion = Number(page.contractVersion);
    assertCatalogContract(contractVersion);
    return {
      contractVersion,
      scope: validateNativeScope(page.scope),
      sessions: Array.isArray(page.sessions)
        ? (page.sessions as UnknownRecord[]).map(catalogSession)
        : [],
      nextCursor: catalogCursor(page.nextCursor),
    };
  });
}

export async function discoverSessions(
  options: DiscoverSessionsOptions = {},
): Promise<DiscoverResult> {
  validateAcquisition(options);
  const sourceConnectors = validateSourceConnectors(options.sourceConnectors);
  const plugins = pluginScope(
    options.plugins,
    options.scope,
    options.sourceConnectors,
    options.sources,
  );
  if (options.plugins && plugins) {
    const { scope, selected } = plugins;
    const local =
      scope !== 'remote'
        ? await discoverSessions({
            ...options,
            plugins: undefined,
            scope: 'local',
            sourceConnectors: [],
          })
        : null;
    if (!selected.length && local) return { ...local, scope };
    const failures: DiscoveryDiagnostic[] = [];
    let sourceFailure: RelayHistoryError | undefined;
    const runs = await discoverSourcePlugins(options.plugins, {
      ...options,
      scope,
      sourceConnectors: selected.map((connector) => `${connector.id}:${connector.instanceId}`),
      onUnavailable: (source, error) => {
        sourceFailure ??= error;
        failures.push({ source, locator: null, error: `${error.code}: ${error.message}` });
      },
    });
    if (!runs.length && !local)
      throw sourceFailure ?? new ConnectorNotConfiguredError(
        'No selected source plugin is available',
        'CONNECTOR_NOT_CONFIGURED',
      );
    // Native discovery returns every session it saw when no limit is given,
    // and up to its 1-10000 acquisition limit when one is. The catalog read
    // that stands in for it pages at most CATALOG_PAGE_MAX rows, so follow the
    // cursor to the requested count (or the end) rather than passing an
    // acquisition limit the catalog would reject.
    const sessions: CatalogSession[] = [];
    const pageLimit = () =>
      options.limit === undefined
        ? undefined
        : Math.min(options.limit - sessions.length, CATALOG_PAGE_MAX);
    let page = await listSessionCatalogPage({ ...options, scope, limit: pageLimit() });
    sessions.push(...page.sessions);
    while (page.nextCursor && (options.limit === undefined || sessions.length < options.limit)) {
      page = await listSessionCatalogPage({
        ...options,
        scope,
        limit: pageLimit(),
        after: page.nextCursor,
      });
      sessions.push(...page.sessions);
    }
    return {
      contractVersion: SESSION_CATALOG_CONTRACT_VERSION,
      scope,
      locationsRun: [
        ...new Set([
          ...(local?.locationsRun ?? []),
          ...runs.map((run) => run.connector.location),
        ]),
      ],
      sessions,
      discovered:
        (local?.discovered ?? 0) +
        runs.reduce(
          (sum, run) => sum + Number(run.summary.discovered ?? run.observations.length),
          0,
        ),
      skippedUnchanged:
        (local?.skippedUnchanged ?? 0) +
        runs.reduce((sum, run) => sum + Number(run.summary.skipped_unchanged ?? 0), 0),
      providers: [
        ...(local?.providers ?? []),
        ...runs.map((run) => ({
          source: run.connector.id,
          candidates: run.observations.length,
          discovered: Number(run.summary.discovered ?? run.observations.length),
          skippedUnchanged: Number(run.summary.skipped_unchanged ?? 0),
          failed: false,
        })),
      ],
      exemptSources: local?.exemptSources ?? [],
      diagnostics: [...(local?.diagnostics ?? []), ...failures],
      counters: {
        candidatesEnumerated:
          (local?.counters.candidatesEnumerated ?? 0) +
          runs.reduce((sum, run) => sum + run.observations.length, 0),
        shallowReads: local?.counters.shallowReads ?? 0,
        skippedUnchanged: local?.counters.skippedUnchanged ?? 0,
        filesOpened: local?.counters.filesOpened ?? 0,
        bytesRead: local?.counters.bytesRead ?? 0,
        providerQueries: (local?.counters.providerQueries ?? 0) + runs.length,
        recordsInspected: local?.counters.recordsInspected ?? 0,
      },
    };
  }
  return nativeCall(async (native) => {
    const result = await native.discoverSessions({
      ...options,
      sourceConnectors,
      scope: options.scope ?? 'local',
    });
    const contractVersion = Number(result.contractVersion);
    assertCatalogContract(contractVersion);
    return {
      contractVersion,
      scope: validateNativeScope(result.scope),
      locationsRun: Array.isArray(result.locationsRun)
        ? (result.locationsRun as unknown[]).map(validateNativeLocation)
        : [],
      sessions: Array.isArray(result.sessions)
        ? (result.sessions as UnknownRecord[]).map(catalogSession)
        : [],
      discovered: Number(result.discovered),
      skippedUnchanged: Number(result.skippedUnchanged),
      providers: (result.providers as ProviderDiscoverySummary[]) ?? [],
      exemptSources: (result.exemptSources as SourceExemption[]) ?? [],
      diagnostics: Array.isArray(result.diagnostics)
        ? (result.diagnostics as UnknownRecord[]).map((item) => ({
            source: String(item.source),
            locator: nullableString(item.locator),
            error: String(item.error),
          }))
        : [],
      counters: result.counters as unknown as DiscoveryCounters,
    };
  });
}

export async function hydrateSession(
  options: HydrateSessionOptions,
): Promise<HydrateSessionResult> {
  if (!options || typeof options !== 'object') {
    throw new InvalidArgumentError('hydrateSession options are required', 'INVALID_ARGUMENT');
  }
  if (!CATALOG_SOURCES.includes(options.source)) {
    throw new InvalidArgumentError(
      `invalid catalog source: ${String(options.source)}`,
      'INVALID_ARGUMENT',
    );
  }
  if (typeof options.sessionId !== 'string' || options.sessionId.trim() === '') {
    throw new InvalidArgumentError('sessionId must not be empty', 'INVALID_ARGUMENT');
  }
  validateAcquisition(options);
  const sourceConnectors = validateSourceConnectors(options.sourceConnectors);
  const plugins = pluginScope(options.plugins, options.scope, sourceConnectors, [options.source]);
  if (options.plugins && plugins) {
    const selected = plugins.selected.filter((source) =>
      source.supportedSources.includes(options.source),
    );
    const failures: HydrationDiagnostic[] = [];
    let sourceFailure: RelayHistoryError | undefined;
    let result: HydrateSessionResult | undefined;
    // The built-in parser answers first whenever the local side is asked for;
    // a local plugin then adds the evidence it holds for the same identity.
    let localFailure: RelayHistoryError | undefined;
    if (plugins.scope !== 'remote') {
      try {
        result = await hydrateSession({
          ...options,
          plugins: undefined,
          scope: 'local',
          sourceConnectors: [],
        });
      } catch (error) {
        // A session only a local plugin observed is catalogued as local, so the
        // built-in adapter reports that it has not observed it rather than that
        // it does not exist. Either way the plugins below may still hold it.
        if (
          !(
            error instanceof SessionNotFoundError ||
            error instanceof SessionSourceUnavailableError ||
            ((error instanceof ConnectorNotConfiguredError ||
              // The built-in adapter has no full-evidence parser for this
              // source (relay); a plugin that supports it may still have one.
              error instanceof HydrationUnsupportedError) &&
              selected.length > 0)
          )
        )
          throw error;
        localFailure = error;
      }
    }
    if (!selected.length && result) return result;
    for (const connector of selected) {
      try {
        let state = await getSourceObservation(
          {
            source: options.source,
            session_id: options.sessionId,
            location: connector.location,
            connector_id: connector.id,
            connector_instance: connector.instanceId,
          },
          options,
        );
        if (!state.observation) {
          await discoverSourcePlugins(options.plugins, {
            ...options,
            sourceConnectors: [`${connector.id}:${connector.instanceId}`],
            sources: [options.source],
            sessionId: options.sessionId,
          });
          state = await getSourceObservation(
            {
              source: options.source,
              session_id: options.sessionId,
              location: connector.location,
              connector_id: connector.id,
              connector_instance: connector.instanceId,
            },
            options,
          );
        }
        if (state.observation)
          result = combineHydration(
            result,
            normalizeHydration(
              camelSourceResult(await hydrateSourcePlugin(connector, options, options)),
            ),
          );
      } catch (error) {
        throwIfSourceAborted(options.signal);
        preserveStorageFailure(error);
        if (error instanceof RelayHistoryError) sourceFailure ??= error;
        failures.push({
          code: error instanceof RelayHistoryError ? error.code : 'SOURCE_PLUGIN_UNAVAILABLE',
          message: `${connector.id}:${connector.instanceId}: source acquisition failed`,
          durationMs: null,
          sourceBytes: null,
          recordsParsed: null,
        });
      }
    }
    if (!result)
      throw sourceFailure ?? localFailure ?? new SessionSourceUnavailableError(
        'No selected plugin observed this session',
        'SESSION_SOURCE_UNAVAILABLE',
      );
    return { ...result, diagnostics: [...result.diagnostics, ...failures] };
  }
  return nativeCall(async (native) => {
    const value = await native.hydrateSession({
      ...options,
      sourceConnectors,
      scope: options.scope ?? 'local',
      includeRelated: options.includeRelated ?? true,
    });
    return normalizeHydration(value);
  });
}

export async function discoverAndList(
  options: DiscoverSessionsOptions & ListCatalogOptions = {},
): Promise<SessionCatalogPage> {
  await discoverSessions(options);
  return listSessionCatalogPage(options);
}

export async function getSessionEventsPage(
  sessionId: string,
  options: EventsPageOptions = {},
): Promise<SessionEventsPage> {
  return nativeCall(async (native) => {
    const page = await native.getSessionEventsPage(sessionId, options);
    return {
      events: Array.isArray(page.events) ? (page.events as UnknownRecord[]).map(sessionEvent) : [],
      nextCursor:
        page.nextCursor && typeof page.nextCursor === 'object'
          ? {
              tsMs: Number((page.nextCursor as UnknownRecord).tsMs),
              id: Number((page.nextCursor as UnknownRecord).id),
            }
          : null,
    };
  });
}

/**
 * Direct delegation relationships for one session, in both directions. A
 * missing database returns an empty, well-formed result whose `capabilities`
 * still describe what the provider is able to record.
 */
export async function getSessionRelationships(
  options: GetSessionRelationshipsOptions,
): Promise<SessionRelationships> {
  validateSessionRef(options, 'getSessionRelationships');
  return nativeCall(async (native) => {
    const value = await native.getSessionRelationships({
      source: options.source,
      sessionId: options.sessionId,
      dbPath: options.dbPath,
    });
    const contractVersion = Number(value.contractVersion);
    assertRelationshipContract(contractVersion);
    return {
      contractVersion,
      source: String(value.source) as CatalogSource,
      sessionId: String(value.sessionId),
      asParent: relationships(value.asParent),
      asChild: relationships(value.asChild),
      continuity: relationships(value.continuity),
      capabilities: relationshipCapabilities(value.capabilities),
      diagnostics: relationshipDiagnostics(value.diagnostics),
    };
  });
}

export async function getSessionToolCallsPage(
  source: Source,
  sessionId: string,
  options: EvidencePageOptions = {},
): Promise<SessionToolCallsPage> {
  evidenceIdentity(source, sessionId, 'getSessionToolCallsPage');
  return nativeCall(async (native) => {
    const page = await native.getSessionToolCallsPage(source, sessionId, {
      ...options,
      after: nativeEvidenceCursor(options.after),
    });
    assertEvidenceContract(Number(page.contractVersion));
    return {
      contractVersion: Number(page.contractVersion),
      source: String(page.source) as Source,
      sessionId: String(page.sessionId),
      toolCalls: Array.isArray(page.toolCalls)
        ? (page.toolCalls as UnknownRecord[]).map(sessionToolCall)
        : [],
      nextCursor: evidenceCursor(page.nextCursor),
    };
  });
}

/**
 * One bounded page of a session's model requests, oldest first.
 *
 * A request is one API call: Claude's per-content-block copies of
 * `message.usage` are collapsed into it, so summing these pages counts each
 * call once where summing raw events would not.
 */
export async function getSessionRequestsPage(
  source: Source,
  sessionId: string,
  options: RequestPageOptions = {},
): Promise<SessionRequestsPage> {
  evidenceIdentity(source, sessionId, 'getSessionRequestsPage');
  const page = await sessionStoreCall(SESSION_STORE_OPS.requests, {
    dbPath: options.dbPath, source, sessionId, limit: options.limit, after: options.after,
  });
  assertUsageContract(Number(page.contractVersion));
  return {
    contractVersion: Number(page.contractVersion),
    source: String(page.source) as Source,
    sessionId: String(page.sessionId),
    requests: Array.isArray(page.requests)
      ? (page.requests as UnknownRecord[]).map(sessionRequest)
      : [],
    nextCursor: requestCursor(page.nextCursor),
  };
}

/**
 * Provider-neutral usage rollup for one session.
 *
 * `usage` is null when the session carries no usage evidence at all. Cost is
 * never estimated here; `reportedCostUsd` is populated only when the source
 * data itself carried one.
 */
export async function getSessionUsage(
  source: Source,
  sessionId: string,
  options: SessionUsageOptions = {},
): Promise<SessionUsage> {
  evidenceIdentity(source, sessionId, 'getSessionUsage');
  const value = await sessionStoreCall(SESSION_STORE_OPS.usageSummary, {
    dbPath: options.dbPath, source, sessionId,
  });
  assertUsageContract(Number(value.contractVersion));
  return {
    contractVersion: Number(value.contractVersion),
    source: String(value.source) as Source,
    sessionId: String(value.sessionId),
    usage: normalizedUsage(value.usage),
    requestCount: Number(value.requestCount),
    totalRequestCount: Number(value.totalRequestCount),
    accounting: Array.isArray(value.accounting) ? value.accounting.map(usageAccounting) : [],
    models: Array.isArray(value.models) ? value.models.map(String) : [],
    firstTsMs: nullableNumber(value.firstTsMs),
    lastTsMs: nullableNumber(value.lastTsMs),
    diagnostics: usageDiagnostics(value.diagnostics),
    overflowed: Boolean(value.overflowed),
  };
}

/**
 * One bounded page of user turns for one session, oldest first.
 *
 * Each turn carries the ordered blocks a provider attached to one user
 * message — the human's own text and the tool results that came back with it,
 * each with its measured payload size. Derived from the indexed events, so it
 * cannot disagree with the transcript it came from.
 */
export async function getSessionUserTurnsPage(
  source: Source,
  sessionId: string,
  options: UserTurnsPageOptions = {},
): Promise<SessionUserTurnsPage> {
  evidenceIdentity(source, sessionId, 'getSessionUserTurnsPage');
  const page = await sessionStoreCall(SESSION_STORE_OPS.userTurns, {
    dbPath: options.dbPath, source, sessionId, limit: options.limit, after: options.after,
  });
  assertEvidenceContract(Number(page.contractVersion));
  return {
    contractVersion: Number(page.contractVersion),
    source: String(page.source) as Source,
    sessionId: String(page.sessionId),
    userTurns: Array.isArray(page.userTurns)
      ? (page.userTurns as UnknownRecord[]).map(sessionUserTurn)
      : [],
    nextCursor:
      page.nextCursor && typeof page.nextCursor === 'object'
        ? {
            tsMs: Number((page.nextCursor as UnknownRecord).tsMs),
            id: Number((page.nextCursor as UnknownRecord).id),
          }
        : null,
  };
}

/**
 * One bounded page of a session's markers, oldest first — the records a
 * provider wrote that the normalized event model cannot carry: compaction and
 * summary boundaries, provider `system` rows, non-text content blocks, agent
 * lifecycle events. Same `(tsMs IS NULL, tsMs, id)` keyset as tool calls and
 * file edits, so an undated marker pages last through a null-timestamp cursor.
 * A missing database is an empty page.
 */
export async function getSessionMarkersPage(
  source: Source,
  sessionId: string,
  options: EvidencePageOptions = {},
): Promise<SessionMarkersPage> {
  evidenceIdentity(source, sessionId, 'getSessionMarkersPage');
  const page = await sessionStoreCall(SESSION_STORE_OPS.markers, {
    dbPath: options.dbPath,
    source,
    sessionId,
    limit: options.limit,
    // Unlike the typed boundary, JSON carries an undated cursor's `null`
    // intact, so the SDK's emitted cursor goes back in as it came out.
    after: options.after ? { tsMs: options.after.tsMs ?? null, id: options.after.id } : undefined,
  });
  assertEvidenceContract(Number(page.contractVersion));
  return {
    contractVersion: Number(page.contractVersion),
    source: String(page.source) as Source,
    sessionId: String(page.sessionId),
    markers: Array.isArray(page.markers)
      ? (page.markers as UnknownRecord[]).map(sessionMarker)
      : [],
    nextCursor: evidenceCursor(page.nextCursor),
  };
}

/**
 * One bounded page of the revision-stamped change feed
 * (`SessionStore::changes_since`): every row write and delete across the
 * store, in `(revision, kind, recordKey)` order, each with the row as stored.
 * Pass the page's `position` back as `from` for the next page. A named
 * `consumer` resumes from its cursor inside the store, which moves only on
 * `commitChanges`, so a page that was read but not applied is served again.
 * A missing database is an empty, finished feed and is not created.
 */
export async function getChangesPage(options: ChangesPageOptions = {}): Promise<ChangesPage> {
  return changesPage(await sessionStoreCall(SESSION_STORE_OPS.changes, {
    dbPath: options.dbPath,
    from: options.from === undefined || typeof options.from === 'string'
      ? options.from
      : { epoch: options.from.epoch, revision: options.from.revision },
    consumer: options.consumer,
    kinds: options.kinds ? [...options.kinds] : undefined,
    session: options.session ? { source: options.session.source, sessionId: options.session.sessionId } : undefined,
    limit: options.limit,
  }));
}

/**
 * Acknowledge everything up to `position` for a named cursor. Forward-only: a
 * commit behind the stored cursor leaves it where it is, and the answer says
 * where that is. The kind set must be the one the cursor was first committed
 * for (`CONSUMER_KINDS_MISMATCH` otherwise). Needs a writable database.
 */
export async function commitChanges(
  consumer: string,
  position: Watermark,
  options: CommitChangesOptions = {},
): Promise<CommittedCursor> {
  return committedCursor(await sessionStoreCall(SESSION_STORE_OPS.commitChanges, {
    dbPath: options.dbPath,
    consumer,
    kinds: options.kinds ? [...options.kinds] : undefined,
    position: { epoch: position.epoch, revision: position.revision },
  }));
}

/**
 * What one provider's parser can record. Answered from RelayHistory's own
 * capability tables, never from a database, so it does not depend on what has
 * been synced: `evidenceKinds` is the `coverage` a hydration of this source
 * reports, and `relationships` is what its records establish about delegation.
 */
export async function getSourceCapabilities(source: CatalogSource): Promise<SourceCapabilities> {
  if (!isCatalogSource(source)) {
    throw new InvalidArgumentError(
      `invalid source: ${String(source)} (expected one of ${CATALOG_SOURCES.join(', ')})`,
      'INVALID_ARGUMENT',
    );
  }
  return sourceCapabilities(await sessionStoreCall(SESSION_STORE_OPS.capabilities, { source }));
}

/**
 * The complete descendant delegation tree for one session: pre-order,
 * cycle-safe, and bounded by `maxDepth` and `maxNodes`. Child events keep
 * their own session identity and are never flattened into the root.
 */
export async function getSessionTree(options: GetSessionTreeOptions): Promise<SessionTree> {
  validateSessionRef(options, 'getSessionTree');
  return nativeCall(async (native) => {
    const value = await native.getSessionTree({
      source: options.source,
      sessionId: options.sessionId,
      dbPath: options.dbPath,
      maxDepth: options.maxDepth,
      maxNodes: options.maxNodes,
      relationshipKinds: options.relationshipKinds,
    });
    const contractVersion = Number(value.contractVersion);
    assertRelationshipContract(contractVersion);
    return {
      contractVersion,
      source: String(value.source) as CatalogSource,
      rootSessionId: String(value.rootSessionId),
      nodes: Array.isArray(value.nodes) ? (value.nodes as UnknownRecord[]).map(treeNode) : [],
      unlinked: relationships(value.unlinked),
      capabilities: relationshipCapabilities(value.capabilities),
      diagnostics: relationshipDiagnostics(value.diagnostics),
      truncated: value.truncated === true,
      maxDepthReached: Number(value.maxDepthReached),
    };
  });
}

export async function getSessionFileEditsPage(
  source: Source,
  sessionId: string,
  options: EvidencePageOptions = {},
): Promise<SessionFileEditsPage> {
  evidenceIdentity(source, sessionId, 'getSessionFileEditsPage');
  return nativeCall(async (native) => {
    const page = await native.getSessionFileEditsPage(source, sessionId, {
      ...options,
      after: nativeEvidenceCursor(options.after),
    });
    assertEvidenceContract(Number(page.contractVersion));
    return {
      contractVersion: Number(page.contractVersion),
      source: String(page.source) as Source,
      sessionId: String(page.sessionId),
      fileEdits: Array.isArray(page.fileEdits)
        ? (page.fileEdits as UnknownRecord[]).map(sessionFileEdit)
        : [],
      nextCursor: evidenceCursor(page.nextCursor),
    };
  });
}

/**
 * One bounded page of a session's direct children, in the same total order
 * the tree traversal uses: `(spawnedAtMs, relationshipUid)`, nulls last.
 */
export async function getSessionChildrenPage(
  options: GetSessionChildrenPageOptions,
): Promise<SessionChildrenPage> {
  validateSessionRef(options, 'getSessionChildrenPage');
  return nativeCall(async (native) => {
    const page = await native.getSessionChildrenPage({
      source: options.source,
      sessionId: options.sessionId,
      dbPath: options.dbPath,
      limit: options.limit,
      after: options.after
        ? {
            ...options.after,
            spawnedAtMs: options.after.spawnedAtMs ?? undefined,
          }
        : undefined,
      relationshipKinds: options.relationshipKinds,
    });
    return {
      children: relationships(page.children),
      nextCursor: relationshipCursor(page.nextCursor),
    };
  });
}

export async function stats(options: StatsOptions = {}): Promise<Stats> {
  const scope = options.scope ?? 'local';
  return nativeCall(async (native) => {
    const result = await native.stats({ ...options, scope });
    const bySource: Partial<Record<Source, number>> = {};
    for (const item of (result.bySource as UnknownRecord[] | undefined) ?? []) {
      bySource[String(item.source) as Source] = Number(item.count);
    }
    return {
      scope: validateNativeScope(result.scope),
      total: Number(result.total),
      bySource,
      byProject: ((result.byProject as UnknownRecord[] | undefined) ?? []).map((item) => ({
        project: String(item.project),
        count: Number(item.count),
      })),
      groupedBy: result.groupedBy === 'cwd' ? 'cwd' : 'project_key',
      firstTimestampMs:
        typeof result.firstTimestampMs === 'number' ? result.firstTimestampMs : null,
      lastTimestampMs: typeof result.lastTimestampMs === 'number' ? result.lastTimestampMs : null,
    };
  });
}

export async function sync(options: SyncOptions = {}): Promise<SyncResult> {
  validateAcquisition(options);
  const sourceConnectors = validateSourceConnectors(options.sourceConnectors);
  const plugins = pluginScope(options.plugins, options.scope, sourceConnectors);
  if (options.plugins && plugins) {
    const { scope, selected } = plugins;
    const local =
      scope !== 'remote'
        ? await sync({ ...options, plugins: undefined, scope: 'local', sourceConnectors: [] })
        : null;
    const diagnostics: DiscoveryDiagnostic[] = [];
    let sourceFailure: RelayHistoryError | undefined;
    const runs = selected.length
      ? await discoverSourcePlugins(options.plugins, {
          ...options,
          scope,
          sourceConnectors: selected.map((connector) => `${connector.id}:${connector.instanceId}`),
          onUnavailable: (source, error) => {
            sourceFailure ??= error;
            diagnostics.push({ source, locator: null, error: `${error.code}: ${error.message}` });
          },
        })
      : [];
    if (!runs.length && !local)
      throw sourceFailure ?? new ConnectorNotConfiguredError(
        'No selected source plugin is available',
        'CONNECTOR_NOT_CONFIGURED',
      );
    for (const run of runs)
      for (const row of run.observations) {
        try {
          await hydrateSourcePlugin(
            run.connector,
            { source: row.source, sessionId: row.session_id },
            options,
          );
        } catch (error) {
          throwIfSourceAborted(options.signal);
          preserveStorageFailure(error);
          diagnostics.push({
            source: `${run.connector.id}:${run.connector.instanceId}`,
            locator: null,
            error: `${error instanceof RelayHistoryError ? error.code : 'SOURCE_PLUGIN_UNAVAILABLE'}: Source plugin acquisition failed`,
          });
        }
      }
    return {
      databasePath: local?.databasePath ?? options.dbPath ?? defaultDbPath(),
      scope,
      // The native local pass is part of this sync: its diagnostics are this
      // sync's diagnostics, and an incomplete local pass is an incomplete sync.
      completed: (local?.completed ?? true) && diagnostics.length === 0,
      diagnostics: [...(local?.diagnostics ?? []), ...diagnostics],
    };
  }
  return nativeCall(async (native) => {
    const result = await native.sync({
      ...options,
      sourceConnectors,
      scope: options.scope ?? 'local',
    });
    return {
      databasePath: String(result.databasePath),
      scope: validateNativeScope(result.scope),
      completed: result.completed === true,
    };
  });
}

export interface FormatSessionRowOptions {
  /** Opt in to ANSI colour. Default false for logs and SDK consumers. */
  color?: boolean;
  nowMs?: number;
  maxPromptLength?: number;
}

/** Format a catalog session for a terminal without reading providers or the DB. */
export function formatSessionRow(
  session: CatalogSession,
  options: FormatSessionRowOptions = {},
): string {
  if (options.nowMs !== undefined && !Number.isFinite(options.nowMs)) {
    throw new InvalidArgumentError('nowMs must be finite', 'INVALID_ARGUMENT');
  }
  const max = options.maxPromptLength ?? 96;
  if (!Number.isInteger(max) || max < 1 || max > 1000) {
    throw new InvalidArgumentError(
      'maxPromptLength must be an integer between 1 and 1000',
      'INVALID_ARGUMENT',
    );
  }
  const clean = (value: string) =>
    value
      .replace(/[\u0000-\u001f\u007f-\u009f]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  const icons: Record<Source, string> = {
    claude: '✦',
    codex: '◇',
    cursor: '▸',
    grok: '◉',
    relay: '↔',
    opencode: '⌘',
    trajectory: '↗',
    muse: '✧',
  };
  const ageMs =
    session.lastActivityMs === null
      ? null
      : Math.max(0, (options.nowMs ?? Date.now()) - session.lastActivityMs);
  const age =
    ageMs === null
      ? 'unknown age'
      : ageMs < 60_000
        ? 'just now'
        : ageMs < 3_600_000
          ? `${Math.floor(ageMs / 60_000)}m ago`
          : ageMs < 86_400_000
            ? `${Math.floor(ageMs / 3_600_000)}h ago`
            : `${Math.floor(ageMs / 86_400_000)}d ago`;
  const paint = (text: string, code: number) =>
    options.color ? `\u001b[${code}m${text}\u001b[0m` : text;
  const prompt = Array.from(clean(session.firstPrompt ?? '(no prompt)'));
  const preview = prompt.length > max ? `${prompt.slice(0, max).join('')}…` : prompt.join('');
  const locations = session.locations.length ? ` [${session.locations.join(',')}]` : '';
  return (
    `${paint(`${icons[session.source] ?? '•'} [${clean(session.source)}]`, 36)} ${paint(age, 2)}${locations}  ` +
    `${clean(session.sessionId)}  ${session.cwd ? `${clean(session.cwd)}  ` : ''}${preview}`
  );
}

export interface BootstrapLocalOptions {
  dbPath?: string;
  /** Maximum sessions to discover and index on first use. Default 20. */
  limit?: number;
}

export interface BootstrapLocalResult {
  status: 'ready' | 'empty' | 'partial';
  alreadyIndexed: boolean;
  indexedPrompts: number;
  hydratedSessions: number;
  discovery: DiscoverResult | null;
  diagnostics: Array<{ source: string; sessionId: string; code: string; message: string }>;
}

/**
 * Prepare a first local search with the native discovery and hydration APIs.
 * Existing searchable databases are left alone; use sync() for a full refresh.
 * Discovery is bounded and related sessions are excluded from first-touch work.
 */
export async function bootstrapLocal(
  options: BootstrapLocalOptions = {},
): Promise<BootstrapLocalResult> {
  const limit = options.limit ?? 20;
  if (!Number.isInteger(limit) || limit < 1 || limit > 1000) {
    throw new InvalidArgumentError(
      'bootstrap limit must be an integer between 1 and 1000',
      'INVALID_ARGUMENT',
    );
  }
  const local = { dbPath: options.dbPath, scope: 'local' as const };
  const existing = await stats(local);
  if (existing.total > 0) {
    return {
      status: 'ready',
      alreadyIndexed: true,
      indexedPrompts: existing.total,
      hydratedSessions: 0,
      discovery: null,
      diagnostics: [],
    };
  }
  const discovery = await discoverSessions({ ...local, limit });
  const diagnostics: BootstrapLocalResult['diagnostics'] = [];
  let hydratedSessions = 0;
  for (const session of discovery.sessions.slice(0, limit)) {
    try {
      const result = await hydrateSession({
        ...local,
        source: session.source,
        sessionId: session.sessionId,
        includeRelated: false,
      });
      hydratedSessions++;
      // Bootstrap declines delegation evidence above, so an absent
      // `relationship` is this call's own choice and must not be reported as a
      // provider limitation. What remains missing is the provider's.
      const unavailable = FULL_SESSION_KINDS.filter(
        (kind) => kind !== 'relationship' && !result.coverage.includes(kind),
      );
      if (unavailable.length > 0) {
        diagnostics.push({
          source: session.source,
          sessionId: session.sessionId,
          code: 'CAPABILITY_LIMITED',
          message: `Provider exposes no ${unavailable.join(', ')} evidence`,
        });
      }
    } catch (error) {
      if (
        !(
          error instanceof SessionSourceUnavailableError ||
          error instanceof SessionSourceMismatchError ||
          error instanceof HydrationUnsupportedError ||
          error instanceof HydrationFailedError
        )
      )
        throw error;
      diagnostics.push({
        source: session.source,
        sessionId: session.sessionId,
        code: error.code,
        message: error.message,
      });
    }
  }
  const indexed = await stats(local);
  const partial =
    diagnostics.length > 0 ||
    discovery.diagnostics.length > 0 ||
    discovery.providers.some((provider) => provider.failed);
  return {
    status: partial ? 'partial' : indexed.total > 0 ? 'ready' : 'empty',
    alreadyIndexed: false,
    indexedPrompts: indexed.total,
    hydratedSessions,
    discovery,
    diagnostics,
  };
}

/**
 * `ready` — the store answers queries. `empty` — bootstrap ran and this machine
 * has no local coding-agent history at all. `unbuilt` — bootstrap was declined,
 * so nothing is indexed yet and that is not the same as having no history.
 * `skipped` — the caller is not reading the local store.
 */
export type LocalStoreStatus = 'ready' | 'empty' | 'unbuilt' | 'skipped';

export interface LocalStoreReadiness {
  status: LocalStoreStatus;
  indexedPrompts: number;
  /** The bootstrap that ran on this call, or null when none did. */
  bootstrap: BootstrapLocalResult | null;
}

/**
 * Listen for schema migrations this process runs on an existing database.
 *
 * A migration after an upgrade can take minutes on a large history. `listener`
 * hears `started` when an open takes the write lock to migrate, then
 * `finished` when it commits or `failed` when it rolls back, each with the
 * database's path -- never for a new or current
 * database, or for a call that is rejected before it opens -- so a front end
 * announces exactly the work that happens. Events arrive asynchronously, so
 * the last one can land just after the migrating call settles. One listener per
 * process: resolves false when one is already registered.
 */
export async function onStoreMigration(
  listener: (event: 'started' | 'finished' | 'failed', dbPath: string | null) => void,
): Promise<boolean> {
  return nativeCall(async (native) => native.onStoreMigration(listener));
}

/** Run any outstanding schema migration now, creating the database if it does not exist. */
export async function migrateStore(options: { dbPath?: string } = {}): Promise<void> {
  return nativeCall((native) => native.migrateStore(options.dbPath));
}

export interface EnsureLocalStoreOptions {
  dbPath?: string;
  /** Only `local` and `all` read the local database; `remote` skips the check. */
  scope?: SessionScope;
  /** False for `--no-bootstrap`: report the store as it stands, build nothing. */
  bootstrap?: boolean;
}

/**
 * The single first-use decision behind every local read. Callers must not each
 * choose whether to bootstrap: a fresh install has to answer the same way
 * whichever command the user happens to type first, and a store that was never
 * built has to be distinguishable from one that holds no match.
 */
export async function ensureLocalStore(
  options: EnsureLocalStoreOptions = {},
): Promise<LocalStoreReadiness> {
  const { dbPath, scope = 'local' } = options;
  if (scope === 'remote') return { status: 'skipped', indexedPrompts: 0, bootstrap: null };
  if (options.bootstrap === false) {
    const existing = await stats({ dbPath, scope: 'local' });
    return {
      status: existing.total > 0 ? 'ready' : 'unbuilt',
      indexedPrompts: existing.total,
      bootstrap: null,
    };
  }
  const bootstrap = await bootstrapLocal({ dbPath });
  // `partial` reports indexing diagnostics, not emptiness: whether the store can
  // answer is decided by the prompt count alone.
  return {
    status: bootstrap.indexedPrompts > 0 ? 'ready' : 'empty',
    indexedPrompts: bootstrap.indexedPrompts,
    bootstrap,
  };
}

export function resumeCommand(
  entry: Pick<HistoryEntry, 'source' | 'sessionId' | 'project' | 'locations'>,
): string | null {
  if (!entry.sessionId) return null;
  if (entry.locations.length > 0 && !entry.locations.includes('local')) return null;
  const resume = (() => {
    if (entry.source === 'claude') return `claude --resume ${shellQuote(entry.sessionId)}`;
    if (entry.source === 'codex') return `codex resume ${shellQuote(entry.sessionId)}`;
    if (entry.source === 'cursor') return `cursor-agent --resume=${shellQuote(entry.sessionId)}`;
    if (entry.source === 'grok') return `grok resume ${shellQuote(entry.sessionId)}`;
    if (entry.source === 'muse') return `muse resume ${shellQuote(entry.sessionId)}`;
    return null;
  })();
  return resume && entry.project ? `cd ${shellQuote(entry.project)} && ${resume}` : resume;
}

function shellQuote(value: string): string {
  return /^[A-Za-z0-9._:/-]+$/.test(value) ? value : `'${value.replace(/'/g, `'"'"'`)}'`;
}

function preserveStorageFailure(error: unknown): void {
  if (
    error instanceof RelayHistoryError &&
    [
      'SOURCE_REVISION_CONFLICT',
      'SOURCE_INTAKE_FAILED',
      'DATABASE_OPEN_FAILED',
      'NATIVE_CALL_FAILED',
      'NATIVE_LOAD_FAILED',
      'NATIVE_CONTRACT_MISMATCH',
    ].includes(error.code)
  )
    throw error;
}
function validateAcquisition(options: {
  scope?: SessionScope;
  sources?: CatalogSource[];
  limit?: number;
  acquisitionTimeoutMs?: number;
}): void {
  if (!options || typeof options !== 'object')
    throw new InvalidArgumentError('acquisition options are required', 'INVALID_ARGUMENT');
  sourceAcquisitionTimeout(options.acquisitionTimeoutMs);
  if (options.scope !== undefined && !['local', 'remote', 'all'].includes(options.scope))
    throw new InvalidArgumentError('scope must be local, remote, or all', 'INVALID_ARGUMENT');
  if (
    options.sources !== undefined &&
    (!Array.isArray(options.sources) ||
      options.sources.some((source) => !CATALOG_SOURCES.includes(source)))
  )
    throw new InvalidArgumentError(
      'sources must contain supported catalog sources',
      'INVALID_ARGUMENT',
    );
  if (
    options.limit !== undefined &&
    (!Number.isInteger(options.limit) || options.limit < 1 || options.limit > 10000)
  )
    throw new InvalidArgumentError(
      'acquisition limit must be an integer from 1 to 10000',
      'INVALID_ARGUMENT',
    );
}
/** Internals reachable from this package's own tests. Not public API. */
export const __testing = { combineHydration };

function validateSourceConnectors(value: unknown): string[] | undefined {
  if (value === undefined) return undefined;
  if (
    !Array.isArray(value) ||
    [...value].some((id) => typeof id !== 'string' || !id || id.trim() !== id)
  ) {
    throw new InvalidArgumentError(
      'sourceConnectors must be an array of nonempty, unpadded connector IDs',
      'INVALID_ARGUMENT',
    );
  }
  if (new Set(value).size !== value.length) {
    throw new InvalidArgumentError(
      'sourceConnectors must not contain duplicate IDs',
      'INVALID_ARGUMENT',
    );
  }
  return [...value];
}
