import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

import { SESSION_EVIDENCE_CONTRACT_VERSION, SESSION_USAGE_CONTRACT_VERSION } from './index.js';
import { humanLine } from './cli.js';

const run = promisify(execFile);
const cli = join(dirname(fileURLToPath(import.meta.url)), 'cli.js');

function isUsageFailure(error: unknown, message: string): boolean {
  return typeof error === 'object' && error !== null
    && 'code' in error && error.code === 2
    && 'stderr' in error && String(error.stderr).includes(message)
    && String(error.stderr).includes('Usage:');
}

test('sessions discover preserves repeated sources and emits JSONL', async () => {
  const root = await mkdtemp(join(tmpdir(), 'relayhistory-cli-'));
  const home = join(root, 'home');
  const claude = join(home, '.claude', 'projects', 'project');
  const codex = join(home, '.codex', 'sessions', '2026', '08', '30');
  await mkdir(claude, { recursive: true });
  await mkdir(codex, { recursive: true });
  await writeFile(join(home, '.claude', 'history.jsonl'), `${JSON.stringify({
    display: 'indexed prompt', sessionId: 'claude-1', project: '/work/claude', timestamp: 1,
  })}\n`);
  await writeFile(join(claude, 'claude-1.jsonl'), `${JSON.stringify({
    sessionId: 'claude-1', cwd: '/work/claude', type: 'user',
    message: { role: 'user', content: 'claude prompt' }, timestamp: '2026-08-30T10:00:00.000Z',
  })}\n`);
  await writeFile(join(codex, 'rollout-codex-1.jsonl'), `${JSON.stringify({
    timestamp: '2026-08-30T11:00:00.000Z', type: 'session_meta',
    payload: { id: 'codex-1', cwd: '/work/codex' },
  })}\n${JSON.stringify({
    timestamp: '2026-08-30T11:00:01.000Z', type: 'event_msg',
    payload: { type: 'user_message', message: 'codex prompt' },
  })}\n`);

  try {
    const { stdout } = await run(process.execPath, [
      cli, 'sessions', 'discover', '--source', 'claude', '--source', 'codex',
      '--db', join(root, 'history.db'), '--json', '--no-warning',
    ], { env: { ...process.env, HOME: home, USERPROFILE: home } });
    const lines = stdout.trim().split('\n').map((line) => JSON.parse(line) as Record<string, unknown>);
    const sessions = lines.filter((line) => line.type === 'session');
    assert.deepEqual(sessions.map((line) => line.source).sort(), ['claude', 'codex']);
    assert.ok(sessions.every((line) => JSON.stringify(line.locations) === '["local"]'));
    assert.equal(lines.at(-1)?.type, 'summary');
    assert.equal(lines.at(-1)?.contract_version, 4);
    assert.equal(lines.at(-1)?.scope, 'local');
    assert.equal('sessions' in (lines.at(-1) ?? {}), false);

    const human = await run(process.execPath, [
      cli, 'sessions', 'discover', '--all', '--source', 'codex',
      '--db', join(root, 'history.db'), '--no-warning',
    ], { env: { ...process.env, HOME: home, USERPROFILE: home } });
    assert.match(human.stdout, /requested scope: all, connector locations run: local/);

    await run(process.execPath, [
      cli, 'sync', '--db', join(root, 'history.db'), '--json', '--no-warning',
    ], { env: { ...process.env, HOME: home, USERPROFILE: home } });
    const searched = await run(process.execPath, [
      cli, 'search', 'indexed prompt', '--db', join(root, 'history.db'), '--json', '--no-warning',
    ], { env: { ...process.env, HOME: home, USERPROFILE: home } });
    assert.deepEqual((JSON.parse(searched.stdout) as Array<Record<string, unknown>>)[0]?.locations, ['local']);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('the Node CLI filters by canonical project key and groups stats by it', async () => {
  const root = await mkdtemp(join(tmpdir(), 'relayhistory-cli-project-'));
  const home = join(root, 'home');
  const db = join(root, 'history.db');
  const env = { ...process.env, HOME: home, USERPROFILE: home };
  // Two checkouts of one repository plus an unrelated directory. Under a
  // path-keyed filter the first two are different projects; the whole point of
  // the key is that they are not.
  const checkout = async (name: string, origin: string | null): Promise<string> => {
    const dir = join(root, 'work', name);
    await mkdir(join(dir, '.git'), { recursive: true });
    await writeFile(join(dir, '.git', 'config'),
      origin ? `[remote "origin"]\n\turl = ${origin}\n` : '[core]\n\tbare = false\n');
    return dir;
  };
  const one = await checkout('proj', 'git@github.com:Org/Repo.git');
  const two = await checkout('proj-elsewhere', 'https://github.com/Org/Repo');
  const loose = await checkout('loose', null);
  const day = join(home, '.codex', 'sessions', '2026', '09', '19');
  await mkdir(day, { recursive: true });
  for (const [id, cwd] of [['one', one], ['two', two], ['loose', loose]] as const) {
    await writeFile(join(day, `rollout-${id}.jsonl`), [
      JSON.stringify({ timestamp: '2026-09-19T11:00:00.000Z', type: 'session_meta', payload: { id, cwd } }),
      JSON.stringify({ timestamp: '2026-09-19T11:00:01.000Z', type: 'event_msg', payload: { type: 'user_message', message: `${id} prompt` } }),
      '',
    ].join('\n'));
  }
  try {
    await run(process.execPath, [cli, 'sync', '--db', db, '--json', '--no-warning'], { env });

    // The CLI's JSON surface is snake_case, unlike the SDK objects it wraps.
    type Row = Record<string, unknown>;
    type Page = { sessions: Row[] };
    type StatsJson = { grouped_by: string; by_project: Array<{ project: string; count: number }> };

    const listed = await run(process.execPath, [cli, 'sessions', 'list', '--db', db, '--json', '--no-warning'], { env });
    const rows = (JSON.parse(listed.stdout) as Page).sessions;
    const keyed = Object.fromEntries(rows.map((row) => [row.session_id, row.project_key]));
    assert.equal(keyed.one, 'github.com/Org/Repo');
    assert.equal(keyed.two, 'github.com/Org/Repo');
    assert.equal(keyed.loose, loose, 'a directory with no remote falls back to itself');
    assert.equal(rows.find((row) => row.session_id === 'one')?.project_key_method, 'remote');

    const filtered = await run(process.execPath, [
      cli, 'sessions', 'list', '--db', db, '--json', '--project', 'github.com/Org/Repo', '--no-warning',
    ], { env });
    const selected = (JSON.parse(filtered.stdout) as Page).sessions
      .map((row) => row.session_id).sort();
    assert.deepEqual(selected, ['one', 'two'],
      '--project must select both checkouts of the repository and nothing else');

    const canonical = await run(process.execPath, [cli, 'stats', '--db', db, '--json', '--no-warning'], { env });
    const byKey = JSON.parse(canonical.stdout) as StatsJson;
    assert.equal(byKey.grouped_by, 'project_key');
    assert.equal(byKey.by_project.find((row) => row.project === 'github.com/Org/Repo')?.count, 2,
      'the two checkouts must land in one bucket');

    const byCwd = await run(process.execPath, [cli, 'stats', '--db', db, '--json', '--by-cwd', '--no-warning'], { env });
    const cwdGrouped = JSON.parse(byCwd.stdout) as StatsJson;
    assert.equal(cwdGrouped.grouped_by, 'cwd');
    assert.ok(cwdGrouped.by_project.every((row) => row.project !== 'github.com/Org/Repo'),
      '--by-cwd must restore the raw directory grouping');
    assert.equal(cwdGrouped.by_project.find((row) => row.project === one)?.count, 1);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('sessions list keeps human and JSON output contracts distinct', async () => {
  const root = await mkdtemp(join(tmpdir(), 'relayhistory-cli-empty-'));
  const db = join(root, 'missing.db');
  const env = { ...process.env, HOME: root, USERPROFILE: root, XDG_DATA_HOME: join(root, 'share') };
  try {
    await assert.rejects(
      run(process.execPath, [cli, 'sessions', 'list', '--db', db, '--no-warning'], { env }),
      (error: unknown) => typeof error === 'object' && error !== null
        && 'stdout' in error && String(error.stdout).includes('No searchable local sessions found'),
    );
    await assert.rejects(
      run(process.execPath, [cli, 'sessions', 'list', '--db', db, '--json', '--no-warning'], { env }),
      (error: unknown) => {
        if (typeof error !== 'object' || error === null || !('stdout' in error)) return false;
        return JSON.stringify(JSON.parse(String(error.stdout))) === JSON.stringify({
          status: 'empty', indexed_prompts: 0,
          message: 'No searchable local sessions found. Start a coding-agent session, then run ai-hist again.',
        });
      },
    );
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('sessions hydrate uses the SDK contract and is idempotent', async () => {
  const root = await mkdtemp(join(tmpdir(), 'relayhistory-cli-hydrate-'));
  const home = join(root, 'home');
  const claude = join(home, '.claude', 'projects', 'project');
  const db = join(root, 'history.db');
  await mkdir(claude, { recursive: true });
  await writeFile(join(claude, 'claude-hydrate.jsonl'), `${JSON.stringify({
    sessionId: 'claude-hydrate', uuid: 'user-1', cwd: '/work/claude', type: 'user',
    message: { role: 'user', content: 'hydrate this session' }, timestamp: '2026-08-30T10:00:00.000Z',
  })}\n`);
  const env = { ...process.env, HOME: home, USERPROFILE: home };
  try {
    await run(process.execPath, [
      cli, 'sessions', 'discover', '--source', 'claude', '--db', db, '--no-warning',
    ], { env });
    const first = await run(process.execPath, [
      cli, 'sessions', 'hydrate', 'claude', 'claude-hydrate', '--db', db, '--json', '--no-warning',
    ], { env });
    const hydrated = JSON.parse(first.stdout) as Record<string, unknown>;
    assert.equal(hydrated.contract_version, 3);
    assert.ok(hydrated.status === 'hydrated' || hydrated.status === 'updated',
      `expected hydrated or updated, got ${String(hydrated.status)}`);
    assert.equal(hydrated.capability, 'full');
    assert.equal(hydrated.discovery_state, 'full');
    // Claude's parser produces every kind, so `full` is a computed answer here
    // rather than the literal every provider used to receive.
    assert.deepEqual(hydrated.coverage, [
      'history', 'session_event', 'tool_call', 'file_edit', 'relationship',
    ]);
    assert.deepEqual(hydrated.evidence, {
      prompts: 1, events: 1, tool_calls: 0, file_edits: 0, related_sessions: 0,
    });

    const second = await run(process.execPath, [
      cli, 'sessions', 'hydrate', 'claude', 'claude-hydrate', '--db', db, '--json', '--no-warning',
    ], { env });
    assert.equal((JSON.parse(second.stdout) as Record<string, unknown>).status, 'unchanged');
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('sessions relationships and sessions tree render topology in both modes', async () => {
  const root = await mkdtemp(join(tmpdir(), 'relayhistory-cli-topology-'));
  const home = join(root, 'home');
  const day = join(home, '.codex', 'sessions', '2026', '08', '31');
  const db = join(root, 'history.db');
  await mkdir(day, { recursive: true });
  const rollout = (id: string, at: string, parent?: string) => [
    JSON.stringify({
      timestamp: at, type: 'session_meta',
      payload: parent === undefined
        ? { id, cwd: '/work/app' }
        : {
          id, cwd: '/work/app', session_id: parent, parent_thread_id: parent,
          thread_source: 'subagent', source: { subagent: { other: 'guardian' } },
        },
    }),
    JSON.stringify({ timestamp: at, type: 'event_msg', payload: { type: 'user_message', message: `${id} prompt` } }),
    JSON.stringify({ timestamp: at, type: 'event_msg', payload: { type: 'agent_message', message: `${id} answer` } }),
    '',
  ].join('\n');
  await writeFile(join(day, 'rollout-topology-root.jsonl'), rollout('topology-root', '2026-08-31T10:00:00Z'));
  await writeFile(join(day, 'rollout-topology-child.jsonl'), rollout('topology-child', '2026-08-31T10:00:01Z', 'topology-root'));
  const env = { ...process.env, HOME: home, USERPROFILE: home };
  try {
    await run(process.execPath, [cli, 'sessions', 'discover', '--source', 'codex', '--db', db, '--no-warning'], { env });
    await run(process.execPath, [cli, 'sessions', 'hydrate', 'codex', 'topology-root', '--db', db, '--no-warning'], { env });

    const relationships = await run(process.execPath, [
      cli, 'sessions', 'relationships', 'codex', 'topology-root', '--db', db, '--json', '--no-warning',
    ], { env });
    const wire = JSON.parse(relationships.stdout) as Record<string, unknown>;
    assert.equal(wire.contract_version, 2);
    assert.equal(wire.session_id, 'topology-root');
    assert.deepEqual(wire.as_child, []);
    const [edge] = wire.as_parent as Array<Record<string, unknown>>;
    assert.equal(edge.child_session_id, 'topology-child');
    assert.equal(edge.identity_status, 'observed');
    assert.equal(edge.child_has_events, true);
    assert.equal(edge.relationship_uid, 'child:topology-child');
    assert.equal((wire.capabilities as Record<string, unknown>).stable_child_identity, 'always');

    const readable = await run(process.execPath, [
      cli, 'sessions', 'relationships', 'codex', 'topology-root', '--db', db, '--no-warning',
    ], { env });
    assert.match(readable.stdout, /codex\/topology-root: 1 child relationship\(s\), 0 parent relationship\(s\)/);
    assert.match(readable.stdout, /child {2}topology-child {2}delegated {2}guardian/);
    assert.match(readable.stdout, /identity=observed/);
    assert.match(readable.stdout, /capability: stable child identity = always/);

    const empty = await run(process.execPath, [
      cli, 'sessions', 'relationships', 'codex', 'topology-child', '--db', db, '--no-warning',
    ], { env });
    assert.match(empty.stdout, /codex\/topology-child: 0 child relationship\(s\), 1 parent relationship\(s\)/);
    assert.match(empty.stdout, /parent {2}topology-root/);

    const treeJson = await run(process.execPath, [
      cli, 'sessions', 'tree', 'codex', 'topology-root', '--db', db, '--json', '--no-warning',
    ], { env });
    const tree = JSON.parse(treeJson.stdout) as Record<string, unknown>;
    assert.equal(tree.root_session_id, 'topology-root');
    assert.equal(tree.truncated, false);
    assert.deepEqual((tree.nodes as Array<Record<string, unknown>>).map((node) => node.session_id), [
      'topology-root', 'topology-child',
    ]);

    const treeHuman = await run(process.execPath, [
      cli, 'sessions', 'tree', 'codex', 'topology-root', '--max-depth', '4', '--db', db, '--no-warning',
    ], { env });
    assert.match(treeHuman.stdout, /^topology-root\n {2}topology-child {2}\[delegated guardian] {2}events=yes\n1 descendant\(s\), max depth 1\n$/);

    // A tree always contains its root, so a session with no recorded
    // delegation renders as itself rather than as nothing at all.
    const lone = await run(process.execPath, [
      cli, 'sessions', 'tree', 'codex', 'topology-child', '--db', db, '--no-warning',
    ], { env });
    assert.match(lone.stdout, /^topology-child\n0 descendant\(s\), max depth 0\n$/);

    // A budget that stops the walk is worth saying out loud: the readable
    // tree prints the same diagnostics the JSON form carries.
    const bounded = await run(process.execPath, [
      cli, 'sessions', 'tree', 'codex', 'topology-root', '--max-nodes', '1', '--db', db, '--no-warning',
    ], { env });
    assert.match(
      bounded.stdout,
      /^topology-root {2}…\n0 descendant\(s\), max depth 0\nRELATIONSHIP_TREE_TRUNCATED: tree exceeded max_nodes=1\ntruncated: node\/depth budget reached\n$/,
    );

    await assert.rejects(
      run(process.execPath, [
        cli, 'sessions', 'tree', 'codex', 'topology-root', '--max-depth', '0', '--db', db, '--no-warning',
      ], { env }),
      (error: unknown) => typeof error === 'object' && error !== null
        && 'code' in error && error.code === 1
        && 'stderr' in error && String(error.stderr).includes('INVALID_ARGUMENT'),
    );
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('sessions tools and edits page versioned JSON and continue from a cursor', async () => {
  const root = await mkdtemp(join(tmpdir(), 'relayhistory-cli-evidence-'));
  const home = join(root, 'home');
  const claude = join(home, '.claude', 'projects', 'project');
  const db = join(root, 'history.db');
  await mkdir(claude, { recursive: true });
  const transcript = [
    { type: 'user', uuid: 'u1', sessionId: 'claude-evidence', cwd: '/work/app', gitBranch: 'main', timestamp: '2026-08-30T10:00:00.000Z', message: { role: 'user', content: 'edit two files' } },
    { type: 'assistant', uuid: 'a1', parentUuid: 'u1', sessionId: 'claude-evidence', cwd: '/work/app', gitBranch: 'main', timestamp: '2026-08-30T10:00:01.000Z', message: { role: 'assistant', content: [{ type: 'tool_use', id: 'toolu_1', name: 'Edit', input: { file_path: '/work/app/a.ts', old_string: 'a', new_string: 'b' } }] } },
    { type: 'assistant', uuid: 'a2', parentUuid: 'a1', sessionId: 'claude-evidence', cwd: '/work/app', gitBranch: 'main', timestamp: '2026-08-30T10:00:02.000Z', message: { role: 'assistant', content: [{ type: 'tool_use', id: 'toolu_2', name: 'Write', input: { file_path: '/work/app/b.ts', content: 'b' } }] } },
  ];
  await writeFile(join(claude, 'claude-evidence.jsonl'), `${transcript.map((line) => JSON.stringify(line)).join('\n')}\n`);
  const env = { ...process.env, HOME: home, USERPROFILE: home };
  try {
    await run(process.execPath, [cli, 'sync', '--db', db, '--no-warning'], { env });

    const first = await run(process.execPath, [
      cli, 'sessions', 'tools', 'claude', 'claude-evidence', '--limit', '1', '--db', db, '--json', '--no-warning',
    ], { env });
    const page = JSON.parse(first.stdout) as Record<string, unknown>;
    assert.equal(page.contract_version, SESSION_EVIDENCE_CONTRACT_VERSION);
    assert.equal(page.source, 'claude');
    assert.equal(page.session_id, 'claude-evidence');
    const calls = page.tool_calls as Array<Record<string, unknown>>;
    assert.equal(calls.length, 1);
    assert.equal(calls[0].tool_use_id, 'toolu_1');
    // Provider argument keys are data and survive the snake_case wire mapping.
    assert.deepEqual(calls[0].args, { file_path: '/work/app/a.ts', old_string: 'a', new_string: 'b' });
    const cursor = page.next_cursor as Record<string, unknown>;
    assert.equal(typeof cursor.id, 'number');

    // The printed cursor feeds straight back into --after, unedited.
    const second = await run(process.execPath, [
      cli, 'sessions', 'tools', 'claude', 'claude-evidence', '--after', JSON.stringify(cursor),
      '--db', db, '--json', '--no-warning',
    ], { env });
    const rest = JSON.parse(second.stdout) as Record<string, unknown>;
    assert.deepEqual((rest.tool_calls as Array<Record<string, unknown>>).map((call) => call.tool_use_id), ['toolu_2']);
    assert.equal(rest.next_cursor, null);

    const edits = await run(process.execPath, [
      cli, 'sessions', 'edits', 'claude', 'claude-evidence', '--db', db, '--json', '--no-warning',
    ], { env });
    const editPage = JSON.parse(edits.stdout) as Record<string, unknown>;
    assert.equal(editPage.contract_version, SESSION_EVIDENCE_CONTRACT_VERSION);
    assert.deepEqual((editPage.file_edits as Array<Record<string, unknown>>).map((edit) => edit.file_path), ['/work/app/a.ts', '/work/app/b.ts']);

    const human = await run(process.execPath, [
      cli, 'sessions', 'edits', 'claude', 'claude-evidence', '--db', db, '--no-warning',
    ], { env });
    assert.match(human.stdout, /\/work\/app\/a\.ts/);
    // Human rows are positional: every column is printed, so an absent value
    // never shifts the ones after it, and an uncounted line delta reads as `?`
    // rather than a fabricated zero.
    for (const line of human.stdout.trim().split('\n')) {
      const columns = line.split('  ');
      assert.equal(columns.length, 6, `edit row keeps six columns: ${line}`);
      assert.match(columns[5], /^\+(\d+|\?)\/-(\d+|\?)$/);
    }
    const humanTools = await run(process.execPath, [
      cli, 'sessions', 'tools', 'claude', 'claude-evidence', '--db', db, '--no-warning',
    ], { env });
    for (const line of humanTools.stdout.trim().split('\n')) {
      assert.equal(line.split('  ').length, 6, `tool call row keeps six columns: ${line}`);
    }
    const empty = await run(process.execPath, [
      cli, 'sessions', 'tools', 'claude', 'missing-session', '--db', db, '--no-warning',
    ], { env });
    assert.match(empty.stdout, /No tool calls\./);
    // The human continuation hint is the other accepted cursor spelling.
    const humanPage = await run(process.execPath, [
      cli, 'sessions', 'tools', 'claude', 'claude-evidence', '--limit', '1', '--db', db, '--no-warning',
    ], { env });
    const hint = /more available: --after '(.+)'/.exec(humanPage.stdout)?.[1];
    assert.ok(hint, 'human output prints a continuation cursor');
    const continued = await run(process.execPath, [
      cli, 'sessions', 'tools', 'claude', 'claude-evidence', '--after', hint,
      '--db', db, '--json', '--no-warning',
    ], { env });
    assert.deepEqual(
      (JSON.parse(continued.stdout).tool_calls as Array<Record<string, unknown>>).map((call) => call.tool_use_id),
      ['toolu_2'],
    );

    // An undated cursor is spelled either way — `"tsMs": null` as the human
    // hint and the JSON page print it, or no `tsMs` at all — and both reach
    // the native boundary, which only accepts an absent one. On this dated
    // session both name an empty undated tail instead of failing the command.
    for (const after of [`{"tsMs":null,"id":${cursor.id as number}}`, '{"id":1}', '{"ts_ms":null,"id":1}']) {
      const tail = await run(process.execPath, [
        cli, 'sessions', 'tools', 'claude', 'claude-evidence', '--after', after,
        '--db', db, '--json', '--no-warning',
      ], { env });
      assert.deepEqual((JSON.parse(tail.stdout) as Record<string, unknown>).tool_calls, []);
      const tailEdits = await run(process.execPath, [
        cli, 'sessions', 'edits', 'claude', 'claude-evidence', '--after', after,
        '--db', db, '--no-warning',
      ], { env });
      assert.match(tailEdits.stdout, /No file edits\./);
    }

    // A cursor field that is present but not an integer is malformed, not
    // undated: coercing it to null would move the page into the undated tail
    // and silently omit every dated record instead of reporting the bad flag.
    for (const [after, message] of [
      ['{"ts_ms":"1720000000000","id":1}', '--after cursor ts_ms must be an integer or null'],
      ['{"tsMs":"1720000000000","id":1}', '--after cursor ts_ms must be an integer or null'],
      ['{"tsMs":1.5,"id":1}', '--after cursor ts_ms must be an integer or null'],
      ['{"id":"1"}', '--after must be a JSON cursor with an integer id'],
      ['{"tsMs":null}', '--after must be a JSON cursor with an integer id'],
      ['{"tsMs":null,"id":1.5}', '--after must be a JSON cursor with an integer id'],
    ] as const) {
      for (const subcommand of ['tools', 'edits']) {
        await assert.rejects(
          run(process.execPath, [
            cli, 'sessions', subcommand, 'claude', 'claude-evidence', '--after', after,
            '--db', db, '--json', '--no-warning',
          ], { env }),
          (error: unknown) => typeof error === 'object' && error !== null
            && 'code' in error && error.code === 1
            && 'stderr' in error && String(error.stderr).includes(message),
          `sessions ${subcommand} --after ${after}`,
        );
      }
    }

    for (const args of [
      ['sessions', 'tools', 'claude'],
      ['sessions', 'edits', 'claude'],
    ]) {
      await assert.rejects(
        run(process.execPath, [cli, ...args, '--db', db, '--no-warning'], { env }),
        (error: unknown) => isUsageFailure(error, 'requires SOURCE and SESSION_ID'),
        args.join(' '),
      );
    }
    await assert.rejects(
      run(process.execPath, [cli, 'sessions', 'tools', 'claude', 'claude-evidence', '--remote', '--db', db, '--no-warning'], { env }),
      (error: unknown) => isUsageFailure(error, 'sessions tools does not accept --remote'),
    );
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('sessions markers and sessions usage page versioned JSON and render human rows', async () => {
  const root = await mkdtemp(join(tmpdir(), 'relayhistory-cli-markers-'));
  const home = join(root, 'home');
  const claude = join(home, '.claude', 'projects', 'project');
  const db = join(root, 'history.db');
  await mkdir(claude, { recursive: true });
  const usage = { input_tokens: 3, cache_creation_input_tokens: 40, cache_read_input_tokens: 100, output_tokens: 7 };
  const transcript = [
    { type: 'summary', summary: 'earlier work', leafUuid: 'leaf-1' },
    { type: 'user', uuid: 'u1', sessionId: 'claude-markers', cwd: '/work/app', timestamp: '2026-08-30T10:00:00.000Z', message: { role: 'user', content: 'continue' } },
    { type: 'system', subtype: 'compact_boundary', uuid: 's1', parentUuid: 'u1', sessionId: 'claude-markers', cwd: '/work/app', timestamp: '2026-08-30T10:00:01.000Z', compactMetadata: { trigger: 'manual', preTokens: 5 } },
    { type: 'assistant', uuid: 'a1', parentUuid: 's1', requestId: 'req_1', sessionId: 'claude-markers', cwd: '/work/app', timestamp: '2026-08-30T10:00:02.000Z', message: { role: 'assistant', model: 'claude-test', id: 'msg_1', usage, content: [{ type: 'text', text: 'ok' }] } },
  ];
  await writeFile(join(claude, 'claude-markers.jsonl'), `${transcript.map((line) => JSON.stringify(line)).join('\n')}\n`);
  const env = { ...process.env, HOME: home, USERPROFILE: home };
  try {
    await run(process.execPath, [cli, 'sync', '--db', db, '--no-warning'], { env });

    const first = await run(process.execPath, [
      cli, 'sessions', 'markers', 'claude', 'claude-markers', '--limit', '1', '--db', db, '--json', '--no-warning',
    ], { env });
    const page = JSON.parse(first.stdout) as Record<string, unknown>;
    assert.equal(page.contract_version, SESSION_EVIDENCE_CONTRACT_VERSION);
    assert.equal(page.source, 'claude');
    assert.equal(page.session_id, 'claude-markers');
    const markers = page.markers as Array<Record<string, unknown>>;
    assert.equal(markers.length, 1);
    assert.equal(markers[0].kind, 'compaction_boundary');
    // Provider payload keys are data and survive the snake_case wire mapping.
    assert.equal((markers[0].payload as Record<string, unknown>).trigger, 'manual');
    const cursor = page.next_cursor as Record<string, unknown>;
    assert.equal(typeof cursor.id, 'number');

    // The printed cursor feeds straight back into --after, unedited, and the
    // undated summary is reached through the null-timestamp tail.
    const second = await run(process.execPath, [
      cli, 'sessions', 'markers', 'claude', 'claude-markers', '--after', JSON.stringify(cursor),
      '--db', db, '--json', '--no-warning',
    ], { env });
    const rest = JSON.parse(second.stdout) as Record<string, unknown>;
    const restMarkers = rest.markers as Array<Record<string, unknown>>;
    assert.ok(restMarkers.some((marker) => marker.kind === 'summary' && marker.ts_ms === null));
    assert.equal(rest.next_cursor, null);

    const human = await run(process.execPath, [
      cli, 'sessions', 'markers', 'claude', 'claude-markers', '--db', db, '--no-warning',
    ], { env });
    assert.match(human.stdout, /compaction_boundary  compact_boundary/);
    for (const line of human.stdout.trim().split('\n')) {
      if (line.startsWith('more available')) continue;
      assert.equal(line.split('  ').length, 6, `marker row keeps six columns: ${line}`);
    }

    const usageJson = await run(process.execPath, [
      cli, 'sessions', 'usage', 'claude', 'claude-markers', '--db', db, '--json', '--no-warning',
    ], { env });
    const summary = JSON.parse(usageJson.stdout) as Record<string, unknown>;
    assert.equal(summary.contract_version, SESSION_USAGE_CONTRACT_VERSION);
    assert.equal(summary.request_count, 1);
    assert.equal((summary.usage as Record<string, unknown>).input_tokens, 3);
    assert.equal((summary.usage as Record<string, unknown>).cache_write_tokens, 40);
    assert.equal((summary.usage as Record<string, unknown>).reported_cost_usd, null);

    const usageHuman = await run(process.execPath, [
      cli, 'sessions', 'usage', 'claude', 'claude-markers', '--db', db, '--no-warning',
    ], { env });
    assert.match(usageHuman.stdout, /1 of 1 request\(s\) with usage/);
    assert.match(usageHuman.stdout, /input=3 output=7 cache_read=100 cache_write=40/);
    assert.match(usageHuman.stdout, /reported cost: none/);

    await assert.rejects(
      run(process.execPath, [cli, 'sessions', 'usage', 'claude', '--db', db, '--no-warning'], { env }),
      (error: unknown) => isUsageFailure(error, 'sessions usage requires SOURCE and SESSION_ID'),
    );
    await assert.rejects(
      run(process.execPath, [cli, 'sessions', 'markers', 'claude', 'claude-markers', '--local', '--db', db, '--no-warning'], { env }),
      (error: unknown) => isUsageFailure(error, 'sessions markers does not accept --local'),
    );
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('topology commands require SOURCE and SESSION_ID and reject location scope', async () => {
  for (const subcommand of ['relationships', 'tree']) {
    await assert.rejects(
      run(process.execPath, [cli, 'sessions', subcommand, '--no-warning']),
      (error: unknown) => isUsageFailure(error, `sessions ${subcommand} requires SOURCE and SESSION_ID`),
    );
    await assert.rejects(
      run(process.execPath, [cli, 'sessions', subcommand, 'codex', 'root', 'extra', '--no-warning']),
      (error: unknown) => isUsageFailure(error, 'does not accept positional argument'),
    );
    await assert.rejects(
      run(process.execPath, [cli, 'sessions', subcommand, 'codex', 'root', '--remote', '--no-warning']),
      (error: unknown) => isUsageFailure(error, 'does not accept --local, --remote, or --all'),
    );
  }
});

test('scope flags are boolean, default to local, and are mutually exclusive', async () => {
  const root = await mkdtemp(join(tmpdir(), 'relayhistory-cli-scope-'));
  const db = join(root, 'missing.db');
  const env = { ...process.env, HOME: root, USERPROFILE: root, XDG_DATA_HOME: join(root, 'share') };
  try {
    const readEmpty = async (args: string[]) => {
      try {
        return await run(process.execPath, args, { env });
      } catch (error) {
        return error as NodeJS.ErrnoException & { stdout: string };
      }
    };
    const implicit = await readEmpty([cli, 'sessions', 'list', '--db', db, '--json', '--no-warning']);
    const explicit = await readEmpty([cli, '--json', 'sessions', 'list', '--local', '--db', db, '--no-warning']);
    assert.deepEqual(JSON.parse(implicit.stdout), JSON.parse(explicit.stdout));
    const remote = await run(process.execPath, [cli, 'sessions', 'list', '--remote', '--db', db, '--json', '--no-warning'], { env });
    assert.deepEqual(JSON.parse(remote.stdout), {
      contract_version: 4, scope: 'remote', sessions: [], next_cursor: null,
    });

    await assert.rejects(
      run(process.execPath, [cli, 'sessions', 'list', '--local', '--remote', '--db', db, '--no-warning']),
      (error: unknown) => typeof error === 'object' && error !== null
        && 'stderr' in error
        && String(error.stderr).includes('--local, --remote, and --all are mutually exclusive'),
    );
    await assert.rejects(
      run(process.execPath, [cli, 'sessions', 'list', '--remote=false', '--db', db, '--no-warning']),
      (error: unknown) => isUsageFailure(error, '--remote does not take a value'),
    );
    await assert.rejects(
      run(process.execPath, [cli, 'sessions', 'list', '--remote', 'false', '--db', db, '--no-warning']),
      (error: unknown) => isUsageFailure(error, '--remote does not take a value'),
    );
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('commands reject surplus positional arguments with usage exit 2', async () => {
  for (const args of [
    ['sessions', 'list', 'extra'],
    ['sessions', 'discover', 'extra'],
    ['sessions', 'tools', 'claude', 'session-id', 'extra'],
    ['sessions', 'edits', 'claude', 'session-id', 'extra'],
    ['recent', '1', 'extra'],
    ['session', 'session-id', 'extra'],
    ['events', 'session-id', 'extra'],
    ['stats', 'extra'],
    ['sync', 'extra'],
  ]) {
    await assert.rejects(
      run(process.execPath, [cli, ...args, '--no-warning']),
      (error: unknown) => isUsageFailure(error, 'does not accept positional argument'),
      args.join(' '),
    );
  }
});

test('identity commands reject location scope instead of silently ignoring it', async () => {
  for (const command of ['session', 'events']) {
    await assert.rejects(
      run(process.execPath, [cli, command, 'session-id', '--remote', '--no-warning']),
      (error: unknown) => typeof error === 'object' && error !== null
        && 'stderr' in error
        && String(error.stderr).includes('does not accept --local, --remote, or --all'),
    );
  }
});

test('unknown, missing-value, and command-inapplicable flags fail with usage exit 2', async () => {
  for (const { args, message } of [
    { args: ['sessions', 'list', '--remtoe'], message: "unknown option '--remtoe'" },
    { args: ['sessions', 'list', '--db'], message: '--db requires a value' },
    { args: ['sessions', 'list', '--source'], message: '--source requires a value' },
    { args: ['sessions', 'list', '--project'], message: '--project requires a value' },
    { args: ['sessions', 'list', '--version'], message: 'sessions list does not accept --version' },
    { args: ['sessions', 'list', '-V'], message: 'sessions list does not accept --version' },
    { args: ['stats', '--source', 'codex'], message: 'stats does not accept --source' },
    { args: ['stats', '--by-cwd', 'true'], message: '--by-cwd does not take a value' },
    { args: ['search', 'q', '--by-cwd'], message: 'search does not accept --by-cwd' },
  ]) {
    await assert.rejects(
      run(process.execPath, [cli, ...args, '--no-warning']),
      (error: unknown) => isUsageFailure(error, message),
      args.join(' '),
    );
  }
});

test('search preserves a multi-word positional query', async () => {
  const root = await mkdtemp(join(tmpdir(), 'relayhistory-cli-search-'));
  const env = { ...process.env, HOME: root, USERPROFILE: root, XDG_DATA_HOME: join(root, 'share') };
  try {
    await assert.rejects(
      run(process.execPath, [
        cli, 'search', 'two', 'word query', '--db', join(root, 'missing.db'), '--json', '--no-warning',
      ], { env }),
      (error: unknown) => typeof error === 'object' && error !== null
        && 'stdout' in error && JSON.parse(String(error.stdout)).status === 'empty',
    );
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

async function seedCodexSession(root: string, home: string, db: string): Promise<void> {
  const codex = join(home, '.codex', 'sessions', '2026', '09', '07');
  await mkdir(codex, { recursive: true });
  await writeFile(join(codex, 'rollout-codex-1.jsonl'), `${JSON.stringify({
    timestamp: '2026-09-07T20:00:00.000Z', type: 'session_meta',
    payload: { id: 'codex-demo-1', cwd: '/work/demo' },
  })}\n${JSON.stringify({
    timestamp: '2026-09-07T20:00:01.000Z', type: 'event_msg',
    payload: { type: 'user_message', message: 'fix the flaky auth refresh test in refresh.ts' },
  })}\n`);
  const env = { ...process.env, HOME: home, USERPROFILE: home };
  await run(process.execPath, [cli, 'sessions', 'discover', '--source', 'codex', '--db', db, '--no-warning'], { env });
  await run(process.execPath, [cli, 'sync', '--db', db, '--no-warning'], { env });
}

test('resume prints the best matching session\'s native resume command', async () => {
  const root = await mkdtemp(join(tmpdir(), 'relayhistory-cli-resume-'));
  const home = join(root, 'home');
  const db = join(root, 'history.db');
  try {
    await seedCodexSession(root, home, db);
    const human = await run(process.execPath, [cli, 'resume', 'auth refresh', '--db', db, '--no-warning']);
    assert.equal(human.stdout.trim(), 'cd /work/demo && codex resume codex-demo-1');

    const json = await run(process.execPath, [cli, 'resume', 'auth refresh', '--db', db, '--json', '--no-warning']);
    const parsed = JSON.parse(json.stdout) as Record<string, unknown>;
    assert.equal(parsed.session_id, 'codex-demo-1');
    assert.equal(parsed.resume_cmd, 'cd /work/demo && codex resume codex-demo-1');
    // A resumable session's JSON never carries the unavailability explanation.
    assert.equal('resume_unavailable_reason' in parsed, false);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('resume rejects an unknown flag with a documented --db option', async () => {
  await assert.rejects(
    run(process.execPath, [cli, 'resume', 'query', '--after', '{}', '--no-warning']),
    (error: unknown) => isUsageFailure(error, 'resume does not accept --after')
      && typeof error === 'object' && error !== null && 'stderr' in error
      && String(error.stderr).includes('resume QUERY... [--local | --remote | --all] [--db PATH]'),
  );
});

test('resume fails loudly when nothing matches', async () => {
  const root = await mkdtemp(join(tmpdir(), 'relayhistory-cli-resume-empty-'));
  const home = join(root, 'home');
  const db = join(root, 'history.db');
  const env = { ...process.env, HOME: home, USERPROFILE: home, XDG_DATA_HOME: join(home, 'share') };
  try {
    await seedCodexSession(root, home, db);
    await assert.rejects(
      run(process.execPath, [cli, 'resume', 'no such session anywhere', '--db', db, '--no-warning'], { env }),
      (error: unknown) => typeof error === 'object' && error !== null
        && 'stderr' in error && String(error.stderr).includes('No session found'),
    );
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('pack formats matching entries with resume commands and respects a token budget', async () => {
  const root = await mkdtemp(join(tmpdir(), 'relayhistory-cli-pack-'));
  const home = join(root, 'home');
  const db = join(root, 'history.db');
  try {
    await seedCodexSession(root, home, db);
    const human = await run(process.execPath, [cli, 'pack', 'auth refresh', '--db', db, '--no-warning']);
    assert.match(human.stdout, /^=== ai-hist pack: "auth refresh" \| .+ \| 1 entries ===/);
    assert.match(human.stdout, /\[1\/1\] #\d+ {2}.+ {2}codex {2}\/work\/demo/);
    assert.match(human.stdout, /Resume: cd \/work\/demo && codex resume codex-demo-1/);

    const truncated = await run(process.execPath, [
      cli, 'pack', 'auth refresh', '--db', db, '--tokens', '2', '--no-warning',
    ]);
    assert.match(truncated.stdout, /fix the \.\.\.\n/);

    const json = await run(process.execPath, [cli, 'pack', 'auth refresh', '--db', db, '--json', '--no-warning']);
    const parsed = JSON.parse(json.stdout) as { entries: Array<Record<string, unknown>> };
    assert.equal(parsed.entries.length, 1);
    assert.equal(parsed.entries[0]?.resume_cmd, 'cd /work/demo && codex resume codex-demo-1');
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('pack defaults to the native command\'s 10-entry limit, not search\'s general default', async () => {
  const root = await mkdtemp(join(tmpdir(), 'relayhistory-cli-pack-limit-'));
  const home = join(root, 'home');
  const db = join(root, 'history.db');
  const codex = join(home, '.codex', 'sessions', '2026', '09', '07');
  try {
    await mkdir(codex, { recursive: true });
    for (let i = 1; i <= 12; i++) {
      const metaLine = JSON.stringify({
        timestamp: `2026-09-07T20:${String(i).padStart(2, '0')}:00.000Z`, type: 'session_meta',
        payload: { id: `codex-limit-${i}`, cwd: '/work/demo' },
      });
      const messageLine = JSON.stringify({
        timestamp: `2026-09-07T20:${String(i).padStart(2, '0')}:01.000Z`, type: 'event_msg',
        payload: { type: 'user_message', message: `entry ${i} shared-limit-keyword` },
      });
      await writeFile(join(codex, `rollout-codex-${i}.jsonl`), `${metaLine}\n${messageLine}\n`);
    }
    const env = { ...process.env, HOME: home, USERPROFILE: home };
    await run(process.execPath, [cli, 'sessions', 'discover', '--source', 'codex', '--db', db, '--no-warning'], { env });
    await run(process.execPath, [cli, 'sync', '--db', db, '--no-warning'], { env });

    const defaultLimit = await run(process.execPath, [cli, 'pack', 'shared-limit-keyword', '--db', db, '--json', '--no-warning']);
    const defaultParsed = JSON.parse(defaultLimit.stdout) as { entries: unknown[] };
    assert.equal(defaultParsed.entries.length, 10);

    const explicitLimit = await run(process.execPath, [
      cli, 'pack', 'shared-limit-keyword', '--db', db, '--limit', '3', '--json', '--no-warning',
    ]);
    const explicitParsed = JSON.parse(explicitLimit.stdout) as { entries: unknown[] };
    assert.equal(explicitParsed.entries.length, 3);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('pack truncates by Unicode code point, not UTF-16 code unit, so it never splits a surrogate pair', async () => {
  const root = await mkdtemp(join(tmpdir(), 'relayhistory-cli-pack-unicode-'));
  const home = join(root, 'home');
  const db = join(root, 'history.db');
  const codex = join(home, '.codex', 'sessions', '2026', '09', '07');
  try {
    await mkdir(codex, { recursive: true });
    // U+1F600 is a surrogate pair in UTF-16 (2 code units, 1 code point).
    // A code-unit-based slice at length 3 would cut it in half.
    const message = '😀😀 emoji-unicode-keyword rest of the message that keeps going';
    await writeFile(join(codex, 'rollout-codex-1.jsonl'), `${JSON.stringify({
      timestamp: '2026-09-07T20:00:00.000Z', type: 'session_meta',
      payload: { id: 'codex-unicode-1', cwd: '/work/demo' },
    })}\n${JSON.stringify({
      timestamp: '2026-09-07T20:00:01.000Z', type: 'event_msg',
      payload: { type: 'user_message', message },
    })}\n`);
    const env = { ...process.env, HOME: home, USERPROFILE: home };
    await run(process.execPath, [cli, 'sessions', 'discover', '--source', 'codex', '--db', db, '--no-warning'], { env });
    await run(process.execPath, [cli, 'sync', '--db', db, '--no-warning'], { env });

    const json = await run(process.execPath, [
      cli, 'pack', 'emoji-unicode-keyword', '--db', db, '--tokens', '1', '--json', '--no-warning',
    ]);
    const parsed = JSON.parse(json.stdout) as { entries: Array<{ prompt: string }> };
    // Every character of the truncated prefix must remain a well-formed
    // code point — no lone (unpaired) surrogate.
    for (const char of parsed.entries[0]?.prompt ?? '') {
      const code = char.codePointAt(0) ?? 0;
      assert.ok(code < 0xD800 || code > 0xDFFF, `lone surrogate in truncated prompt: ${JSON.stringify(parsed.entries[0]?.prompt)}`);
    }
    assert.equal(Array.from(parsed.entries[0]?.prompt ?? '').length, 4);

    const human = await run(process.execPath, [
      cli, 'pack', 'emoji-unicode-keyword', '--db', db, '--tokens', '1', '--no-warning',
    ]);
    assert.match(human.stdout, /😀😀 e\.\.\./);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('pack rejects a negative or fractional --tokens instead of silently misinterpreting it', async () => {
  // The generic arg parser reads a leading '-' as "the next flag", not a
  // negative value, so a negative number can only reach our validator via
  // the inline `--flag=value` form; the space-separated form is covered by
  // the pre-existing "--tokens requires a value" usage error instead.
  for (const args of [['--tokens=-1'], ['--tokens', '0.5']]) {
    await assert.rejects(
      run(process.execPath, [cli, 'pack', 'query', ...args, '--no-warning']),
      (error: unknown) => typeof error === 'object' && error !== null && 'stderr' in error
        && String(error.stderr).includes('--tokens must be a non-negative integer'),
      args.join(' '),
    );
  }
});

test('pack reports no results distinctly from a match, and exits non-zero', async () => {
  const root = await mkdtemp(join(tmpdir(), 'relayhistory-cli-pack-empty-'));
  const home = join(root, 'home');
  const db = join(root, 'history.db');
  const env = { ...process.env, HOME: home, USERPROFILE: home, XDG_DATA_HOME: join(home, 'share') };
  try {
    await seedCodexSession(root, home, db);
    await assert.rejects(
      run(process.execPath, [cli, 'pack', 'nothing matches this', '--db', db, '--no-warning'], { env }),
      (error: unknown) => typeof error === 'object' && error !== null
        && 'stdout' in error && String(error.stdout).includes('No results.'),
    );
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('resume and pack reject flags the other commands accept but these do not', async () => {
  await assert.rejects(
    run(process.execPath, [cli, 'resume', 'query', '--project', '/work', '--no-warning']),
    (error: unknown) => isUsageFailure(error, 'resume does not accept --project'),
  );
  await assert.rejects(
    run(process.execPath, [cli, 'pack', 'query', '--after-source', 'codex', '--no-warning']),
    (error: unknown) => isUsageFailure(error, 'pack does not accept --after-source'),
  );
});

test('--help flag works on local root commands with exit code 0', async () => {
  for (const args of [['--help'], ['-h'], ['help']]) {
    const rootHelp = await run(process.execPath, [cli, ...args]);
    assert.equal(rootHelp.stderr, '');
    assert.match(rootHelp.stdout, /Usage:/);
    assert.match(rootHelp.stdout, /ai-hist \[--no-bootstrap\] \[--db PATH\] \[--json\] \[--help\]/);
  }

  const sessionsHelp = await run(process.execPath, [cli, 'sessions', '--help']);
  assert.equal(sessionsHelp.stderr, '');
  assert.match(sessionsHelp.stdout, /Usage:/);
});

test('--help is rejected on commands that do not advertise it', async () => {
  await assert.rejects(
    run(process.execPath, [cli, 'sync', '--help', '--no-warning']),
    (error: unknown) => isUsageFailure(error, 'sync does not accept --help'),
  );
});

test('unknown subcommands name what was unknown instead of generic parse error', async () => {
  // Test unknown root command
  await assert.rejects(
    run(process.execPath, [cli, 'unknown-command', '--no-warning']),
    (error: unknown) => isUsageFailure(error, "unknown command 'unknown-command'"),
  );

  // Test unknown sessions subcommand
  await assert.rejects(
    run(process.execPath, [cli, 'sessions', 'unknown-subcommand', '--no-warning']),
    (error: unknown) => isUsageFailure(error, "unknown sessions subcommand 'unknown-subcommand'"),
  );
});

test('sessions relationships names the other end of a continuity edge', async () => {
  const root = await mkdtemp(join(tmpdir(), 'relayhistory-cli-continuity-'));
  const home = join(root, 'home');
  const projects = join(home, '.claude', 'projects', 'app');
  const db = join(root, 'history.db');
  await mkdir(projects, { recursive: true });
  const line = (row: Record<string, unknown>) => `${JSON.stringify(row)}\n`;
  await writeFile(join(projects, 'origin.jsonl'),
    line({
      sessionId: 'origin', uuid: 'origin-u', parentUuid: null, type: 'user', cwd: '/work/app',
      message: { role: 'user', content: 'start' }, timestamp: '2026-08-31T10:00:00Z',
    })
    + line({
      sessionId: 'origin', uuid: 'origin-a', parentUuid: 'origin-u', type: 'assistant', cwd: '/work/app',
      message: { role: 'assistant', content: 'ok' }, timestamp: '2026-08-31T10:00:01Z',
    }));
  await writeFile(join(projects, 'continued.jsonl'), line({
    sessionId: 'continued', uuid: 'cont-u', parentUuid: 'origin-a', type: 'user', cwd: '/work/app',
    message: { role: 'user', content: 'carry on' }, timestamp: '2026-08-31T11:00:00Z',
  }));
  const env = { ...process.env, HOME: home, USERPROFILE: home };
  try {
    await run(process.execPath, [cli, 'sync', '--db', db, '--no-warning'], { env });

    // Asked about the origin, the line names the branch.
    const parentSide = await run(process.execPath, [
      cli, 'sessions', 'relationships', 'claude', 'origin', '--db', db, '--no-warning',
    ], { env });
    assert.match(parentSide.stdout, /1 continuity relationship\(s\)/);
    assert.match(parentSide.stdout, /continuity {2}continued {2}continuation/);

    // Asked about the branch, the same row names the origin — not the
    // session that was just asked about.
    const childSide = await run(process.execPath, [
      cli, 'sessions', 'relationships', 'claude', 'continued', '--db', db, '--no-warning',
    ], { env });
    assert.match(childSide.stdout, /1 continuity relationship\(s\)/);
    assert.match(childSide.stdout, /continuity {2}origin {2}continuation/);
    assert.doesNotMatch(childSide.stdout, /continuity {2}continued/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('human search output labels a session-event match by role and kind', () => {
  const base = { id: 1, timestampMs: 5, source: 'claude', sessionId: 's', prompt: 'hello' };
  assert.equal(humanLine({ ...base, matchSource: 'history', role: 'user', kind: 'text' }), '5  claude  s  hello');
  assert.equal(
    humanLine({ ...base, matchSource: 'session_event', role: 'assistant', kind: 'tool_use' }),
    '5  claude:assistant:tool_use  s  hello',
  );
});
