import assert from 'node:assert/strict';
import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import test from 'node:test';
import {
  FULL_SESSION_KINDS, SESSION_HYDRATION_CONTRACT_VERSION, SessionSourceUnavailableError,
  discoverSessions, getSessionEvents, getSessionEventsPage, getSessionFileEdits,
  getSessionToolCalls, hydrateSession, listSessionCatalogPage, recent, search, stats, sync,
  type CatalogCursor, type CatalogSession, type EventCursor,
} from './index.js';

const sqlite = await import('node:sqlite').catch(() => null);
const needsNodeSqlite = sqlite ? false : 'node:sqlite requires Node >= 22';

// These fixtures exercise public SDK/native contracts before package moves.
// Clear every provider/transport override used by these operations so neither
// credentials nor history from the operator's environment enter the fixture.
const ENVIRONMENT = [
  'HOME', 'USERPROFILE', 'XDG_DATA_HOME', 'OPENCODE_DB', 'TRAJECTORY_ROOT', 'AI_HIST_DB',
  'RELAYHISTORY_HOME', 'RELAYHISTORY_BASE_URL', 'AI_HIST_BASE_URL',
  'RELAYHISTORY_CLAUDE_CREDENTIALS', 'RELAYHISTORY_CLAUDE_API_BASE_URL',
  'RELAYCAST_API_KEY', 'RELAYCAST_WORKSPACE_ID', 'RELAYCAST_BASE_URL',
];

async function withFixture(
  body: (fixture: { home: string; dbPath: string; cloudHome: string }) => Promise<void>,
): Promise<void> {
  const root = await mkdtemp(join(tmpdir(), 'relayhistory-local-contract-'));
  const saved = new Map(ENVIRONMENT.map((name) => [name, process.env[name]]));
  for (const name of ENVIRONMENT) delete process.env[name];
  const home = join(root, 'home');
  const cloudHome = join(root, 'commercial');
  process.env.HOME = home;
  process.env.USERPROFILE = home;
  process.env.XDG_DATA_HOME = join(home, '.local', 'share');
  process.env.RELAYHISTORY_HOME = cloudHome;
  try {
    await mkdir(home, { recursive: true });
    await body({ home, cloudHome, dbPath: join(root, 'history.db') });
  } finally {
    for (const [name, value] of saved) {
      if (value === undefined) delete process.env[name]; else process.env[name] = value;
    }
    await rm(root, { recursive: true, force: true });
  }
}

async function claudeSession(home: string, sessionId: string): Promise<string> {
  const directory = join(home, '.claude', 'projects', '-work-contract');
  await mkdir(directory, { recursive: true });
  const path = join(directory, `${sessionId}.jsonl`);
  const common = { sessionId, cwd: '/work/contract', timestamp: '2026-09-01T10:00:00.000Z' };
  await writeFile(path, [
    { ...common, type: 'user', uuid: `${sessionId}-user`, message: { role: 'user', content: `contractneedle ${sessionId}` } },
    { ...common, type: 'assistant', uuid: `${sessionId}-assistant`, parentUuid: `${sessionId}-user`, message: {
      role: 'assistant', content: [{ type: 'tool_use', id: `${sessionId}-edit`, name: 'Edit', input: {
        file_path: '/work/contract/file.ts', old_string: 'before', new_string: 'after',
      } }],
    } },
    { ...common, type: 'user', uuid: `${sessionId}-result`, parentUuid: `${sessionId}-assistant`, message: {
      role: 'user', content: [{ type: 'tool_result', tool_use_id: `${sessionId}-edit`, content: 'done',
        toolUseResult: { filePath: '/work/contract/file.ts', structuredPatch: '@@\n-before\n+after\n' } }],
    } },
  ].map((record) => JSON.stringify(record)).join('\n') + '\n');
  return path;
}

test('absent commercial auth allows every cached remote query API', async () => {
  await withFixture(async ({ dbPath }) => {
    assert.deepEqual(await search('contractneedle', { dbPath, scope: 'remote' }), []);
    assert.deepEqual(await recent({ dbPath, scope: 'remote' }), []);
    const page = await listSessionCatalogPage({ dbPath, scope: 'remote' });
    assert.equal(page.scope, 'remote');
    assert.deepEqual(page.sessions, []);
    const counts = await stats({ dbPath, scope: 'remote' });
    assert.equal(counts.scope, 'remote');
    assert.equal(counts.total, 0);
  });
});

test('malformed commercial auth leaves cached all-scope queries unchanged', async () => {
  await withFixture(async ({ cloudHome, dbPath }) => {
    const stages = join(cloudHome, 'stages');
    await mkdir(stages, { recursive: true });
    await writeFile(join(stages, 'broken.auth.json'), '{not-json', { mode: 0o600 });
    assert.deepEqual(await search('contractneedle', { dbPath, scope: 'all' }), []);
    assert.deepEqual(await recent({ dbPath, scope: 'all' }), []);
    assert.equal((await listSessionCatalogPage({ dbPath, scope: 'all' })).scope, 'all');
    assert.equal((await stats({ dbPath, scope: 'all' })).scope, 'all');
  });
});

test('local discovery, hydration and cached evidence survive malformed commercial auth and repeated ingestion', async () => {
  await withFixture(async ({ home, cloudHome, dbPath }) => {
    const stages = join(cloudHome, 'stages');
    await mkdir(stages, { recursive: true });
    await writeFile(join(stages, 'broken.auth.json'), '{not-json', { mode: 0o600 });
    await claudeSession(home, 'contract-session');
    await discoverSessions({ dbPath, scope: 'local', sources: ['claude'] });
    const hydrated = await hydrateSession({ source: 'claude', sessionId: 'contract-session', dbPath });
    assert.equal(hydrated.presence, 'local');
    assert.equal(hydrated.discoveryState, 'full');
    assert.equal(hydrated.contractVersion, SESSION_HYDRATION_CONTRACT_VERSION);
    assert.equal(hydrated.capability, 'full');
    assert.deepEqual(hydrated.coverage, [...FULL_SESSION_KINDS]);
    assert.equal(
      hydrated.diagnostics.some((item) => item.code === 'HYDRATION_PARTIAL_COVERAGE'),
      false,
    );

    const readEvidence = async () => ({
      events: await getSessionEvents('contract-session', { source: 'claude', dbPath, limit: 1 }),
      calls: await getSessionToolCalls('claude', 'contract-session', { dbPath, limit: 1 }),
      edits: await getSessionFileEdits('claude', 'contract-session', { dbPath, limit: 1 }),
    });
    const original = await readEvidence();
    assert.ok(original.events.length >= 3);
    assert.equal(original.calls.length, 1);
    assert.equal(original.edits.length, 1);
    for (const event of original.events) {
      assert.equal(event.source, 'claude');
      assert.equal(event.sessionId, 'contract-session');
      assert.ok(event.eventUid.length > 0);
    }
    assert.equal(new Set(original.events.map((event) => event.eventUid)).size, original.events.length);
    assert.equal(original.calls[0].messageId, 'contract-session-assistant');
    assert.equal(original.edits[0].toolUseId, original.calls[0].toolUseId);

    // Every timestamp is equal: continuation must use the stable row ID too.
    const first = await getSessionEventsPage('contract-session', { source: 'claude', dbPath, limit: 1 });
    assert.ok(first.nextCursor);
    const tail = await getSessionEvents('contract-session', { source: 'claude', dbPath });
    const resumed = await getSessionEventsPage('contract-session', {
      source: 'claude', dbPath, after: JSON.parse(JSON.stringify(first.nextCursor)) as EventCursor,
    });
    assert.deepEqual(resumed.events, tail.slice(1));
    assert.equal(resumed.nextCursor, null);

    await sync({ dbPath, scope: 'local' });
    await hydrateSession({ source: 'claude', sessionId: 'contract-session', dbPath });
    // These record IDs, event UIDs, raw patches and arguments are the existing
    // evidence contract a future exporter must preserve across retry/restart.
    assert.deepEqual(await readEvidence(), original);
    // Search spans prompts and session events; the prompt itself is the
    // `history` match.
    const prompts = (await search('contractneedle', { dbPath, scope: 'local' }))
      .filter((match) => match.matchSource === 'history');
    assert.equal(prompts.length, 1);
    assert.deepEqual(prompts[0].locations, ['local']);
    assert.deepEqual(
      await recent({ dbPath, scope: 'local' }),
      prompts.map(({ matchSource: _source, role: _role, kind: _kind, ...entry }) => entry),
    );
    assert.equal((await stats({ dbPath, scope: 'local' })).total, 1);
  });
});

// A minimal OpenCode session still exercises the complete parser contract:
// full capability describes the evidence kinds the provider can produce, not
// whether this particular one-turn fixture happened to use a tool.
async function opencodeSession(home: string, sessionId: string): Promise<void> {
  const { DatabaseSync } = await import('node:sqlite');
  const path = join(home, '.local', 'share', 'opencode', 'opencode.db');
  await mkdir(dirname(path), { recursive: true });
  const db = new DatabaseSync(path);
  db.exec(`
    CREATE TABLE session (id TEXT PRIMARY KEY, directory TEXT, time_created INTEGER);
    CREATE TABLE message (id TEXT PRIMARY KEY, session_id TEXT, time_created INTEGER, data TEXT);
    CREATE TABLE part (id TEXT PRIMARY KEY, message_id TEXT, session_id TEXT, time_created INTEGER, data TEXT);
  `);
  db.prepare('INSERT INTO session VALUES (?, ?, ?)').run(sessionId, '/work/contract', 1);
  db.prepare('INSERT INTO message VALUES (?, ?, ?, ?)').run('m1', sessionId, 1, JSON.stringify({ role: 'user' }));
  db.prepare('INSERT INTO part VALUES (?, ?, ?, ?, ?)').run(
    'p1', 'm1', sessionId, 2, JSON.stringify({ type: 'text', text: 'openeedle prompt' }),
  );
  db.close();
}

test('OpenCode reports full capability and stores normalized events', { skip: needsNodeSqlite }, async () => {
  await withFixture(async ({ home, dbPath }) => {
    await opencodeSession(home, 'oc-contract');
    await discoverSessions({ dbPath, scope: 'local', sources: ['opencode'] });
    const hydrated = await hydrateSession({ source: 'opencode', sessionId: 'oc-contract', dbPath });

    assert.equal(hydrated.contractVersion, SESSION_HYDRATION_CONTRACT_VERSION);
    assert.equal(hydrated.capability, 'full');
    assert.deepEqual(hydrated.coverage, [...FULL_SESSION_KINDS]);
    assert.equal(hydrated.evidence.prompts, 1);
    assert.equal(hydrated.evidence.events, 1);
    assert.equal((await search('openeedle', { dbPath, scope: 'local', role: 'user' }))
      .filter((match) => match.matchSource === 'history').length, 1);
    assert.equal(
      hydrated.diagnostics.some((item) => item.code === 'HYDRATION_PARTIAL_COVERAGE'),
      false,
    );
  });
});

test('catalog cursors retain tied session identities and hydration failure leaves cached evidence readable', async () => {
  await withFixture(async ({ home, dbPath }) => {
    const paths = await Promise.all(['session-c', 'session-a', 'session-b'].map((id) => claudeSession(home, id)));
    await sync({ dbPath, scope: 'local' });
    const all = await listSessionCatalogPage({ dbPath, scope: 'local', limit: 100 });
    assert.equal(all.sessions.length, 3);
    const paged: CatalogSession[] = [];
    let after: CatalogCursor | undefined;
    do {
      const page = await listSessionCatalogPage({ dbPath, scope: 'local', limit: 1, after });
      paged.push(...page.sessions);
      assert.ok(paged.length <= all.sessions.length, 'cursor must not repeat a page');
      after = page.nextCursor ? JSON.parse(JSON.stringify(page.nextCursor)) as CatalogCursor : undefined;
    } while (after);
    assert.deepEqual(paged, all.sessions);
    assert.equal(new Set(paged.map((row) => `${row.source}:${row.sessionId}`)).size, 3);

    const before = await getSessionEvents('session-c', { source: 'claude', dbPath });
    assert.ok(before.length > 0);
    await rm(paths[0]);
    await assert.rejects(
      () => hydrateSession({ source: 'claude', sessionId: 'session-c', dbPath }),
      (error: unknown) => error instanceof SessionSourceUnavailableError
        && error.code === 'SESSION_SOURCE_UNAVAILABLE'
        && error.message.includes('disappeared after discovery'),
    );
    assert.deepEqual(await getSessionEvents('session-c', { source: 'claude', dbPath }), before);
    assert.deepEqual((await listSessionCatalogPage({ dbPath, scope: 'local', limit: 100 })).sessions, all.sessions);
  });
});

test('per-message raw provider facts reach the SDK unnormalized', async () => {
  await withFixture(async ({ home, dbPath }) => {
    const directory = join(home, '.claude', 'projects', '-work-facts');
    await mkdir(directory, { recursive: true });
    const common = { sessionId: 'facts-session', cwd: '/work/facts', version: '2.1.96' };
    await writeFile(join(directory, 'facts-session.jsonl'), [
      { ...common, type: 'user', uuid: 'facts-user', timestamp: '2026-09-01T10:00:00.000Z',
        message: { role: 'user', content: 'contractneedle facts' } },
      // Still in flight: no stop_reason, and the SDK must report that as null
      // rather than inventing a terminal reason.
      { ...common, type: 'assistant', uuid: 'facts-open', parentUuid: 'facts-user', requestId: 'req_open',
        isSidechain: false, timestamp: '2026-09-01T10:00:01.000Z',
        message: { role: 'assistant', stop_reason: null, content: [{ type: 'text', text: 'working' }] } },
      { ...common, type: 'assistant', uuid: 'facts-done', parentUuid: 'facts-open', requestId: 'req_done',
        isSidechain: false, timestamp: '2026-09-01T10:00:02.000Z',
        message: { role: 'assistant', stop_reason: 'end_turn', content: [{ type: 'text', text: 'finished' }] } },
    ].map((record) => JSON.stringify(record)).join('\n') + '\n');

    await discoverSessions({ dbPath, scope: 'local', sources: ['claude'] });
    await hydrateSession({ source: 'claude', sessionId: 'facts-session', dbPath });

    const events = await getSessionEvents('facts-session', { source: 'claude', dbPath });
    assert.deepEqual(
      events.map((event) => [event.requestId, event.stopReason, event.agentVersion, event.isSidechain]),
      [
        // The opening human turn records no flag at all, and a provider that
        // never says either way leaves it null -- a different fact from false.
        [null, null, '2.1.96', null],
        ['req_open', null, '2.1.96', false],
        ['req_done', 'end_turn', '2.1.96', false],
      ],
    );
    assert.deepEqual(events.map((event) => event.isMeta), [null, null, null]);
    assert.deepEqual(events.map((event) => event.turnId), [null, null, null]);
    // A genuine prompt and model output carry no control kind.
    assert.deepEqual(events.map((event) => event.controlKind), [null, null, null]);

    // A page carries the same shape as the whole-session read.
    const page = await getSessionEventsPage('facts-session', { source: 'claude', dbPath });
    assert.deepEqual(page.events, events);
  });
});
