//! Mandatory Node-API boundary for RelayHistory.
//!
//! This crate maps typed JavaScript requests to reusable Rust operations. It
//! contains no SQL, provider parsing, migration, or query semantics of its own.
#![deny(clippy::all)]

pub mod change_feed;
pub mod export;
pub mod session_store;
pub mod sources;

use std::path::{Path, PathBuf};

use ai_hist::history_search::{search_all, search_page as core_search_page, SearchRole, SearchRow};
use ai_hist::{
    default_db_path, open_db, open_db_readonly, recent as core_recent, relationship_capabilities,
    schema_is_catalog_read_current, schema_is_event_read_current, schema_is_evidence_read_current,
    schema_is_read_current, schema_is_relationship_read_current, session as core_session,
    session_children_page as core_session_children_page,
    session_events_page as core_session_events_page,
    session_file_edits_page as core_session_file_edits_page, session_locations,
    session_relationships as core_session_relationships,
    session_tool_calls_page as core_session_tool_calls_page, session_tree as core_session_tree,
    session_user_turns_page as core_session_user_turns_page,
    stats_scoped_by as core_stats_scoped_by, HistoryEntry, QueryFilter,
    RelationshipCapabilities as CoreRelationshipCapabilities,
    RelationshipCursor as CoreRelationshipCursor,
    RelationshipDiagnostic as CoreRelationshipDiagnostic,
    RelationshipKinds as CoreRelationshipKinds, SessionEvent as CoreSessionEvent,
    SessionEventCursor as CoreEventCursor, SessionEvidenceCursor as CoreEvidenceCursor,
    SessionFileEdit as CoreSessionFileEdit, SessionRelationship as CoreSessionRelationship,
    SessionRelationships as CoreSessionRelationships, SessionScope,
    SessionToolCall as CoreSessionToolCall, SessionTree as CoreSessionTree,
    SessionTreeNode as CoreSessionTreeNode, SessionTreeOptions as CoreSessionTreeOptions,
    SessionUserTurn as CoreSessionUserTurn, SessionUserTurnBlock as CoreSessionUserTurnBlock,
    DEFAULT_CHILDREN_PAGE_LIMIT, DEFAULT_TREE_MAX_DEPTH, DEFAULT_TREE_MAX_NODES,
    MAX_CHILDREN_PAGE_LIMIT, MAX_TREE_MAX_DEPTH, MAX_TREE_MAX_NODES,
    SESSION_EVIDENCE_CONTRACT_VERSION, SESSION_RELATIONSHIP_CONTRACT_VERSION,
};
use ai_hist::{recent_page as core_recent_page, HistoryCursor};
use ai_hist::{
    schema_is_usage_read_current, session_requests_page as core_session_requests_page,
    session_usage_summary as core_session_usage_summary, NormalizedUsage as CoreNormalizedUsage,
    SessionRequest as CoreSessionRequest, SessionRequestCursor as CoreRequestCursor,
    SessionUsageSummary as CoreSessionUsageSummary, SESSION_USAGE_CONTRACT_VERSION,
};
use napi::{Env, JsFunction};
use napi_derive::napi;
use serde::Serialize;

/// Bump whenever native object shapes or semantics require an SDK change.
/// 16 added `project_key` to catalog rows and session events, plus
/// `project_key_method` on the catalog row and the `project_key` listing
/// filter.
/// 17 adds the per-tool-result fidelity fields to session events and the
/// `getSessionUserTurnsPage` operation. It is 17 rather than 16 because that
/// work and the project-identity work were developed in parallel and both
/// claimed 16; a merged addon carries both, so it cannot answer with a
/// number either side already published.
/// 18 was claimed independently by the upstream `provider` field and the
/// per-request usage surface. The merged addon exposes both shapes, so it is
/// 19 rather than identifying itself as either incompatible contract 18.
/// 20 was claimed independently by the `historyExport` bridge, which moved
/// the upload lifecycle out of the addon, and by the `sessionStoreCall`
/// dispatcher below. The merged addon exposes both, so it is 21 rather than
/// answering with a number either incompatible contract 20 already used.
/// 21 adds the `sessionStoreCall` JSON dispatcher over the `SessionStore`
/// facade (markers, requests, usage summary, user turns, source
/// capabilities) and moves the SDK's request, usage and user-turn reads onto
/// it, alongside contract 20's `historyExport` bridge.
/// 22: `historyExport` serves snapshots that each hold one read transaction,
/// emits schema-version-2 records, and no longer accepts the upload-journal
/// operations (retention and compaction).
/// 23: `search` runs the shared `history_search::search_all` contract the CLI
/// uses — prompts and session events, a `role` option, a total
/// `(timestamp, id)` order — and returns `NativeSearchMatch` rows carrying
/// `matchSource`, `role` and `kind`.
/// 24: `search` and `recent` take inclusive `sinceMs`/`untilMs` and a keyset
/// `after` cursor, and `searchPage`/`recentPage` return a page with a
/// `nextCursor` computed by over-fetching one row.
/// 25 adds the change feed to `sessionStoreCall`: `changes` pages
/// `SessionStore::changes_since` and `commit_changes` moves a named consumer
/// cursor.
/// 26 adds `onStoreMigration` and `migrateStore`, so a front end can name
/// the one-time schema migration after an upgrade instead of appearing hung.
pub const NATIVE_CONTRACT_VERSION: u32 = 26;
const DEFAULT_LIMIT: i64 = 50;
const DEFAULT_EVENT_LIMIT: i64 = 200;

fn db_path(path: Option<String>) -> PathBuf {
    path.map(PathBuf::from).unwrap_or_else(default_db_path)
}

fn native_error(code: &str, error: impl std::fmt::Display) -> napi::Error {
    napi::Error::from_reason(format!("RELAYHISTORY_NATIVE::{code}::{error}"))
}

fn worker_error(error: impl std::fmt::Display) -> napi::Error {
    native_error("WORKER_FAILED", error)
}

fn database_error(path: &Path, error: impl std::fmt::Display) -> napi::Error {
    native_error(
        "DATABASE_OPEN_FAILED",
        format!("could not open {}: {error}", path.display()),
    )
}

fn validate_limit(limit: Option<i64>, default: i64, max: i64) -> napi::Result<i64> {
    let limit = limit.unwrap_or(default);
    if !(1..=max).contains(&limit) {
        return Err(native_error(
            "INVALID_ARGUMENT",
            format!("limit must be between 1 and {max} (got {limit})"),
        ));
    }
    Ok(limit)
}

/// Session identity is two required strings; an empty one would silently widen
/// a page to every row a provider ever recorded.
///
/// A padded value is rejected rather than trimmed, because the query is an
/// exact match: trimming for the emptiness check alone would answer
/// `" sess-1 "` with an empty page, and silently trimming would echo an
/// identity the caller did not ask for. This boundary rejects every other
/// invalid argument outright too.
fn validate_identity(value: String, field: &str) -> napi::Result<String> {
    if value.trim().is_empty() {
        return Err(native_error(
            "INVALID_ARGUMENT",
            format!("{field} must not be empty"),
        ));
    }
    if value.trim() != value {
        return Err(native_error(
            "INVALID_ARGUMENT",
            format!("{field} must not be padded with whitespace"),
        ));
    }
    Ok(value)
}

fn core_evidence_cursor(cursor: EvidenceCursor) -> CoreEvidenceCursor {
    CoreEvidenceCursor {
        ts_ms: cursor.ts_ms,
        id: cursor.id,
    }
}

fn evidence_cursor(cursor: CoreEvidenceCursor) -> EvidenceCursor {
    EvidenceCursor {
        ts_ms: cursor.ts_ms,
        id: cursor.id,
    }
}

fn parse_scope(scope: Option<String>) -> napi::Result<SessionScope> {
    match scope.as_deref().unwrap_or("local") {
        "local" => Ok(SessionScope::Local),
        "remote" => Ok(SessionScope::Remote),
        "all" => Ok(SessionScope::All),
        value => Err(native_error(
            "INVALID_ARGUMENT",
            format!("scope must be local, remote, or all (got '{value}')"),
        )),
    }
}

fn parse_search_role(role: Option<&str>) -> napi::Result<SearchRole> {
    SearchRole::parse(role.unwrap_or("all"))
        .map_err(|error| native_error("INVALID_ARGUMENT", format!("{error:#}")))
}

fn scope_name(scope: SessionScope) -> String {
    match scope {
        SessionScope::Local => "local",
        SessionScope::Remote => "remote",
        SessionScope::All => "all",
    }
    .to_string()
}

/// Reject remote-only acquisition that no configured remote connector can
/// serve — none configured at all, or a source filter that excludes every
/// configured one — keeping the SDK's stable `UNSUPPORTED_OPERATION`
/// taxonomy. The engine re-validates; this pre-check only classifies the
/// error.
fn ensure_acquisition_scope_supported(
    scope: SessionScope,
    operation: &str,
    sources: &[String],
    connectors: &ai_hist::remote::SourceConnectorSelection,
) -> napi::Result<()> {
    if scope == SessionScope::Remote {
        ai_hist::remote::ensure_selected_remote_connectors_configured_for(
            operation, sources, connectors,
        )
        .map_err(|error| native_error("UNSUPPORTED_OPERATION", format!("{error:#}")))?;
    }
    Ok(())
}

fn source_connector_selection(
    ids: Option<Vec<String>>,
) -> napi::Result<ai_hist::remote::SourceConnectorSelection> {
    ids.map(ai_hist::remote::SourceConnectorSelection::new)
        .transpose()
        .map(|selection| selection.unwrap_or_default())
        .map_err(|error| native_error("INVALID_ARGUMENT", error.to_string()))
}

/// Contract version implemented by this native addon.
#[napi]
pub fn native_contract_version() -> u32 {
    NATIVE_CONTRACT_VERSION
}

/// Call `callback` with `"started"`, then `"finished"` or `"failed"`, and the
/// database's path whenever an open in this process migrates an existing
/// database. Returns
/// false when a callback is already registered: the first registration wins.
///
/// The callback never keeps the process alive. It runs asynchronously on the
/// JS thread, so a caller that needs `finished` before exiting waits for it.
#[napi(
    ts_args_type = "callback: (event: 'started' | 'finished' | 'failed', dbPath: string | null) => void"
)]
pub fn on_store_migration(env: Env, callback: JsFunction) -> napi::Result<bool> {
    use napi::threadsafe_function::{
        ErrorStrategy, ThreadSafeCallContext, ThreadsafeFunction, ThreadsafeFunctionCallMode,
    };
    let mut notify: ThreadsafeFunction<(&'static str, Option<String>), ErrorStrategy::Fatal> =
        callback.create_threadsafe_function(
            0,
            |ctx: ThreadSafeCallContext<(&'static str, Option<String>)>| {
                let (event, path) = ctx.value;
                let path = match path {
                    Some(path) => ctx.env.create_string(&path)?.into_unknown(),
                    None => ctx.env.get_null()?.into_unknown(),
                };
                Ok(vec![ctx.env.create_string(event)?.into_unknown(), path])
            },
        )?;
    notify.unref(&env)?;
    Ok(ai_hist::observe_migrations(move |event, path| {
        let event = match event {
            ai_hist::MigrationEvent::Started => "started",
            ai_hist::MigrationEvent::Finished => "finished",
            ai_hist::MigrationEvent::Failed => "failed",
        };
        notify.call(
            (event, path.map(str::to_string)),
            ThreadsafeFunctionCallMode::NonBlocking,
        );
    }))
}

/// Run any outstanding schema migration now, creating the database if it
/// does not exist. The same work the first open of any operation would do.
#[napi]
pub async fn migrate_store(db_path: Option<String>) -> napi::Result<()> {
    let path = crate::db_path(db_path);
    napi::tokio::task::spawn_blocking(move || {
        open_db(&path)
            .map(drop)
            .map_err(|error| database_error(&path, format!("{error:#}")))
    })
    .await
    .map_err(worker_error)?
}

/// Optimization profile this addon was compiled with: `release` or `debug`.
/// Performance measurements are only meaningful against `release`.
#[napi]
pub fn native_build_profile() -> String {
    if cfg!(debug_assertions) {
        "debug".to_string()
    } else {
        "release".to_string()
    }
}

/// Where a newest-first history read stopped: its last row's
/// `(timestampMs, id)` and, for a search match, its `matchSource`.
#[napi(object)]
#[derive(Clone)]
pub struct NativeHistoryCursor {
    pub timestamp_ms: i64,
    pub id: i64,
    /// `history` (the default when absent) or `session_event`.
    pub match_source: Option<String>,
}

impl NativeHistoryCursor {
    fn into_core(self) -> HistoryCursor {
        HistoryCursor {
            timestamp_ms: self.timestamp_ms,
            id: self.id,
            match_source: self.match_source,
        }
    }

    fn from_core(cursor: HistoryCursor) -> Self {
        Self {
            timestamp_ms: cursor.timestamp_ms,
            id: cursor.id,
            match_source: cursor.match_source,
        }
    }
}

#[napi(object)]
#[derive(Default)]
pub struct HistoryQueryOptions {
    pub scope: Option<String>,
    pub db_path: Option<String>,
    pub source: Option<String>,
    pub project: Option<String>,
    pub tag: Option<String>,
    /// Deprecated: exclusive, so it skips rows tied on the boundary
    /// timestamp. Page with `after` instead.
    pub before_ms: Option<i64>,
    /// Inclusive lower timestamp bound.
    pub since_ms: Option<i64>,
    /// Inclusive upper timestamp bound.
    pub until_ms: Option<i64>,
    /// Continue after this row (the previous page's `nextCursor`).
    pub after: Option<NativeHistoryCursor>,
    pub limit: Option<i64>,
}

impl HistoryQueryOptions {
    /// Build and validate the filter, so an invalid window or cursor is
    /// `INVALID_ARGUMENT` with the message every surface uses.
    fn filter(&self, limit: i64) -> napi::Result<QueryFilter> {
        let filter = QueryFilter {
            scope: parse_scope(self.scope.clone())?,
            source: self.source.clone(),
            project: self.project.clone(),
            tag: self.tag.clone(),
            before_ms: self.before_ms,
            since_ms: self.since_ms,
            until_ms: self.until_ms,
            after: self.after.clone().map(NativeHistoryCursor::into_core),
            limit,
        };
        filter
            .validate()
            .map_err(|error| native_error("INVALID_ARGUMENT", format!("{error:#}")))?;
        Ok(filter)
    }
}

#[napi(object)]
#[derive(Default)]
pub struct SearchOptions {
    pub scope: Option<String>,
    pub db_path: Option<String>,
    pub source: Option<String>,
    pub project: Option<String>,
    pub tag: Option<String>,
    /// Deprecated: exclusive, so it skips rows tied on the boundary
    /// timestamp. Page with `after` instead.
    pub before_ms: Option<i64>,
    /// Inclusive lower timestamp bound.
    pub since_ms: Option<i64>,
    /// Inclusive upper timestamp bound.
    pub until_ms: Option<i64>,
    /// Continue after this match (the previous page's `nextCursor`).
    pub after: Option<NativeHistoryCursor>,
    pub limit: Option<i64>,
    pub raw_fts: Option<bool>,
    /// `all` (default), `user`, `assistant` or `prompt` — the CLI's `--role`.
    pub role: Option<String>,
}

struct SearchRequest {
    path: PathBuf,
    terms: Vec<String>,
    raw_fts: bool,
    filter: QueryFilter,
    role: SearchRole,
}

impl SearchRequest {
    fn new(query: String, options: Option<SearchOptions>) -> napi::Result<Self> {
        let options = options.unwrap_or_default();
        let limit = validate_limit(options.limit, 20, 1_000)?;
        let role = parse_search_role(options.role.as_deref())?;
        Ok(Self {
            path: db_path(options.db_path.clone()),
            terms: query.split_whitespace().map(str::to_string).collect(),
            raw_fts: options.raw_fts.unwrap_or(false),
            filter: HistoryQueryOptions {
                scope: options.scope,
                db_path: None,
                source: options.source,
                project: options.project,
                tag: options.tag,
                before_ms: options.before_ms,
                since_ms: options.since_ms,
                until_ms: options.until_ms,
                after: options.after,
                limit: None,
            }
            .filter(limit)?,
            role,
        })
    }
}

#[napi(object)]
pub struct NativeSearchPage {
    pub matches: Vec<NativeSearchMatch>,
    /// Present only when a further match exists.
    pub next_cursor: Option<NativeHistoryCursor>,
}

#[napi(object)]
pub struct NativeHistoryPage {
    pub entries: Vec<NativeHistoryEntry>,
    /// Present only when a further entry exists.
    pub next_cursor: Option<NativeHistoryCursor>,
}

#[napi(object)]
pub struct SessionOptions {
    pub db_path: Option<String>,
    pub source: Option<String>,
    pub tag: Option<String>,
}

#[napi(object)]
pub struct NativeHistoryEntry {
    pub id: i64,
    pub source: String,
    pub session_id: Option<String>,
    pub project: Option<String>,
    pub prompt: String,
    pub timestamp_ms: i64,
    pub locations: Vec<String>,
}

impl NativeHistoryEntry {
    fn from_entry(conn: &rusqlite::Connection, entry: HistoryEntry) -> anyhow::Result<Self> {
        let locations = match entry.session_id.as_deref() {
            Some(session_id) => session_locations(conn, &entry.source, session_id)?,
            None => Vec::new(),
        };
        Ok(Self {
            id: entry.id,
            source: entry.source,
            session_id: entry.session_id,
            project: entry.project,
            prompt: entry.prompt,
            timestamp_ms: entry.timestamp_ms,
            locations,
        })
    }
}

/// One `search` match. `id` is unique only within `match_source`: a prompt
/// is a `history` row, anything else a `session_event` row.
#[napi(object)]
pub struct NativeSearchMatch {
    pub id: i64,
    pub source: String,
    pub session_id: Option<String>,
    pub project: Option<String>,
    /// The matched text: the prompt for a `history` match, the event text
    /// otherwise. Named `prompt` so a match is still a history entry.
    pub prompt: String,
    pub timestamp_ms: i64,
    pub locations: Vec<String>,
    /// `history` or `session_event`.
    pub match_source: String,
    /// `user` for a `history` match; the event's role otherwise.
    pub role: String,
    /// `history` for a `history` match; the event's kind otherwise.
    pub kind: String,
}

impl NativeSearchMatch {
    fn from_row(conn: &rusqlite::Connection, row: SearchRow) -> anyhow::Result<Self> {
        let locations = match row.session_id.as_deref() {
            Some(session_id) => session_locations(conn, &row.source, session_id)?,
            None => Vec::new(),
        };
        Ok(Self {
            id: row.id,
            source: row.source,
            session_id: row.session_id,
            project: row.project,
            prompt: row.text,
            timestamp_ms: row.timestamp_ms,
            locations,
            match_source: row.match_source,
            role: row.role,
            kind: row.kind,
        })
    }
}

#[napi(object)]
pub struct NativeSessionEvent {
    pub id: i64,
    pub source: String,
    pub session_id: String,
    pub project: Option<String>,
    /// Canonical project identity, denormalized from the owning session.
    pub project_key: Option<String>,
    pub cwd: Option<String>,
    pub git_branch: Option<String>,
    pub message_id: Option<String>,
    pub parent_id: Option<String>,
    pub ts_ms: i64,
    pub role: String,
    pub kind: String,
    pub text: Option<String>,
    pub model: Option<String>,
    pub token_json: Option<String>,
    /// The upstream inference provider the harness named, when it names one
    /// (OpenCode's `providerID`). Null elsewhere rather than inferred.
    pub provider: Option<String>,
    pub event_uid: String,
    /// Per-tool-result fidelity. Null on every row that is not a tool result,
    /// and on a tool-result row whose provider does not record the fact.
    pub tool_use_id: Option<String>,
    /// Raw UTF-8 byte length of the provider's result payload.
    pub payload_bytes: Option<i64>,
    /// True when the harness had already truncated the payload.
    pub payload_truncated: Option<bool>,
    /// First 16 hex characters of the payload's sha256.
    pub payload_hash: Option<String>,
    /// n-th result recorded for this `toolUseId`, from zero.
    pub call_index: Option<i64>,
    /// Position of this result in the transcript's tool-result order.
    pub event_index: Option<i64>,
    /// `running` / `completed` / `errored` / `cancelled` / `unknown`.
    pub result_status: Option<String>,
    /// `tool_result` / `subagent_notification` / `function_call_output`.
    pub event_source: Option<String>,
    /// Which provider signal set the error.
    pub error_signal: Option<String>,
    pub subagent_session_id: Option<String>,
    pub agent_id: Option<String>,
    pub request_id: Option<String>,
    /// Why the turn ended, as the harness reported it.
    pub stop_reason: Option<String>,
    pub agent_version: Option<String>,
    pub is_sidechain: Option<bool>,
    pub is_meta: Option<bool>,
    pub turn_id: Option<String>,
    /// Why a user-role row is not a human prompt; null for a genuine prompt
    /// and for every model-output row.
    pub control_kind: Option<String>,
}

impl From<CoreSessionEvent> for NativeSessionEvent {
    fn from(event: CoreSessionEvent) -> Self {
        Self {
            id: event.id,
            source: event.source,
            session_id: event.session_id,
            project: event.project,
            project_key: event.project_key,
            cwd: event.cwd,
            git_branch: event.git_branch,
            message_id: event.message_id,
            parent_id: event.parent_id,
            ts_ms: event.ts_ms,
            role: event.role,
            kind: event.kind,
            text: event.text,
            model: event.model,
            token_json: event.token_json,
            provider: event.provider,
            event_uid: event.event_uid,
            tool_use_id: event.tool_use_id,
            payload_bytes: event.payload_bytes,
            payload_truncated: event.payload_truncated.map(|value| value != 0),
            payload_hash: event.payload_hash,
            call_index: event.call_index,
            event_index: event.event_index,
            result_status: event.result_status,
            event_source: event.event_source,
            error_signal: event.error_signal,
            subagent_session_id: event.subagent_session_id,
            agent_id: event.agent_id,
            request_id: event.request_id,
            stop_reason: event.stop_reason,
            agent_version: event.agent_version,
            is_sidechain: event.is_sidechain.map(|value| value != 0),
            is_meta: event.is_meta.map(|value| value != 0),
            turn_id: event.turn_id,
            control_kind: event.control_kind,
        }
    }
}

#[napi(object)]
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct EventCursor {
    pub ts_ms: i64,
    pub id: i64,
}

#[napi(object)]
pub struct EventsPageOptions {
    pub db_path: Option<String>,
    pub source: Option<String>,
    pub limit: Option<i64>,
    pub after: Option<EventCursor>,
}

#[napi(object)]
pub struct SessionEventsPage {
    pub events: Vec<NativeSessionEvent>,
    pub next_cursor: Option<EventCursor>,
}

#[napi(object)]
pub struct NativeSessionToolCall {
    pub id: i64,
    pub source: String,
    pub session_id: String,
    pub message_id: Option<String>,
    pub tool_use_id: String,
    pub name: String,
    pub target: Option<String>,
    /// Stored provider arguments, unparsed. The SDK owns JSON parsing so an
    /// unreadable value cannot fail a whole page at the boundary.
    pub args_json: Option<String>,
    pub is_error: Option<bool>,
    pub ts_ms: Option<i64>,
}

impl From<CoreSessionToolCall> for NativeSessionToolCall {
    fn from(call: CoreSessionToolCall) -> Self {
        Self {
            id: call.id,
            source: call.source,
            session_id: call.session_id,
            message_id: call.message_id,
            tool_use_id: call.tool_use_id,
            name: call.name,
            target: call.target,
            args_json: call.args_json,
            is_error: call.is_error.map(|value| value != 0),
            ts_ms: call.ts_ms,
        }
    }
}

#[napi(object)]
pub struct NativeSessionFileEdit {
    pub id: i64,
    pub source: String,
    pub session_id: String,
    pub message_id: Option<String>,
    pub tool_use_id: String,
    pub file_path: String,
    pub tool_name: Option<String>,
    pub lines_added: Option<i64>,
    pub lines_removed: Option<i64>,
    /// Stored provider patch, unparsed, for the same reason as `args_json`.
    pub structured_patch_json: Option<String>,
    pub user_modified: Option<bool>,
    pub ts_ms: Option<i64>,
    pub git_branch: Option<String>,
    pub cwd: Option<String>,
}

impl From<CoreSessionFileEdit> for NativeSessionFileEdit {
    fn from(edit: CoreSessionFileEdit) -> Self {
        Self {
            id: edit.id,
            source: edit.source,
            session_id: edit.session_id,
            message_id: edit.message_id,
            tool_use_id: edit.tool_use_id,
            file_path: edit.file_path,
            tool_name: edit.tool_name,
            lines_added: edit.lines_added,
            lines_removed: edit.lines_removed,
            structured_patch_json: edit.structured_patch_json,
            user_modified: edit.user_modified.map(|value| value != 0),
            ts_ms: edit.ts_ms,
            git_branch: edit.git_branch,
            cwd: edit.cwd,
        }
    }
}

/// Continuation for tool call and file edit pages. `tsMs` is optional because
/// both tables order their undated rows last.
///
/// Absent-or-`undefined` is how a caller says "inside the undated tail": an
/// explicit JavaScript `null` cannot be converted to `i64` and fails at the
/// boundary, so the SDK normalizes `null` to `undefined` before calling in.
#[napi(object)]
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct EvidenceCursor {
    pub ts_ms: Option<i64>,
    pub id: i64,
}

#[napi(object)]
pub struct EvidencePageOptions {
    pub db_path: Option<String>,
    pub limit: Option<i64>,
    pub after: Option<EvidenceCursor>,
}

#[napi(object)]
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct NativeSessionUserTurnBlock {
    /// `text` or `tool_result`.
    pub kind: String,
    pub tool_use_id: Option<String>,
    /// Measured payload bytes when the parser recorded them, otherwise the
    /// UTF-8 length of the stored text.
    pub byte_len: i64,
    /// True when the result is known to have failed, false when it is known
    /// to have succeeded, null when the provider has not said.
    pub is_error: Option<bool>,
}

impl From<CoreSessionUserTurnBlock> for NativeSessionUserTurnBlock {
    fn from(block: CoreSessionUserTurnBlock) -> Self {
        Self {
            kind: block.kind,
            tool_use_id: block.tool_use_id,
            byte_len: block.byte_len,
            is_error: block.is_error.map(|value| value != 0),
        }
    }
}

#[napi(object)]
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct NativeSessionUserTurn {
    pub id: i64,
    pub source: String,
    pub session_id: String,
    pub message_id: Option<String>,
    /// The nearest messages recorded either side of this turn, from either
    /// side of the conversation. Null only when the session recorded no named
    /// message on that side; an event the provider left unnamed is passed
    /// over rather than nulling the field.
    pub preceding_message_id: Option<String>,
    pub following_message_id: Option<String>,
    pub ts_ms: i64,
    pub blocks: Vec<NativeSessionUserTurnBlock>,
}

impl From<CoreSessionUserTurn> for NativeSessionUserTurn {
    fn from(turn: CoreSessionUserTurn) -> Self {
        Self {
            id: turn.id,
            source: turn.source,
            session_id: turn.session_id,
            message_id: turn.message_id,
            preceding_message_id: turn.preceding_message_id,
            following_message_id: turn.following_message_id,
            ts_ms: turn.ts_ms,
            blocks: turn
                .blocks
                .into_iter()
                .map(NativeSessionUserTurnBlock::from)
                .collect(),
        }
    }
}

#[napi(object)]
pub struct UserTurnsPageOptions {
    pub db_path: Option<String>,
    pub limit: Option<i64>,
    pub after: Option<EventCursor>,
}

#[napi(object)]
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SessionUserTurnsPage {
    pub contract_version: u32,
    pub source: String,
    pub session_id: String,
    pub user_turns: Vec<NativeSessionUserTurn>,
    pub next_cursor: Option<EventCursor>,
}

#[napi(object)]
pub struct SessionToolCallsPage {
    pub contract_version: u32,
    pub source: String,
    pub session_id: String,
    pub tool_calls: Vec<NativeSessionToolCall>,
    pub next_cursor: Option<EvidenceCursor>,
}

#[napi(object)]
pub struct SessionFileEditsPage {
    pub contract_version: u32,
    pub source: String,
    pub session_id: String,
    pub file_edits: Vec<NativeSessionFileEdit>,
    pub next_cursor: Option<EvidenceCursor>,
}

/// Normalized usage for one request or one session.
///
/// The optional fields stay optional across the boundary: `null` means the
/// provider did not report that counter, which is a different fact from a
/// reported zero and the only thing that makes `coverage` interpretable.
#[napi(object)]
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct NativeNormalizedUsage {
    pub input_tokens: i64,
    pub output_tokens: i64,
    pub reasoning_tokens: Option<i64>,
    pub cache_read_tokens: i64,
    pub cache_write_tokens: i64,
    #[napi(js_name = "cacheWrite5mTokens")]
    #[serde(rename = "cacheWrite5mTokens")]
    pub cache_write5m_tokens: Option<i64>,
    #[napi(js_name = "cacheWrite1hTokens")]
    #[serde(rename = "cacheWrite1hTokens")]
    pub cache_write1h_tokens: Option<i64>,
    pub provider_total_tokens: Option<i64>,
    pub reported_cost_usd: Option<f64>,
    /// `per-request`, `per-message`, `cumulative-delta`, `context-proxy`, or
    /// `mixed` on a summary spanning more than one.
    pub accounting: String,
    pub has_input_tokens: bool,
    pub has_output_tokens: bool,
    pub has_reasoning_tokens: bool,
    pub has_cache_read_tokens: bool,
    pub has_cache_write_tokens: bool,
}

/// The largest integer a JavaScript number represents exactly
/// (`Number.MAX_SAFE_INTEGER`).
///
/// This, not `i64::MAX`, is the real ceiling of the boundary: above it a
/// `number` silently stops being the value it was given, so a count that does
/// not fit cannot be handed over at all.
pub(crate) const MAX_JS_SAFE_COUNT: u64 = 9_007_199_254_740_991;

/// Stable code for a count that JavaScript cannot represent exactly.
const COUNT_NOT_REPRESENTABLE: &str = "USAGE_COUNT_NOT_REPRESENTABLE";
const COUNT_NOT_REPRESENTABLE_DIAGNOSTIC: &str = "count-not-representable";

/// A token count as a JavaScript-safe integer, or `None` when it is not one.
///
/// Core accepts every counter up to `u64::MAX`; this boundary accepts only
/// what survives the crossing. Saturating to `i64::MAX` would hand JavaScript
/// a plausible number that is neither the stored value nor representable —
/// the exact shape of failure this crate refuses everywhere else.
pub(crate) fn js_count(value: u64) -> Option<i64> {
    (value <= MAX_JS_SAFE_COUNT).then_some(value as i64)
}

/// `None` stays `None`; a reported count that is not representable makes the
/// whole record unrepresentable rather than quietly dropping one field.
fn js_count_optional(value: Option<u64>) -> Option<Option<i64>> {
    match value {
        None => Some(None),
        Some(value) => js_count(value).map(Some),
    }
}

impl NativeNormalizedUsage {
    /// Convert a normalized record, or `None` when any count it carries
    /// cannot cross the boundary intact.
    pub(crate) fn from_core(usage: &CoreNormalizedUsage, accounting: String) -> Option<Self> {
        Some(Self {
            input_tokens: js_count(usage.input_tokens)?,
            output_tokens: js_count(usage.output_tokens)?,
            reasoning_tokens: js_count_optional(usage.reasoning_tokens)?,
            cache_read_tokens: js_count(usage.cache_read_tokens)?,
            cache_write_tokens: js_count(usage.cache_write_tokens)?,
            cache_write5m_tokens: js_count_optional(usage.cache_write_5m_tokens)?,
            cache_write1h_tokens: js_count_optional(usage.cache_write_1h_tokens)?,
            provider_total_tokens: js_count_optional(usage.provider_total_tokens)?,
            reported_cost_usd: usage.reported_cost_usd,
            accounting,
            has_input_tokens: usage.coverage.has_input_tokens,
            has_output_tokens: usage.coverage.has_output_tokens,
            has_reasoning_tokens: usage.coverage.has_reasoning_tokens,
            has_cache_read_tokens: usage.coverage.has_cache_read_tokens,
            has_cache_write_tokens: usage.coverage.has_cache_write_tokens,
        })
    }
}

#[napi(object)]
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct NativeSessionRequest {
    pub id: i64,
    pub source: String,
    pub session_id: String,
    pub request_key: String,
    /// `request-id`, `provider-message-id`, `request-span` or `record-id`.
    pub request_key_source: String,
    pub message_ids: Vec<String>,
    pub model: Option<String>,
    pub provider: Option<String>,
    pub first_ts_ms: i64,
    pub last_ts_ms: i64,
    /// Absent when the request carried no usage evidence, or when the
    /// evidence could not be trusted — `diagnostics` says which.
    pub usage: Option<NativeNormalizedUsage>,
    pub usage_error: Option<String>,
    pub tool_use_ids: Vec<String>,
    pub has_thinking: bool,
    pub event_count: i64,
    pub diagnostics: Vec<String>,
}

impl From<CoreSessionRequest> for NativeSessionRequest {
    fn from(request: CoreSessionRequest) -> Self {
        let mut diagnostics: Vec<String> = request
            .diagnostics
            .iter()
            .map(|diagnostic| diagnostic.as_str().to_string())
            .collect();
        let mut usage_error = request.usage_error;
        let usage = request.usage.as_ref().and_then(|usage| {
            let accounting = usage.accounting.as_str().to_string();
            let converted = NativeNormalizedUsage::from_core(usage, accounting);
            if converted.is_none() {
                // The row normalized; it just cannot be expressed here. Say
                // so rather than serve a rounded number.
                usage_error = Some(COUNT_NOT_REPRESENTABLE.to_string());
                diagnostics.push(COUNT_NOT_REPRESENTABLE_DIAGNOSTIC.to_string());
            }
            converted
        });
        Self {
            id: request.id,
            source: request.source,
            session_id: request.session_id,
            request_key: request.request_key,
            request_key_source: request.request_key_source.as_str().to_string(),
            message_ids: request.message_ids,
            model: request.model,
            provider: request.provider,
            first_ts_ms: request.first_ts_ms,
            last_ts_ms: request.last_ts_ms,
            usage,
            usage_error,
            tool_use_ids: request.tool_use_ids,
            has_thinking: request.has_thinking,
            event_count: request.event_count,
            diagnostics,
        }
    }
}

#[napi(object)]
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RequestCursor {
    pub ts_ms: i64,
    pub id: i64,
}

#[napi(object)]
pub struct RequestPageOptions {
    pub db_path: Option<String>,
    pub limit: Option<i64>,
    pub after: Option<RequestCursor>,
}

#[napi(object)]
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SessionRequestsPage {
    pub contract_version: u32,
    pub source: String,
    pub session_id: String,
    pub requests: Vec<NativeSessionRequest>,
    pub next_cursor: Option<RequestCursor>,
}

#[napi(object)]
pub struct SessionUsageOptions {
    pub db_path: Option<String>,
}

/// One session's usage rollup. `usage` is absent when the session has no
/// usage evidence at all — not zeroed, because zero is a claim.
#[napi(object)]
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SessionUsage {
    pub contract_version: u32,
    pub source: String,
    pub session_id: String,
    pub usage: Option<NativeNormalizedUsage>,
    /// Requests that contributed to `usage`.
    pub request_count: i64,
    /// Requests seen, including ones with no usage.
    pub total_request_count: i64,
    /// Every accounting mode present. More than one means the totals mix
    /// units and should be read per mode.
    pub accounting: Vec<String>,
    pub models: Vec<String>,
    pub first_ts_ms: Option<i64>,
    pub last_ts_ms: Option<i64>,
    pub diagnostics: Vec<String>,
    /// The totals exceeded what can be represented and must not be used.
    pub overflowed: bool,
}

fn session_usage(
    source: String,
    session_id: String,
    summary: Option<CoreSessionUsageSummary>,
) -> SessionUsage {
    let Some(summary) = summary else {
        return SessionUsage {
            contract_version: SESSION_USAGE_CONTRACT_VERSION,
            source,
            session_id,
            usage: None,
            request_count: 0,
            total_request_count: 0,
            accounting: Vec::new(),
            models: Vec::new(),
            first_ts_ms: None,
            last_ts_ms: None,
            diagnostics: Vec::new(),
            overflowed: false,
        };
    };
    let mut diagnostics: Vec<String> = summary
        .diagnostics
        .iter()
        .map(|diagnostic| diagnostic.as_str().to_string())
        .collect();
    // A summary's mode list can be plural; the single-mode field carries a
    // real mode only when there is exactly one, so a session that mixes units
    // cannot be read as if it had one.
    let accounting = match summary.accounting.as_slice() {
        [mode] => mode.as_str().to_string(),
        _ => "mixed".to_string(),
    };
    let usage = summary.usage.as_ref().and_then(|usage| {
        let converted = NativeNormalizedUsage::from_core(usage, accounting);
        if converted.is_none() {
            diagnostics.push(COUNT_NOT_REPRESENTABLE_DIAGNOSTIC.to_string());
        }
        converted
    });
    SessionUsage {
        contract_version: SESSION_USAGE_CONTRACT_VERSION,
        source,
        session_id,
        usage,
        request_count: js_count(summary.request_count).unwrap_or(i64::MAX),
        total_request_count: js_count(summary.total_request_count).unwrap_or(i64::MAX),
        accounting: summary
            .accounting
            .iter()
            .map(|mode| mode.as_str().to_string())
            .collect(),
        models: summary.models,
        first_ts_ms: Some(summary.first_ts_ms),
        last_ts_ms: Some(summary.last_ts_ms),
        diagnostics,
        overflowed: summary.overflowed,
    }
}

#[napi(object)]
pub struct SourceCount {
    pub source: String,
    pub count: i64,
}

#[napi(object)]
pub struct ProjectCount {
    pub project: String,
    pub count: i64,
}

#[napi(object)]
pub struct NativeStats {
    pub scope: String,
    pub total: i64,
    pub by_source: Vec<SourceCount>,
    pub by_project: Vec<ProjectCount>,
    /// Which key `by_project` is bucketed by: `project_key` or `cwd`. Read it
    /// rather than assuming -- the two produce different counts for the same
    /// database.
    pub grouped_by: String,
    pub first_timestamp_ms: Option<i64>,
    pub last_timestamp_ms: Option<i64>,
}

#[napi(object)]
pub struct StatsOptions {
    pub scope: Option<String>,
    pub db_path: Option<String>,
    pub tag: Option<String>,
    /// Bucket `by_project` by the raw working directory instead of the
    /// canonical project key. Defaults to false.
    pub by_cwd: Option<bool>,
}

async fn read_database<T, F>(path: PathBuf, empty: T, operation: F) -> napi::Result<T>
where
    T: Send + 'static,
    F: FnOnce(&rusqlite::Connection) -> anyhow::Result<T> + Send + 'static,
{
    read_database_with_schema(path, empty, schema_is_read_current, operation).await
}

async fn read_database_with_schema<T, F>(
    path: PathBuf,
    empty: T,
    schema_current: fn(&rusqlite::Connection) -> anyhow::Result<bool>,
    operation: F,
) -> napi::Result<T>
where
    T: Send + 'static,
    F: FnOnce(&rusqlite::Connection) -> anyhow::Result<T> + Send + 'static,
{
    napi::tokio::task::spawn_blocking(move || {
        if !path.exists() {
            return Ok(empty);
        }
        let conn = match open_db_readonly(&path) {
            Ok(conn) if schema_current(&conn).unwrap_or(false) => conn,
            _ => open_db(&path).map_err(|error| database_error(&path, format!("{error:#}")))?,
        };
        operation(&conn)
            .map_err(|error| native_error("DATABASE_QUERY_FAILED", format!("{error:#}")))
    })
    .await
    .map_err(worker_error)?
}

/// Full-text search of indexed prompts and session events. Never discovers or
/// syncs implicitly. Same contract as `ai-hist search`.
#[napi]
pub async fn search(
    query: String,
    options: Option<SearchOptions>,
) -> napi::Result<Vec<NativeSearchMatch>> {
    let request = SearchRequest::new(query, options)?;
    read_database(request.path, Vec::new(), move |conn| {
        search_all(
            conn,
            &request.terms,
            request.raw_fts,
            &request.filter,
            request.role,
        )?
        .into_iter()
        .map(|row| NativeSearchMatch::from_row(conn, row))
        .collect()
    })
    .await
}

/// One page of `search`, newest first, with the cursor to the next page.
#[napi]
pub async fn search_page(
    query: String,
    options: Option<SearchOptions>,
) -> napi::Result<NativeSearchPage> {
    let request = SearchRequest::new(query, options)?;
    let empty = NativeSearchPage {
        matches: Vec::new(),
        next_cursor: None,
    };
    read_database(request.path, empty, move |conn| {
        let page = core_search_page(
            conn,
            &request.terms,
            request.raw_fts,
            &request.filter,
            request.role,
        )?;
        Ok(NativeSearchPage {
            matches: page
                .rows
                .into_iter()
                .map(|row| NativeSearchMatch::from_row(conn, row))
                .collect::<anyhow::Result<_>>()?,
            next_cursor: page.next_cursor.map(NativeHistoryCursor::from_core),
        })
    })
    .await
}

/// Recent indexed history. Never discovers or syncs implicitly.
#[napi]
pub async fn recent(options: Option<HistoryQueryOptions>) -> napi::Result<Vec<NativeHistoryEntry>> {
    let options = options.unwrap_or_default();
    let limit = validate_limit(options.limit, 20, 1_000)?;
    let path = db_path(options.db_path.clone());
    let filter = options.filter(limit)?;
    read_database(path, Vec::new(), move |conn| {
        core_recent(conn, &filter)?
            .into_iter()
            .map(|entry| NativeHistoryEntry::from_entry(conn, entry))
            .collect()
    })
    .await
}

/// One page of `recent`, newest first, with the cursor to the next page.
#[napi]
pub async fn recent_page(options: Option<HistoryQueryOptions>) -> napi::Result<NativeHistoryPage> {
    let options = options.unwrap_or_default();
    let limit = validate_limit(options.limit, 20, 1_000)?;
    let path = db_path(options.db_path.clone());
    let filter = options.filter(limit)?;
    let empty = NativeHistoryPage {
        entries: Vec::new(),
        next_cursor: None,
    };
    read_database(path, empty, move |conn| {
        let page = core_recent_page(conn, &filter)?;
        Ok(NativeHistoryPage {
            entries: page
                .rows
                .into_iter()
                .map(|entry| NativeHistoryEntry::from_entry(conn, entry))
                .collect::<anyhow::Result<_>>()?,
            next_cursor: page.next_cursor.map(NativeHistoryCursor::from_core),
        })
    })
    .await
}

/// Indexed prompts for one session. Event payloads are separately paginated.
#[napi]
pub async fn get_session(
    session_id: String,
    options: Option<SessionOptions>,
) -> napi::Result<Vec<NativeHistoryEntry>> {
    let options = options.unwrap_or(SessionOptions {
        db_path: None,
        source: None,
        tag: None,
    });
    let path = db_path(options.db_path);
    read_database(path, Vec::new(), move |conn| {
        core_session(
            conn,
            &session_id,
            options.source.as_deref(),
            options.tag.as_deref(),
        )?
        .into_iter()
        .map(|entry| NativeHistoryEntry::from_entry(conn, entry))
        .collect()
    })
    .await
}

/// One bounded page of normalized events for a session.
#[napi]
pub async fn get_session_events_page(
    session_id: String,
    options: Option<EventsPageOptions>,
) -> napi::Result<SessionEventsPage> {
    let options = options.unwrap_or(EventsPageOptions {
        db_path: None,
        source: None,
        limit: None,
        after: None,
    });
    let limit = validate_limit(options.limit, DEFAULT_EVENT_LIMIT, 1_000)?;
    let path = db_path(options.db_path);
    let after = options.after.map(|cursor| CoreEventCursor {
        ts_ms: cursor.ts_ms,
        id: cursor.id,
    });
    read_database_with_schema(
        path,
        SessionEventsPage {
            events: Vec::new(),
            next_cursor: None,
        },
        schema_is_event_read_current,
        move |conn| {
            let page = core_session_events_page(
                conn,
                &session_id,
                options.source.as_deref(),
                limit,
                after.as_ref(),
            )?;
            Ok(SessionEventsPage {
                events: page
                    .events
                    .into_iter()
                    .map(NativeSessionEvent::from)
                    .collect(),
                next_cursor: page.next_cursor.map(|cursor| EventCursor {
                    ts_ms: cursor.ts_ms,
                    id: cursor.id,
                }),
            })
        },
    )
    .await
}

/// One bounded page of recorded tool calls for one session.
///
/// Both `source` and `sessionId` are required: provider session ids are not
/// globally unique, so an id-only lookup could interleave two sessions.
#[napi]
pub async fn get_session_tool_calls_page(
    source: String,
    session_id: String,
    options: Option<EvidencePageOptions>,
) -> napi::Result<SessionToolCallsPage> {
    let options = options.unwrap_or(EvidencePageOptions {
        db_path: None,
        limit: None,
        after: None,
    });
    let source = validate_identity(source, "source")?;
    let session_id = validate_identity(session_id, "sessionId")?;
    let limit = validate_limit(options.limit, DEFAULT_EVENT_LIMIT, 1_000)?;
    let path = db_path(options.db_path);
    let after = options.after.map(core_evidence_cursor);
    let (page_source, page_session_id) = (source.clone(), session_id.clone());
    read_database_with_schema(
        path,
        ai_hist::SessionToolCallPage {
            tool_calls: Vec::new(),
            next_cursor: None,
        },
        schema_is_evidence_read_current,
        move |conn| core_session_tool_calls_page(conn, &source, &session_id, limit, after.as_ref()),
    )
    .await
    .map(|page| SessionToolCallsPage {
        contract_version: SESSION_EVIDENCE_CONTRACT_VERSION,
        source: page_source,
        session_id: page_session_id,
        tool_calls: page
            .tool_calls
            .into_iter()
            .map(NativeSessionToolCall::from)
            .collect(),
        next_cursor: page.next_cursor.map(evidence_cursor),
    })
}

/// One bounded page of user turns for one session, oldest first.
///
/// Each turn carries the ordered blocks the provider attached to one user
/// message: the human's own text and the tool results that came back with it,
/// with the measured payload size of each. Computed from `session_events`
/// rather than a table of its own, so it cannot disagree with the transcript.
#[napi]
pub async fn get_session_user_turns_page(
    source: String,
    session_id: String,
    options: Option<UserTurnsPageOptions>,
) -> napi::Result<SessionUserTurnsPage> {
    let options = options.unwrap_or(UserTurnsPageOptions {
        db_path: None,
        limit: None,
        after: None,
    });
    let source = validate_identity(source, "source")?;
    let session_id = validate_identity(session_id, "sessionId")?;
    let limit = validate_limit(options.limit, DEFAULT_EVENT_LIMIT, 1_000)?;
    let path = db_path(options.db_path);
    let after = options.after.map(|cursor| CoreEventCursor {
        ts_ms: cursor.ts_ms,
        id: cursor.id,
    });
    let (page_source, page_session_id) = (source.clone(), session_id.clone());
    read_database_with_schema(
        path,
        ai_hist::SessionUserTurnPage {
            user_turns: Vec::new(),
            next_cursor: None,
        },
        schema_is_event_read_current,
        move |conn| core_session_user_turns_page(conn, &source, &session_id, limit, after.as_ref()),
    )
    .await
    .map(|page| SessionUserTurnsPage {
        contract_version: SESSION_EVIDENCE_CONTRACT_VERSION,
        source: page_source,
        session_id: page_session_id,
        user_turns: page
            .user_turns
            .into_iter()
            .map(NativeSessionUserTurn::from)
            .collect(),
        next_cursor: page.next_cursor.map(|cursor| EventCursor {
            ts_ms: cursor.ts_ms,
            id: cursor.id,
        }),
    })
}

/// One bounded page of recorded file edits for one session.
#[napi]
pub async fn get_session_file_edits_page(
    source: String,
    session_id: String,
    options: Option<EvidencePageOptions>,
) -> napi::Result<SessionFileEditsPage> {
    let options = options.unwrap_or(EvidencePageOptions {
        db_path: None,
        limit: None,
        after: None,
    });
    let source = validate_identity(source, "source")?;
    let session_id = validate_identity(session_id, "sessionId")?;
    let limit = validate_limit(options.limit, DEFAULT_EVENT_LIMIT, 1_000)?;
    let path = db_path(options.db_path);
    let after = options.after.map(core_evidence_cursor);
    let (page_source, page_session_id) = (source.clone(), session_id.clone());
    read_database_with_schema(
        path,
        ai_hist::SessionFileEditPage {
            file_edits: Vec::new(),
            next_cursor: None,
        },
        schema_is_evidence_read_current,
        move |conn| core_session_file_edits_page(conn, &source, &session_id, limit, after.as_ref()),
    )
    .await
    .map(|page| SessionFileEditsPage {
        contract_version: SESSION_EVIDENCE_CONTRACT_VERSION,
        source: page_source,
        session_id: page_session_id,
        file_edits: page
            .file_edits
            .into_iter()
            .map(NativeSessionFileEdit::from)
            .collect(),
        next_cursor: page.next_cursor.map(evidence_cursor),
    })
}

/// One bounded page of a session's model requests, oldest first.
///
/// Both halves of the identity are required for the same reason the evidence
/// pages require them: provider session ids collide across providers.
#[napi]
pub async fn get_session_requests_page(
    source: String,
    session_id: String,
    options: Option<RequestPageOptions>,
) -> napi::Result<SessionRequestsPage> {
    let options = options.unwrap_or(RequestPageOptions {
        db_path: None,
        limit: None,
        after: None,
    });
    let source = validate_identity(source, "source")?;
    let session_id = validate_identity(session_id, "sessionId")?;
    let limit = validate_limit(options.limit, DEFAULT_EVENT_LIMIT, 1_000)?;
    let path = db_path(options.db_path);
    let after = options.after.map(|cursor| CoreRequestCursor {
        ts_ms: cursor.ts_ms,
        id: cursor.id,
    });
    let (page_source, page_session_id) = (source.clone(), session_id.clone());
    read_database_with_schema(
        path,
        ai_hist::SessionRequestPage {
            requests: Vec::new(),
            next_cursor: None,
        },
        schema_is_usage_read_current,
        move |conn| core_session_requests_page(conn, &source, &session_id, limit, after.as_ref()),
    )
    .await
    .map(|page| SessionRequestsPage {
        contract_version: SESSION_USAGE_CONTRACT_VERSION,
        source: page_source,
        session_id: page_session_id,
        requests: page
            .requests
            .into_iter()
            .map(NativeSessionRequest::from)
            .collect(),
        next_cursor: page.next_cursor.map(|cursor| RequestCursor {
            ts_ms: cursor.ts_ms,
            id: cursor.id,
        }),
    })
}

/// Provider-neutral usage rollup for one session.
#[napi]
pub async fn get_session_usage(
    source: String,
    session_id: String,
    options: Option<SessionUsageOptions>,
) -> napi::Result<SessionUsage> {
    let options = options.unwrap_or(SessionUsageOptions { db_path: None });
    let source = validate_identity(source, "source")?;
    let session_id = validate_identity(session_id, "sessionId")?;
    let path = db_path(options.db_path);
    let (summary_source, summary_session_id) = (source.clone(), session_id.clone());
    read_database_with_schema(path, None, schema_is_usage_read_current, move |conn| {
        core_session_usage_summary(conn, &source, &session_id)
    })
    .await
    .map(|summary| session_usage(summary_source, summary_session_id, summary))
}

/// Database statistics over already-indexed data.
#[napi]
pub async fn stats(options: Option<StatsOptions>) -> napi::Result<NativeStats> {
    let options = options.unwrap_or(StatsOptions {
        scope: None,
        db_path: None,
        tag: None,
        by_cwd: None,
    });
    let grouping = if options.by_cwd.unwrap_or(false) {
        ai_hist::ProjectGrouping::Cwd
    } else {
        ai_hist::ProjectGrouping::ProjectKey
    };
    let scope = parse_scope(options.scope)?;
    let path = db_path(options.db_path);
    read_database(
        path,
        NativeStats {
            scope: scope_name(scope),
            total: 0,
            by_source: Vec::new(),
            by_project: Vec::new(),
            grouped_by: grouping.as_str().to_string(),
            first_timestamp_ms: None,
            last_timestamp_ms: None,
        },
        move |conn| {
            let result = core_stats_scoped_by(conn, options.tag.as_deref(), scope, grouping)?;
            Ok(NativeStats {
                scope: scope_name(scope),
                total: result.total,
                by_source: result
                    .by_source
                    .into_iter()
                    .map(|(source, count)| SourceCount { source, count })
                    .collect(),
                by_project: result
                    .by_project
                    .into_iter()
                    .map(|(project, count)| ProjectCount { project, count })
                    .collect(),
                grouped_by: result.grouping.as_str().to_string(),
                first_timestamp_ms: result.first_timestamp_ms,
                last_timestamp_ms: result.last_timestamp_ms,
            })
        },
    )
    .await
}

#[napi(object)]
pub struct CatalogSession {
    pub source: String,
    pub session_id: String,
    pub cwd: Option<String>,
    pub git_branch: Option<String>,
    pub first_activity_ms: Option<i64>,
    pub last_activity_ms: Option<i64>,
    pub first_prompt: Option<String>,
    pub last_assistant_text: Option<String>,
    pub models: Vec<String>,
    pub originator: Option<String>,
    pub agent_version: Option<String>,
    pub repo_url: Option<String>,
    pub initial_commit: Option<String>,
    pub workspace_roots: Vec<String>,
    pub raw_path: Option<String>,
    pub source_stamp: Option<String>,
    pub discovery_state: String,
    /// Canonical project identity: `host/owner/repo`, or the working
    /// directory when no git remote resolves.
    pub project_key: Option<String>,
    /// `remote`, `path`, or `inherited`.
    pub project_key_method: Option<String>,
    pub locations: Vec<String>,
    pub from_cache: bool,
}

impl From<ai_hist::ShallowSession> for CatalogSession {
    fn from(session: ai_hist::ShallowSession) -> Self {
        Self {
            source: session.source,
            session_id: session.session_id,
            cwd: session.cwd,
            git_branch: session.git_branch,
            first_activity_ms: session.first_activity_ms,
            last_activity_ms: session.last_activity_ms,
            first_prompt: session.first_prompt,
            last_assistant_text: session.last_assistant_text,
            models: session.models,
            originator: session.originator,
            agent_version: session.agent_version,
            repo_url: session.repo_url,
            initial_commit: session.initial_commit,
            workspace_roots: session.workspace_roots,
            raw_path: session.raw_path,
            source_stamp: session.source_stamp,
            discovery_state: session.discovery_state,
            project_key: session.project_key,
            project_key_method: session.project_key_method,
            locations: session.locations,
            from_cache: session.from_cache,
        }
    }
}

#[napi(object)]
pub struct CatalogCursor {
    pub last_activity_ms: Option<i64>,
    pub source: String,
    pub session_id: String,
}

#[napi(object)]
pub struct ListCatalogOptions {
    pub scope: Option<String>,
    pub db_path: Option<String>,
    pub sources: Option<Vec<String>>,
    pub limit: Option<i64>,
    pub before_ms: Option<i64>,
    pub after: Option<CatalogCursor>,
    /// Exact canonical project key (`host/owner/repo`, or the working
    /// directory when the checkout has no remote).
    pub project_key: Option<String>,
}

#[napi(object)]
pub struct SessionCatalogPage {
    pub contract_version: u32,
    pub scope: String,
    pub sessions: Vec<CatalogSession>,
    pub next_cursor: Option<CatalogCursor>,
}

/// Cache-only indexed catalog query. Missing databases return an empty page.
#[napi]
pub async fn list_session_catalog_page(
    options: Option<ListCatalogOptions>,
) -> napi::Result<SessionCatalogPage> {
    let options = options.unwrap_or(ListCatalogOptions {
        scope: None,
        db_path: None,
        sources: None,
        limit: None,
        before_ms: None,
        after: None,
        project_key: None,
    });
    validate_limit(options.limit, DEFAULT_LIMIT, 1_000)?;
    let scope = parse_scope(options.scope)?;
    let path = db_path(options.db_path);
    let request = ai_hist::CatalogListOptions {
        scope,
        sources: options.sources.unwrap_or_default(),
        limit: options.limit,
        before_ms: options.before_ms,
        after: options.after.map(|cursor| ai_hist::CatalogCursor {
            last_activity_ms: cursor.last_activity_ms,
            source: cursor.source,
            session_id: cursor.session_id,
        }),
        project_key: options.project_key,
    };
    read_database_with_schema(
        path,
        ai_hist::SessionCatalogPage {
            scope,
            ..Default::default()
        },
        schema_is_catalog_read_current,
        move |conn| ai_hist::list_session_catalog_page(conn, &request),
    )
    .await
    .map(|page| SessionCatalogPage {
        contract_version: ai_hist::SESSION_CATALOG_CONTRACT_VERSION,
        scope: scope_name(page.scope),
        sessions: page
            .sessions
            .into_iter()
            .map(CatalogSession::from)
            .collect(),
        next_cursor: page.next_cursor.map(|cursor| CatalogCursor {
            last_activity_ms: cursor.last_activity_ms,
            source: cursor.source,
            session_id: cursor.session_id,
        }),
    })
}

/// Convenience first-page catalog listing with identical cache-only semantics.
#[napi]
pub async fn list_session_catalog(
    options: Option<ListCatalogOptions>,
) -> napi::Result<Vec<CatalogSession>> {
    Ok(list_session_catalog_page(options).await?.sessions)
}

#[napi(object)]
pub struct DiscoverOptions {
    pub source_connectors: Option<Vec<String>>,
    pub scope: Option<String>,
    pub db_path: Option<String>,
    pub sources: Option<Vec<String>>,
    pub limit: Option<u32>,
}

#[napi(object)]
pub struct DiscoveryDiagnostic {
    pub source: String,
    pub locator: Option<String>,
    pub error: String,
}

#[napi(object)]
pub struct ProviderSummary {
    pub source: String,
    pub candidates: u32,
    pub discovered: u32,
    pub skipped_unchanged: u32,
    pub failed: bool,
}

#[napi(object)]
pub struct DiscoveryCounters {
    pub candidates_enumerated: i64,
    pub shallow_reads: i64,
    pub skipped_unchanged: i64,
    pub files_opened: i64,
    pub bytes_read: i64,
    pub provider_queries: i64,
    pub records_inspected: i64,
}

#[napi(object)]
pub struct SourceExemption {
    pub source: String,
    pub reason: String,
}

#[napi(object)]
pub struct DiscoverResult {
    pub contract_version: u32,
    pub scope: String,
    pub locations_run: Vec<String>,
    pub sessions: Vec<CatalogSession>,
    pub discovered: u32,
    pub skipped_unchanged: u32,
    pub providers: Vec<ProviderSummary>,
    pub exempt_sources: Vec<SourceExemption>,
    pub diagnostics: Vec<DiscoveryDiagnostic>,
    pub counters: DiscoveryCounters,
}

/// Explicit bounded provider discovery. It updates only the session catalog.
#[napi]
pub async fn discover_sessions(options: Option<DiscoverOptions>) -> napi::Result<DiscoverResult> {
    let options = options.unwrap_or(DiscoverOptions {
        source_connectors: None,
        scope: None,
        db_path: None,
        sources: None,
        limit: None,
    });
    let scope = parse_scope(options.scope)?;
    let sources = options.sources.unwrap_or_default();
    let connectors = source_connector_selection(options.source_connectors)?;
    ensure_acquisition_scope_supported(scope, "discovery", &sources, &connectors)?;
    let path = db_path(options.db_path);
    let request = ai_hist::DiscoverOptions {
        scope,
        sources,
        limit: options.limit.map(|limit| limit as usize),
    };
    let (sessions, summary) = napi::tokio::task::spawn_blocking(move || {
        ai_hist::discover_sessions_scoped_at_with_connectors(&path, &request, &connectors)
    })
    .await
    .map_err(worker_error)?
    .map_err(|error| native_error("DISCOVERY_FAILED", format!("{error:#}")))?;
    Ok(DiscoverResult {
        contract_version: summary.contract_version,
        scope: scope_name(scope),
        locations_run: summary.locations_run,
        sessions: sessions.into_iter().map(CatalogSession::from).collect(),
        discovered: summary.discovered as u32,
        skipped_unchanged: summary.skipped_unchanged as u32,
        providers: summary
            .providers
            .into_iter()
            .map(|(source, provider)| ProviderSummary {
                source,
                candidates: provider.candidates as u32,
                discovered: provider.discovered as u32,
                skipped_unchanged: provider.skipped_unchanged as u32,
                failed: provider.failed,
            })
            .collect(),
        exempt_sources: summary
            .exempt_sources
            .into_iter()
            .map(|item| SourceExemption {
                source: item.source.to_string(),
                reason: item.reason.to_string(),
            })
            .collect(),
        diagnostics: summary
            .diagnostics
            .into_iter()
            .map(|item| DiscoveryDiagnostic {
                source: item.source,
                locator: item.locator,
                error: item.error,
            })
            .collect(),
        counters: DiscoveryCounters {
            candidates_enumerated: summary.counters.candidates_enumerated as i64,
            shallow_reads: summary.counters.shallow_reads as i64,
            skipped_unchanged: summary.counters.skipped_unchanged as i64,
            files_opened: summary.counters.files_opened as i64,
            bytes_read: summary.counters.bytes_read as i64,
            provider_queries: summary.counters.provider_queries as i64,
            records_inspected: summary.counters.records_inspected as i64,
        },
    })
}

#[napi(object)]
pub struct HydrateSessionOptions {
    pub source_connectors: Option<Vec<String>>,
    pub source: String,
    pub session_id: String,
    pub scope: Option<String>,
    pub db_path: Option<String>,
    pub include_related: Option<bool>,
}

#[napi(object)]
pub struct HydrationIndexedThrough {
    pub source_stamp: Option<String>,
    pub last_event_at_ms: Option<i64>,
}

#[napi(object)]
pub struct HydrationEvidence {
    pub prompts: i64,
    pub events: i64,
    pub tool_calls: i64,
    pub file_edits: i64,
    pub related_sessions: i64,
}

#[napi(object)]
pub struct HydrationDiagnostic {
    pub code: String,
    pub message: String,
    pub duration_ms: Option<i64>,
    pub source_bytes: Option<i64>,
    pub records_parsed: Option<i64>,
}

#[napi(object)]
pub struct HydrateSessionResult {
    pub contract_version: u32,
    pub source: String,
    pub session_id: String,
    pub status: String,
    pub capability: String,
    pub discovery_state: String,
    pub presence: String,
    pub indexed_through: HydrationIndexedThrough,
    pub evidence: HydrationEvidence,
    /// Bytes read from provider files by this hydration. About the size of
    /// the append when a live transcript grew, and small but **not zero** when
    /// the session was unchanged: deciding nothing changed means validating
    /// each cursor against a bounded window of the file it was written from.
    /// Zero is reserved for a pass that opened no provider file at all.
    pub bytes_read: i64,
    /// Evidence kinds this hydration can have indexed, as wire names
    /// (`history`, `session_event`, `tool_call`, `file_edit`,
    /// `relationship`, `commit_link`).
    pub coverage: Vec<String>,
    pub related_session_ids: Vec<String>,
    pub diagnostics: Vec<HydrationDiagnostic>,
}

fn hydration_error(error: anyhow::Error) -> napi::Error {
    let message = format!("{error:#}");
    for code in [
        "SESSION_NOT_FOUND",
        "SESSION_SOURCE_UNAVAILABLE",
        "SESSION_SOURCE_MISMATCH",
        "HYDRATION_UNSUPPORTED",
        "CONNECTOR_NOT_CONFIGURED",
        "AUTHENTICATION_EXPIRED",
        "EVIDENCE_PARTIAL",
        "CONNECTOR_FAILURE",
        "INVALID_ARGUMENT",
    ] {
        if let Some(detail) = message.strip_prefix(&format!("{code}: ")) {
            return native_error(code, detail);
        }
    }
    native_error("HYDRATION_FAILED", message)
}

/// Fully index one cataloged session without enumerating unrelated sessions.
#[napi]
pub async fn hydrate_session(options: HydrateSessionOptions) -> napi::Result<HydrateSessionResult> {
    let connectors = source_connector_selection(options.source_connectors)?;
    let scope = parse_scope(options.scope)?;
    let path = db_path(options.db_path);
    let request = ai_hist::HydrateSessionOptions {
        source: options.source,
        session_id: options.session_id,
        scope,
        include_related: options.include_related.unwrap_or(true),
    };
    let result = napi::tokio::task::spawn_blocking(move || {
        ai_hist::hydrate_session_at_with_connectors(&path, &request, &connectors)
    })
    .await
    .map_err(worker_error)?
    .map_err(hydration_error)?;
    Ok(HydrateSessionResult {
        contract_version: result.contract_version,
        source: result.source,
        session_id: result.session_id,
        status: result.status,
        capability: result.capability,
        discovery_state: result.discovery_state,
        presence: result.presence,
        indexed_through: HydrationIndexedThrough {
            source_stamp: result.indexed_through.source_stamp,
            last_event_at_ms: result.indexed_through.last_event_at_ms,
        },
        evidence: HydrationEvidence {
            prompts: result.evidence.prompts as i64,
            events: result.evidence.events as i64,
            tool_calls: result.evidence.tool_calls as i64,
            file_edits: result.evidence.file_edits as i64,
            related_sessions: result.evidence.related_sessions as i64,
        },
        bytes_read: result.bytes_read,
        coverage: result
            .coverage
            .iter()
            .map(|kind| kind.as_str().to_string())
            .collect(),
        related_session_ids: result.related_session_ids,
        diagnostics: result
            .diagnostics
            .into_iter()
            .map(|diagnostic| HydrationDiagnostic {
                code: diagnostic.code,
                message: diagnostic.message,
                duration_ms: diagnostic.duration_ms,
                source_bytes: diagnostic.source_bytes,
                records_parsed: diagnostic.records_parsed,
            })
            .collect(),
    })
}

/// Reject an unusable identity before opening anything, so a typo is an
/// argument error rather than an empty result that looks like real data.
fn validate_relationship_identity(source: &str, session_id: &str) -> napi::Result<()> {
    if session_id.trim().is_empty() {
        return Err(native_error(
            "INVALID_ARGUMENT",
            "sessionId must not be empty",
        ));
    }
    // The catalog sources are the ones hydration accepts, as the harness
    // registry declares them.
    if !ai_hist::sources::catalog::local_source(source)
        .is_some_and(|descriptor| descriptor.is_hydration_source())
    {
        return Err(native_error(
            "INVALID_ARGUMENT",
            format!("unsupported catalog source '{source}'"),
        ));
    }
    Ok(())
}

fn validate_bound(value: Option<i64>, name: &str, default: u32, max: u32) -> napi::Result<u32> {
    let value = match value {
        Some(value) => value,
        None => return Ok(default),
    };
    if !(1..=i64::from(max)).contains(&value) {
        return Err(native_error(
            "INVALID_ARGUMENT",
            format!("{name} must be between 1 and {max} (got {value})"),
        ));
    }
    Ok(value as u32)
}

#[napi(object)]
pub struct NativeSessionRelationship {
    pub source: String,
    pub parent_session_id: String,
    pub child_session_id: Option<String>,
    pub relationship: String,
    pub identity_status: String,
    pub child_agent_type: Option<String>,
    pub child_agent_name: Option<String>,
    pub child_model: Option<String>,
    pub spawn_depth: Option<i64>,
    pub evidence_kind: String,
    pub evidence_locator: Option<String>,
    pub evidence_ref: Option<String>,
    pub child_has_events: bool,
    pub spawned_at_ms: Option<i64>,
    pub created_ms: i64,
    pub relationship_uid: String,
    pub origin_session_id: Option<String>,
}

impl From<CoreSessionRelationship> for NativeSessionRelationship {
    fn from(relationship: CoreSessionRelationship) -> Self {
        Self {
            source: relationship.source,
            parent_session_id: relationship.parent_session_id,
            child_session_id: relationship.child_session_id,
            relationship: relationship.relationship,
            identity_status: relationship.identity_status,
            child_agent_type: relationship.child_agent_type,
            child_agent_name: relationship.child_agent_name,
            child_model: relationship.child_model,
            spawn_depth: relationship.spawn_depth,
            evidence_kind: relationship.evidence_kind,
            evidence_locator: relationship.evidence_locator,
            evidence_ref: relationship.evidence_ref,
            child_has_events: relationship.child_has_events,
            spawned_at_ms: relationship.spawned_at_ms,
            created_ms: relationship.created_ms,
            relationship_uid: relationship.relationship_uid,
            origin_session_id: relationship.origin_session_id,
        }
    }
}

#[napi(object)]
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct NativeRelationshipCapabilities {
    pub source: String,
    pub stable_child_identity: String,
    pub records_agent_type: bool,
    pub records_spawn_time: bool,
    pub records_evidence_locator: bool,
}

impl From<CoreRelationshipCapabilities> for NativeRelationshipCapabilities {
    fn from(capabilities: CoreRelationshipCapabilities) -> Self {
        Self {
            source: capabilities.source,
            stable_child_identity: capabilities.stable_child_identity,
            records_agent_type: capabilities.records_agent_type,
            records_spawn_time: capabilities.records_spawn_time,
            records_evidence_locator: capabilities.records_evidence_locator,
        }
    }
}

#[napi(object)]
pub struct NativeRelationshipDiagnostic {
    pub code: String,
    pub message: String,
    pub relationship_uid: Option<String>,
}

impl From<CoreRelationshipDiagnostic> for NativeRelationshipDiagnostic {
    fn from(diagnostic: CoreRelationshipDiagnostic) -> Self {
        Self {
            code: diagnostic.code,
            message: diagnostic.message,
            relationship_uid: diagnostic.relationship_uid,
        }
    }
}

#[napi(object)]
pub struct NativeSessionRelationships {
    pub contract_version: u32,
    pub source: String,
    pub session_id: String,
    pub as_parent: Vec<NativeSessionRelationship>,
    pub as_child: Vec<NativeSessionRelationship>,
    pub continuity: Vec<NativeSessionRelationship>,
    pub capabilities: NativeRelationshipCapabilities,
    pub diagnostics: Vec<NativeRelationshipDiagnostic>,
}

impl From<CoreSessionRelationships> for NativeSessionRelationships {
    fn from(relationships: CoreSessionRelationships) -> Self {
        Self {
            contract_version: relationships.contract_version,
            source: relationships.source,
            session_id: relationships.session_id,
            as_parent: relationships
                .as_parent
                .into_iter()
                .map(NativeSessionRelationship::from)
                .collect(),
            as_child: relationships
                .as_child
                .into_iter()
                .map(NativeSessionRelationship::from)
                .collect(),
            continuity: relationships
                .continuity
                .into_iter()
                .map(NativeSessionRelationship::from)
                .collect(),
            capabilities: relationships.capabilities.into(),
            diagnostics: relationships
                .diagnostics
                .into_iter()
                .map(NativeRelationshipDiagnostic::from)
                .collect(),
        }
    }
}

#[napi(object)]
pub struct NativeSessionTreeNode {
    pub source: String,
    pub session_id: String,
    pub depth: u32,
    pub parent_session_id: Option<String>,
    pub relationship: Option<NativeSessionRelationship>,
    pub child_count: u32,
    pub has_events: bool,
    pub truncated: bool,
}

impl From<CoreSessionTreeNode> for NativeSessionTreeNode {
    fn from(node: CoreSessionTreeNode) -> Self {
        Self {
            source: node.source,
            session_id: node.session_id,
            depth: node.depth,
            parent_session_id: node.parent_session_id,
            relationship: node.relationship.map(NativeSessionRelationship::from),
            child_count: node.child_count,
            has_events: node.has_events,
            truncated: node.truncated,
        }
    }
}

#[napi(object)]
pub struct NativeSessionTree {
    pub contract_version: u32,
    pub source: String,
    pub root_session_id: String,
    pub nodes: Vec<NativeSessionTreeNode>,
    pub unlinked: Vec<NativeSessionRelationship>,
    pub capabilities: NativeRelationshipCapabilities,
    pub diagnostics: Vec<NativeRelationshipDiagnostic>,
    pub truncated: bool,
    pub max_depth_reached: u32,
}

impl From<CoreSessionTree> for NativeSessionTree {
    fn from(tree: CoreSessionTree) -> Self {
        Self {
            contract_version: tree.contract_version,
            source: tree.source,
            root_session_id: tree.root_session_id,
            nodes: tree
                .nodes
                .into_iter()
                .map(NativeSessionTreeNode::from)
                .collect(),
            unlinked: tree
                .unlinked
                .into_iter()
                .map(NativeSessionRelationship::from)
                .collect(),
            capabilities: tree.capabilities.into(),
            diagnostics: tree
                .diagnostics
                .into_iter()
                .map(NativeRelationshipDiagnostic::from)
                .collect(),
            truncated: tree.truncated,
            max_depth_reached: tree.max_depth_reached,
        }
    }
}

#[napi(object)]
pub struct RelationshipCursor {
    pub spawned_at_ms: Option<i64>,
    pub relationship_uid: String,
}

#[napi(object)]
pub struct NativeSessionChildrenPage {
    pub children: Vec<NativeSessionRelationship>,
    pub next_cursor: Option<RelationshipCursor>,
}

#[napi(object)]
pub struct RelationshipOptions {
    pub source: String,
    pub session_id: String,
    pub db_path: Option<String>,
}

#[napi(object)]
pub struct SessionTreeOptions {
    pub source: String,
    pub session_id: String,
    pub db_path: Option<String>,
    pub max_depth: Option<i64>,
    pub max_nodes: Option<i64>,
    /// Which edges the walk follows. Omitted means delegation only, which is
    /// what every caller got before continuity existed.
    pub relationship_kinds: Option<Vec<String>>,
}

#[napi(object)]
pub struct SessionChildrenPageOptions {
    pub source: String,
    pub session_id: String,
    pub db_path: Option<String>,
    pub limit: Option<i64>,
    pub after: Option<RelationshipCursor>,
    pub relationship_kinds: Option<Vec<String>>,
}

/// Every relationship kind a caller may name, so a typo is refused at the
/// boundary rather than answered with a silently empty page.
const RELATIONSHIP_KIND_CHOICES: &[&str] = &[
    "delegated",
    "materialized_local",
    "continuation",
    "fork",
    "resume",
];

fn validate_relationship_kinds(kinds: Option<Vec<String>>) -> napi::Result<CoreRelationshipKinds> {
    let Some(kinds) = kinds else {
        return Ok(CoreRelationshipKinds::delegation());
    };
    for kind in &kinds {
        if !RELATIONSHIP_KIND_CHOICES.contains(&kind.as_str()) {
            return Err(native_error(
                "INVALID_ARGUMENT",
                format!(
                    "relationshipKinds must name only {}, got '{kind}'",
                    RELATIONSHIP_KIND_CHOICES.join(", ")
                ),
            ));
        }
    }
    Ok(CoreRelationshipKinds::only(kinds))
}

/// Direct delegation relationships for one session, in both directions.
/// A missing database is an empty result, not an error.
#[napi]
pub async fn get_session_relationships(
    options: RelationshipOptions,
) -> napi::Result<NativeSessionRelationships> {
    validate_relationship_identity(&options.source, &options.session_id)?;
    let path = db_path(options.db_path);
    let source = options.source;
    let session_id = options.session_id;
    // Capabilities are a property of the provider, not of this database, so
    // an empty result still answers what the provider could record.
    let empty = NativeSessionRelationships {
        contract_version: SESSION_RELATIONSHIP_CONTRACT_VERSION,
        source: source.clone(),
        session_id: session_id.clone(),
        as_parent: Vec::new(),
        as_child: Vec::new(),
        continuity: Vec::new(),
        capabilities: relationship_capabilities(&source).into(),
        diagnostics: Vec::new(),
    };
    read_database_with_schema(
        path,
        empty,
        schema_is_relationship_read_current,
        move |conn| Ok(core_session_relationships(conn, &source, &session_id)?.into()),
    )
    .await
}

/// The complete descendant delegation tree for one session: pre-order,
/// cycle-safe, and bounded by `maxDepth` / `maxNodes`.
#[napi]
pub async fn get_session_tree(options: SessionTreeOptions) -> napi::Result<NativeSessionTree> {
    validate_relationship_identity(&options.source, &options.session_id)?;
    let max_depth = validate_bound(
        options.max_depth,
        "maxDepth",
        DEFAULT_TREE_MAX_DEPTH,
        MAX_TREE_MAX_DEPTH,
    )?;
    let max_nodes = validate_bound(
        options.max_nodes,
        "maxNodes",
        DEFAULT_TREE_MAX_NODES,
        MAX_TREE_MAX_NODES,
    )?;
    let relationship_kinds = validate_relationship_kinds(options.relationship_kinds)?;
    let path = db_path(options.db_path);
    let source = options.source;
    let session_id = options.session_id;
    // A tree always contains its root, so the missing-database answer is the
    // same shape a real empty tree has: one node, no descendants.
    let empty = NativeSessionTree {
        contract_version: SESSION_RELATIONSHIP_CONTRACT_VERSION,
        source: source.clone(),
        root_session_id: session_id.clone(),
        nodes: vec![NativeSessionTreeNode {
            source: source.clone(),
            session_id: session_id.clone(),
            depth: 0,
            parent_session_id: None,
            relationship: None,
            child_count: 0,
            has_events: false,
            truncated: false,
        }],
        unlinked: Vec::new(),
        capabilities: relationship_capabilities(&source).into(),
        diagnostics: Vec::new(),
        truncated: false,
        max_depth_reached: 0,
    };
    read_database_with_schema(
        path,
        empty,
        schema_is_relationship_read_current,
        move |conn| {
            let tree = core_session_tree(
                conn,
                &source,
                &session_id,
                &CoreSessionTreeOptions {
                    max_depth,
                    max_nodes,
                    relationship_kinds,
                },
            )?;
            Ok(tree.into())
        },
    )
    .await
}

/// One bounded page of a session's direct children, in the same total order
/// the tree traversal uses.
#[napi]
pub async fn get_session_children_page(
    options: SessionChildrenPageOptions,
) -> napi::Result<NativeSessionChildrenPage> {
    validate_relationship_identity(&options.source, &options.session_id)?;
    let limit = validate_limit(
        options.limit,
        DEFAULT_CHILDREN_PAGE_LIMIT,
        MAX_CHILDREN_PAGE_LIMIT,
    )?;
    let relationship_kinds = validate_relationship_kinds(options.relationship_kinds)?;
    let path = db_path(options.db_path);
    let source = options.source;
    let session_id = options.session_id;
    let after = options.after.map(|cursor| CoreRelationshipCursor {
        spawned_at_ms: cursor.spawned_at_ms,
        relationship_uid: cursor.relationship_uid,
    });
    read_database_with_schema(
        path,
        NativeSessionChildrenPage {
            children: Vec::new(),
            next_cursor: None,
        },
        schema_is_relationship_read_current,
        move |conn| {
            let page = core_session_children_page(
                conn,
                &source,
                &session_id,
                limit,
                after.as_ref(),
                &relationship_kinds,
            )?;
            Ok(NativeSessionChildrenPage {
                children: page
                    .children
                    .into_iter()
                    .map(NativeSessionRelationship::from)
                    .collect(),
                next_cursor: page.next_cursor.map(|cursor| RelationshipCursor {
                    spawned_at_ms: cursor.spawned_at_ms,
                    relationship_uid: cursor.relationship_uid,
                }),
            })
        },
    )
    .await
}

#[napi(object)]
pub struct SyncOptions {
    pub source_connectors: Option<Vec<String>>,
    pub db_path: Option<String>,
    pub scope: Option<String>,
}

#[napi(object)]
pub struct SyncResult {
    pub database_path: String,
    pub completed: bool,
    pub scope: String,
}

/// Explicit full ingestion. A read operation never calls this implicitly.
#[napi]
pub async fn sync(options: Option<SyncOptions>) -> napi::Result<SyncResult> {
    let options = options.unwrap_or(SyncOptions {
        source_connectors: None,
        db_path: None,
        scope: None,
    });
    let scope = parse_scope(options.scope)?;
    let connectors = source_connector_selection(options.source_connectors)?;
    ensure_acquisition_scope_supported(scope, "sync", &[], &connectors)?;
    let path = db_path(options.db_path);
    let result_path = path.display().to_string();
    let completed = napi::tokio::task::spawn_blocking(move || {
        ai_hist::sync_scoped_at_with_connectors(&path, scope, &connectors)
    })
    .await
    .map_err(worker_error)?
    .map_err(|error| native_error("SYNC_FAILED", format!("{error:#}")))?;
    Ok(SyncResult {
        database_path: result_path,
        completed,
        scope: scope_name(scope),
    })
}

/// Backward-compatible internal capture entry point; not used by the SDK.
#[napi]
pub async fn sync_local() -> napi::Result<()> {
    sync(None).await.map(|_| ())
}

#[napi]
pub async fn install_git_hooks(
    options_json: String,
    node: String,
    sdk_url: String,
) -> napi::Result<String> {
    napi::tokio::task::spawn_blocking(move || {
        let options = serde_json::from_str(&options_json)?;
        ai_hist::git_sdk::install(options, &node, &sdk_url)
    })
    .await
    .map_err(worker_error)?
    .map_err(|error: anyhow::Error| native_error("GIT_HOOK_FAILED", format!("{error:#}")))
}

#[napi]
pub async fn link_git_commit(options_json: String) -> napi::Result<String> {
    napi::tokio::task::spawn_blocking(move || {
        let options = serde_json::from_str(&options_json)?;
        ai_hist::git_sdk::link(options)
    })
    .await
    .map_err(worker_error)?
    .map_err(|error: anyhow::Error| native_error("GIT_LINK_FAILED", format!("{error:#}")))
}

#[cfg(test)]
mod tests {
    use super::{js_count, MAX_JS_SAFE_COUNT};

    /// The boundary is `Number.MAX_SAFE_INTEGER`, not `i64::MAX`: beyond it a
    /// JavaScript number is no longer the value it was handed.
    #[test]
    fn a_count_javascript_cannot_represent_is_refused_not_rounded() {
        assert_eq!(js_count(0), Some(0));
        assert_eq!(js_count(43), Some(43));
        assert_eq!(
            js_count(MAX_JS_SAFE_COUNT),
            Some(9_007_199_254_740_991_i64),
            "the largest exactly representable integer still crosses"
        );
        assert_eq!(js_count(MAX_JS_SAFE_COUNT + 1), None);
        assert_eq!(js_count(u64::MAX), None);
    }

    /// The regression this replaced: `i64::try_from(u64::MAX)` saturating to
    /// `i64::MAX` handed JavaScript a number that is neither the stored value
    /// nor representable.
    #[test]
    fn the_old_i64_ceiling_is_not_the_boundary() {
        assert!(i64::try_from(u64::MAX).is_err());
        assert_eq!(js_count(i64::MAX as u64), None);
    }
}
