import assert from 'node:assert/strict';
import { existsSync, mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';

import {
  installChildEnv,
  installWithRegistryRetry,
  isRegistryVisibilityFailure,
} from './npm-install-with-registry-retry.mjs';

const quiet = {
  emit: () => {},
  log: () => {},
  reset: () => {},
};

test('recognizes only npm registry visibility errors as retryable', () => {
  assert.equal(isRegistryVisibilityFailure('npm error code ETARGET'), true);
  assert.equal(isRegistryVisibilityFailure('npm error code E404'), true);
  assert.equal(isRegistryVisibilityFailure('npm error code EACCES'), false);
  assert.equal(isRegistryVisibilityFailure('network timeout'), false);
});

test('retries a registry miss until the exact release becomes installable', async () => {
  const results = [
    { status: 1, stdout: '', stderr: 'npm error code ETARGET' },
    { status: 1, stdout: '', stderr: 'npm error code E404' },
    { status: 0, stdout: 'installed', stderr: '' },
  ];
  const waits = [];
  let resets = 0;

  await installWithRegistryRetry(['ai-hist@0.9.0'], {
    ...quiet,
    attempts: 5,
    delayMs: 7,
    runInstall: () => results.shift(),
    sleep: async (ms) => waits.push(ms),
    reset: () => { resets += 1; },
  });

  assert.deepEqual(waits, [7, 7]);
  assert.equal(resets, 2);
  assert.equal(results.length, 0);
});

test('fails immediately for authentication and other non-propagation errors', async () => {
  let calls = 0;
  await assert.rejects(
    installWithRegistryRetry(['ai-hist@0.9.0'], {
      ...quiet,
      attempts: 5,
      runInstall: () => {
        calls += 1;
        return { status: 7, stdout: '', stderr: 'npm error code E401' };
      },
      sleep: async () => assert.fail('non-retryable failures must not sleep'),
    }),
    (error) => error.exitCode === 7 && /non-registry-visibility/.test(error.message),
  );
  assert.equal(calls, 1);
});

test('fails after the bounded number of registry visibility attempts', async () => {
  let calls = 0;
  await assert.rejects(
    installWithRegistryRetry(['ai-hist@0.9.0'], {
      ...quiet,
      attempts: 3,
      delayMs: 1,
      runInstall: () => {
        calls += 1;
        return { status: 1, stdout: '', stderr: 'npm error code ETARGET' };
      },
      sleep: async () => {},
    }),
    /after 3 attempts/,
  );
  assert.equal(calls, 3);
});

test('supplied env is the child environment, not a patch on process.env', () => {
  const previous = process.env.NODE_AUTH_TOKEN;
  process.env.NODE_AUTH_TOKEN = 'from-parent';
  try {
    const patched = installChildEnv({ env: { PATH: '/bin' } }, '/tmp/cache');
    assert.equal(patched.PATH, '/bin');
    assert.equal(patched.npm_config_cache, '/tmp/cache');
    assert.equal('NODE_AUTH_TOKEN' in patched, false);
    const inherited = installChildEnv({}, '/tmp/cache');
    assert.equal(inherited.NODE_AUTH_TOKEN, 'from-parent');
  } finally {
    if (previous === undefined) delete process.env.NODE_AUTH_TOKEN;
    else process.env.NODE_AUTH_TOKEN = previous;
  }
});

test('a zero exit that did not land the required package is retried', async () => {
  const results = [
    { status: 0, stdout: 'added 99 packages\n', stderr: '' },
    { status: 0, stdout: 'added 101 packages\n', stderr: '' },
  ];
  const waits = [];
  let resets = 0;
  let confirmCalls = 0;
  const logged = [];

  await installWithRegistryRetry(['--prefix', '/tmp/verify'], {
    ...quiet,
    attempts: 4,
    delayMs: 3,
    runInstall: () => results.shift(),
    sleep: async (ms) => waits.push(ms),
    reset: () => { resets += 1; },
    log: (message) => logged.push(message),
    confirm: () => {
      confirmCalls += 1;
      return confirmCalls === 1
        ? '@relayhistory/provider-sources-linux-x64-gnu did not install'
        : '';
    },
  });

  assert.equal(confirmCalls, 2);
  assert.deepEqual(waits, [3]);
  assert.equal(resets, 1);
  assert.equal(results.length, 0);
  assert.match(logged[0], /provider-sources-linux-x64-gnu did not install \(attempt 1\/4\)/);
});

test('exhausting zero-exit misses reports the missing package', async () => {
  let calls = 0;
  await assert.rejects(
    installWithRegistryRetry(['--prefix', '/tmp/verify'], {
      ...quiet,
      attempts: 2,
      delayMs: 1,
      runInstall: () => {
        calls += 1;
        return { status: 0, stdout: 'added 99 packages\n', stderr: '' };
      },
      sleep: async () => {},
      confirm: () => '@relayhistory/provider-sources-linux-x64-gnu did not install',
    }),
    (error) => {
      assert.equal(error.exitCode, 1);
      assert.match(error.message, /provider-sources-linux-x64-gnu did not install/);
      assert.match(error.message, /after 2 attempts/);
      return true;
    },
  );
  assert.equal(calls, 2);
});

test('retries clear node_modules under options.cwd, not process.cwd', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'ai-hist-retry-cwd-'));
  mkdirSync(join(dir, 'node_modules'));
  writeFileSync(join(dir, 'package-lock.json'), '{}\n');
  try {
    let calls = 0;
    await installWithRegistryRetry(['--prefix', dir, 'pkg'], {
      attempts: 2,
      delayMs: 1,
      cwd: dir,
      emit: () => {},
      log: () => {},
      sleep: async () => {},
      runInstall: () => {
        calls += 1;
        return calls === 1
          ? { status: 1, stdout: '', stderr: 'npm error code ETARGET' }
          : { status: 0, stdout: '', stderr: '' };
      },
    });
    assert.equal(calls, 2);
    assert.equal(existsSync(join(dir, 'node_modules')), false);
    assert.equal(existsSync(join(dir, 'package-lock.json')), false);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
