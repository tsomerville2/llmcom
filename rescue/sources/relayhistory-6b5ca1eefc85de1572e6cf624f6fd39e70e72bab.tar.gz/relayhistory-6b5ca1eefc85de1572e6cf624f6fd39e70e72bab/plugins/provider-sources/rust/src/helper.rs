//! Bounded one-request bridge for explicitly selected provider-native adapters.
use ai_hist::{observations::SessionObservation, EvidenceKind, SessionLocation};
use ai_hist::discover::DiscoveryEnv;
use anyhow::{ensure, Context, Result};
use serde::Deserialize;
use serde_json::{json, Value};

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Request {
    pub version: u32,
    pub operation: String,
    #[serde(default)]
    pub args: Arguments,
}
#[derive(Default, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Arguments {
    pub connector_id: Option<String>,
    pub connector_instance: Option<String>,
    pub source: Option<String>,
    pub limit: Option<usize>,
    pub observation: Option<SessionObservation>,
    /// Absent means the caller did not say, which keeps the historical
    /// behaviour of acquiring related evidence.
    pub include_related: Option<bool>,
}
// Validate caller-controlled identities before resolving HOME, constructing an
// adapter, or probing credentials. Classification is based on this phase, never
// on error text returned by a provider or transport.
fn validate_request(request: &Request) -> Result<()> {
    ensure!(request.version == 1, "unsupported helper version");
    ensure!(
        matches!(request.operation.as_str(), "discover" | "hydrate"),
        "unknown operation"
    );
    let args = &request.args;
    let connector = args
        .connector_id
        .as_deref()
        .context("connectorId required")?;
    let source = match connector {
        crate::remote::CLAUDE_WEB_CONNECTOR => "claude",
        crate::remote::CODEX_CLOUD_CONNECTOR => "codex",
        _ => anyhow::bail!("unknown source connector"),
    };
    let instance = args.connector_instance.as_deref().unwrap_or("default");
    ensure!(
        !instance.is_empty()
            && instance.trim() == instance
            && instance.len() <= 512
            && !instance.chars().any(char::is_control),
        "invalid connector instance"
    );
    ensure!(
        args.limit.is_none_or(|limit| limit <= 10_000),
        "invalid source limit"
    );
    ensure!(
        args.source
            .as_deref()
            .is_none_or(|selected| selected == source),
        "source mismatch"
    );
    if request.operation == "hydrate" {
        let observation = args.observation.as_ref().context("observation required")?;
        observation.key.validate()?;
        ensure!(
            observation.key.connector_id == connector
                && observation.key.connector_instance == instance
                && observation.key.source == source
                && observation.key.location == SessionLocation::Remote,
            "observation identity mismatch"
        );
        ensure!(
            ["available", "unavailable", "withdrawn"].contains(&observation.access_state.as_str()),
            "invalid observation access state"
        );
        ensure!(
            ["shallow", "full"].contains(&observation.discovery_state.as_str()),
            "invalid observation discovery state"
        );
    }
    Ok(())
}
fn execute(request: Request) -> Result<Value> {
    let args = request.args;
    let connector = args.connector_id.context("connectorId required")?;
    let instance = args.connector_instance.as_deref().unwrap_or("default");
    let home = resolve_home(std::env::var_os("HOME"), std::env::var_os("USERPROFILE"))?;
    let home = home.as_path();
    let provider = crate::remote::provider(home, &connector, instance, args.limit)?;
    if let Some(source) = &args.source {
        ensure!(provider.source() == source, "source mismatch");
    }
    if request.operation == "discover" {
        provider.check_available(home)?;
        // Provider enumeration takes the public engine context. This ephemeral
        // connection cannot mutate the caller's history or acquisition cursor.
        let conn = rusqlite::Connection::open_in_memory()?;
        let env = DiscoveryEnv::with_roots(&conn, home.into(), home.join("unused-opencode.db"));
        let candidates = provider.enumerate(&env, args.limit)?;
        let mut observations = Vec::new();
        for candidate in candidates {
            if let Some(mut row) = provider.read_shallow(&env.scan(), None, &candidate)? {
                row.source_stamp = Some(candidate.stamp.clone());
                row.locations = vec!["remote".into()];
                let mut value = serde_json::to_value(row)?;
                value
                    .as_object_mut()
                    .context("source observation object required")?
                    .insert("raw_locator".into(), json!(candidate.locator));
                observations.push(value);
            }
        }
        Ok(json!({"observations": observations}))
    } else {
        let observation = args.observation.context("observation required")?;
        observation.key.validate()?;
        ensure!(
            observation.key.connector_id == connector
                && observation.key.connector_instance == instance
                && observation.key.source == provider.source()
                && observation.key.location == SessionLocation::Remote,
            "observation identity mismatch"
        );
        ensure!(
            observation.access_state == "available",
            "observation unavailable"
        );
        provider.check_available(home)?;
        let evidence = provider.acquire(home, &observation)?;
        let mut normalized = ai_hist::sources::normalize_source_evidence(
            provider.source(),
            &observation.key.session_id,
            evidence,
        )?;
        if args.include_related == Some(false) {
            drop_related(&mut normalized);
        }
        Ok(serde_json::to_value(normalized)?)
    }
}
/// Remove delegation evidence from a snapshot the caller asked to scope to one
/// thread.
///
/// Claude's full export derives relationships from the transcript it already
/// fetched, so there is no separate acquisition to skip -- what matters is that
/// the snapshot neither *reports* nor *returns* the kind. Leaving it in
/// `covered_kinds` would let the merge union reinstate exactly what the local
/// path dropped for the same request, and `scope: "all"` could then read `full`
/// despite the opt-out.
fn drop_related(normalized: &mut ai_hist::sources::NormalizedSourceEvidence) {
    normalized
        .covered_kinds
        .retain(|kind| *kind != EvidenceKind::Relationship);
    normalized
        .records
        .retain(|record| record.kind != EvidenceKind::Relationship);
}

pub fn handle(request: Request) -> Value {
    if validate_request(&request).is_err() {
        return json!({"version":1,"ok":false,"error":{"code":"INVALID_ARGUMENT","message":"Invalid provider source request; verify operation, connector identity, source and limits"}});
    }
    match execute(request) {
        Ok(value) => json!({"version":1,"ok":true,"value":value}),
        Err(_) => {
            json!({"version":1,"ok":false,"error":{"code":"CONNECTOR_FAILURE","message":"Provider source operation failed; verify explicit connector configuration and provider CLI sign-in"}})
        }
    }
}

fn resolve_home(
    home: Option<std::ffi::OsString>,
    user_profile: Option<std::ffi::OsString>,
) -> Result<std::path::PathBuf> {
    home.filter(|value| !value.is_empty())
        .or_else(|| user_profile.filter(|value| !value.is_empty()))
        .map(Into::into)
        .context("HOME or USERPROFILE required")
}

#[cfg(test)]
mod tests {
    use super::{drop_related, resolve_home};
    use ai_hist::{EvidenceKind, EvidenceRecord};
    use std::path::PathBuf;

    fn record(kind: EvidenceKind) -> EvidenceRecord {
        EvidenceRecord {
            kind,
            payload: serde_json::Map::new(),
            record_id: None,
            revision_id: None,
        }
    }

    /// Declining related evidence has to remove the kind from `covered_kinds`
    /// as well as the rows: coverage is what the merge unions, so reporting it
    /// covered would put back what the local path dropped for this request.
    #[test]
    fn declining_related_evidence_drops_both_the_coverage_and_the_rows() {
        let mut normalized = ai_hist::sources::NormalizedSourceEvidence {
            source_stamp: "stamp".into(),
            source_bytes: 0,
            covered_kinds: vec![
                EvidenceKind::History,
                EvidenceKind::SessionEvent,
                EvidenceKind::ToolCall,
                EvidenceKind::FileEdit,
                EvidenceKind::Relationship,
            ],
            records: vec![
                record(EvidenceKind::History),
                record(EvidenceKind::Relationship),
                record(EvidenceKind::ToolCall),
            ],
        };
        drop_related(&mut normalized);
        assert_eq!(
            normalized.covered_kinds,
            vec![
                EvidenceKind::History,
                EvidenceKind::SessionEvent,
                EvidenceKind::ToolCall,
                EvidenceKind::FileEdit,
            ]
        );
        assert_eq!(
            normalized
                .records
                .iter()
                .map(|record| record.kind)
                .collect::<Vec<_>>(),
            vec![EvidenceKind::History, EvidenceKind::ToolCall]
        );
        // Everything else the snapshot carries is untouched.
        assert_eq!(normalized.source_stamp, "stamp");
    }

    #[test]
    fn home_resolution_supports_windows_profile_and_rejects_empty_paths() {
        let profile = PathBuf::from("fixture-user-profile");
        assert_eq!(
            resolve_home(None, Some(profile.clone().into_os_string())).unwrap(),
            profile
        );
        assert_eq!(
            resolve_home(Some("".into()), Some(profile.clone().into_os_string())).unwrap(),
            profile
        );
        assert_eq!(
            resolve_home(Some("fixture-home".into()), Some(profile.into_os_string())).unwrap(),
            PathBuf::from("fixture-home")
        );
        assert!(resolve_home(None, None).is_err());
        assert!(resolve_home(Some("".into()), Some("".into())).is_err());
    }
}
