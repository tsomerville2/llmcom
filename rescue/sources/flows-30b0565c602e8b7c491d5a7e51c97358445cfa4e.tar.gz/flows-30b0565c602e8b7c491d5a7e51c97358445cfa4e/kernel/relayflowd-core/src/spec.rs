//! Run specs — the composable unit (RFC-0001 settled decision #5), one dialect.
//!
//! This is the single spec shape at the SDK↔kernel boundary: snake_case keys,
//! semver `version`, flat v0 verification (`output_contains` / `json_schema`;
//! `exit_code == 0` is implicit for deterministic steps — kernel DESIGN.md §4).
//! The SDK compiler emits exactly this shape; parity is pinned bit-for-bit by
//! `tests/spec_parity.rs` against `testdata/hello-ladder.spec.canonical.json`.
//!
//! Parsing is fail-closed (AGENTS.md rule 4): [`RunSpec::parse`] rejects any
//! unknown field, so a misspelled `verification` key can never silently drop a
//! gate. Nested structs carry `deny_unknown_fields`; step objects (which use
//! `#[serde(flatten)]`, where serde cannot enforce it) are checked explicitly.

use std::collections::{BTreeMap, BTreeSet};

use serde::{Deserialize, Serialize};
use serde_json::Value;
use thiserror::Error;

mod dependencies;

use dependencies::validate_dependency_cycles;

/// The spec schema version this kernel reads and writes (semver, RFC §7).
pub const SPEC_VERSION: &str = "0.1.0";

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct RunSpec {
    #[serde(default = "default_spec_version")]
    pub version: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
    /// Default CLI declaration for llm/agent steps. `flows check` resolves
    /// step → flow → project config. The kernel treats this as inert data;
    /// `run.start` does not invoke the surface preflight in gate 1.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub cli: Option<String>,
    /// Inert gate-1 declarations. Matching and dispatch belong to gate 2.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub triggers: Vec<TriggerSpec>,
    #[serde(default)]
    pub steps: Vec<StepSpec>,
    /// Budget envelope (RFC settled decision #10). Carried and journaled from
    /// gate 1; enforced when llm/agent dispatch lands — the deterministic rung
    /// spends zero tokens.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub budget: Option<BudgetSpec>,
}

fn default_spec_version() -> String {
    SPEC_VERSION.to_owned()
}

impl RunSpec {
    /// Fail-closed parse: reject unknown fields everywhere before
    /// deserializing. `#[serde(flatten)]` on [`StepSpec`] prevents serde-level
    /// `deny_unknown_fields` for step objects, so their key sets are checked
    /// here; every non-flattened struct denies unknown fields via serde.
    pub fn parse(value: &Value) -> Result<Self, SpecError> {
        reject_unknown_step_fields(value)?;
        serde_json::from_value(value.clone())
            .map_err(|error| SpecError::Malformed(error.to_string()))
    }

    pub fn validate(&self) -> Result<(), SpecError> {
        if self.version != SPEC_VERSION {
            return Err(SpecError::UnsupportedVersion(self.version.clone()));
        }

        if self.cli.as_ref().is_some_and(|cli| cli.trim().is_empty()) {
            return Err(SpecError::EmptyCli);
        }

        if let Some(budget) = &self.budget {
            if budget
                .max_dollars
                .as_deref()
                .is_some_and(|v| !crate::memory::valid_decimal(v))
                || budget
                    .prior_spend
                    .as_ref()
                    .is_some_and(|p| !crate::memory::valid_decimal(&p.dollars))
            {
                return Err(SpecError::Malformed(
                    "budget dollars must be non-negative decimal strings".into(),
                ));
            }
        }
        let mut trigger_ids = BTreeSet::new();
        for trigger in &self.triggers {
            if trigger.id.trim().is_empty()
                || trigger.executor.trim().is_empty()
                || trigger
                    .event_type
                    .as_ref()
                    .is_some_and(|value| value.trim().is_empty())
                || trigger
                    .dedupe_key_template
                    .as_ref()
                    .is_some_and(|value| value.trim().is_empty())
                || trigger
                    .pattern
                    .as_ref()
                    .is_some_and(|value| crate::event::validate_pattern(value).is_err())
                || trigger.event_type.is_some() != trigger.dedupe_key_template.is_some()
            // A stale_after_ms that does not fit in i64 would make
            // the subscription un-stale-able — the liveness sweep
            // stores that budget as i64. Refuse at parse time so
            // the operator sees the error before submitting events
            // rather than at the first arrival. i64::MAX ms is
            // ~292M years; a value past that is not a real budget.
            {
                return Err(SpecError::InvalidTrigger(trigger.id.clone()));
            }
            // Bounds-check via `TriggerSpec::effective_stale_after_ms`
            // — the single source of truth shared with
            // `engine::submit_event`. Any change to the bound (default
            // shift, u64→u128 someday) lives in one place. A default
            // of 0 here means the spec's own value is the value under
            // test; validate does not care what the engine's default
            // is, only that a DECLARED value fits.
            if trigger.stale_after_ms.is_some()
                && let Err(ms) = trigger.effective_stale_after_ms(0)
            {
                return Err(SpecError::TriggerStaleAfterMsOutOfRange {
                    id: trigger.id.clone(),
                    ms,
                });
            }
            if !trigger_ids.insert(trigger.id.clone()) {
                return Err(SpecError::DuplicateTrigger(trigger.id.clone()));
            }
        }

        let mut ids = BTreeSet::new();
        for step in &self.steps {
            if step.id.trim().is_empty() {
                return Err(SpecError::EmptyStepId);
            }
            if !ids.insert(step.id.clone()) {
                return Err(SpecError::DuplicateStep(step.id.clone()));
            }
            if step.max_iterations == 0 {
                return Err(SpecError::ZeroIterations(step.id.clone()));
            }
            if let StepKind::Deterministic {
                lease_ms: Some(ms), ..
            } = &step.kind
                && (*ms == 0 || *ms > i64::MAX as u64)
            {
                return Err(SpecError::Malformed(format!(
                    "step {}: lease_ms must be positive and fit in i64",
                    step.id
                )));
            }
            let cli = match &step.kind {
                StepKind::Llm { cli, .. } | StepKind::Agent { cli, .. } => cli,
                StepKind::Deterministic { .. } => &None,
            };
            if cli.as_ref().is_some_and(|value| value.trim().is_empty()) {
                return Err(SpecError::EmptyStepCli(step.id.clone()));
            }
            if step
                .cli_identity
                .as_ref()
                .is_some_and(|value| value.trim().is_empty())
            {
                return Err(SpecError::Malformed(format!(
                    "step {}: cli_identity must be a non-empty string",
                    step.id
                )));
            }
            if let StepKind::Agent { surfaces, cwd, .. } = &step.kind {
                if let Some(cwd) = cwd
                    && !is_run_root_relative_path(cwd)
                {
                    return Err(SpecError::InvalidAgentCwd {
                        step: step.id.clone(),
                        cwd: cwd.clone(),
                    });
                }
                for workspace in &surfaces.workspace {
                    if path_surface_identity(&workspace.surface).is_none() {
                        return Err(SpecError::InvalidWorkspaceSurface {
                            step: step.id.clone(),
                            surface: workspace.surface.clone(),
                        });
                    }
                }
                for path in &surfaces.external {
                    if path_surface_identity(path).is_none() {
                        return Err(SpecError::InvalidExternalSurface {
                            step: step.id.clone(),
                            path: path.clone(),
                        });
                    }
                }
            }
            if let Some(schema) = &step.verification.json_schema {
                crate::schema::validate_declaration(schema).map_err(|detail| {
                    SpecError::InvalidJsonSchema {
                        step: step.id.clone(),
                        detail,
                    }
                })?;
            }
            if let Some(memory) = &step.memory {
                memory
                    .validate()
                    .map_err(|detail| SpecError::InvalidMemory {
                        step: step.id.clone(),
                        detail,
                    })?;
            }
            if let Some(requirements) = &step.requirements {
                requirements.validate().map_err(SpecError::Malformed)?;
            }
            step.retry.validate(&step.id)?;
        }

        for step in &self.steps {
            for dependency in &step.depends_on {
                if dependency == &step.id {
                    return Err(SpecError::DependencyCycle(step.id.clone()));
                }
                if !ids.contains(dependency) {
                    return Err(SpecError::UnknownDependency {
                        step: step.id.clone(),
                        dependency: dependency.clone(),
                    });
                }
            }
        }

        let dependencies = self
            .steps
            .iter()
            .map(|step| (step.id.as_str(), step.depends_on.as_slice()))
            .collect::<BTreeMap<_, _>>();
        validate_dependency_cycles(&ids, &dependencies)?;
        crate::input::validate_inputs(self)?;
        Ok(())
    }

    pub fn step(&self, id: &str) -> Option<&StepSpec> {
        self.steps.iter().find(|step| step.id == id)
    }
}

/// Filesystem-free canonical identity for a declared writeback target.
///
/// The kernel cannot resolve host symlinks, so specs must already name a
/// lexical canonical path: no whitespace aliases, empty components, `.`, or
/// `..` — and a terminal slash is an empty final component, so it is refused
/// like any other. One surface has exactly one spelling. URI-like mount
/// identities retain their scheme as a namespace.
pub(crate) fn path_surface_identity(path: &str) -> Option<(String, Vec<String>)> {
    if path.is_empty() || path.trim() != path {
        return None;
    }
    let (namespace, tail) = if let Some(tail) = path.strip_prefix('/') {
        ("/".to_owned(), tail)
    } else if let Some(index) = path.find("://") {
        let scheme = &path[..index];
        if scheme.is_empty() || scheme.contains('/') {
            return None;
        }
        (path[..index + 3].to_owned(), &path[index + 3..])
    } else {
        (String::new(), path)
    };
    if tail.is_empty() {
        return Some((namespace, Vec::new()));
    }
    let components = tail.split('/').map(str::to_owned).collect::<Vec<_>>();
    (!components
        .iter()
        .any(|component| component.is_empty() || component == "." || component == ".."))
    .then_some((namespace, components))
}

/// Whether a declared agent `cwd` names a place inside the run's own tree.
///
/// The same lexical canonical rule surfaces get — no whitespace aliases,
/// empty components, `.` or `..` — narrowed to relative paths only, because
/// the declaration is read against the run root the worker executes under.
/// An absolute path or a URI-like mount identity names a place the run root
/// does not contain, and a `..` component walks out of it; both are refused
/// here rather than discovered on the host. NUL cannot occur in a host path
/// component, so a declaration carrying one can only mislead a reader.
fn is_run_root_relative_path(path: &str) -> bool {
    // U+FEFF is named explicitly because JavaScript's `\s` includes it and
    // `char::is_whitespace` does not; the SDK names U+0085 for the mirror
    // reason. Both sides then refuse `White_Space ∪ {U+FEFF}` at the edges,
    // so a padded declaration cannot pass `flows check` and be refused here.
    let padding = |c: char| c.is_whitespace() || c == '\u{feff}';
    !path.contains('\0')
        && !path.starts_with(padding)
        && !path.ends_with(padding)
        && matches!(path_surface_identity(path), Some((namespace, components))
            if namespace.is_empty() && !components.is_empty())
}

pub fn is_canonical_external_surface(path: &str) -> bool {
    path_surface_identity(path).is_some()
}

pub fn is_canonical_workspace_surface(surface: &str) -> bool {
    path_surface_identity(surface).is_some()
}

/// Workspace pins and declarations may differ only by a terminal slash.
/// Compare their parsed identities so `repo` and `repo/` remain one surface
/// throughout dispatch, pin chaining, and completion.
pub fn workspace_surfaces_equal(left: &str, right: &str) -> bool {
    matches!(
        (path_surface_identity(left), path_surface_identity(right)),
        (Some(left), Some(right)) if left == right
    )
}

pub fn external_surface_contains(declared: &str, target: &str) -> bool {
    let (
        Some((declared_namespace, declared_components)),
        Some((target_namespace, target_components)),
    ) = (
        path_surface_identity(declared),
        path_surface_identity(target),
    )
    else {
        return false;
    };
    declared_namespace == target_namespace && target_components.starts_with(&declared_components)
}

const STEP_COMMON_FIELDS: &[&str] = &[
    "id",
    "type",
    "depends_on",
    "input",
    "max_iterations",
    "retry",
    "verification",
    "memory",
    "requirements",
];
const STEP_DETERMINISTIC_FIELDS: &[&str] = &["command", "timeout_ms", "lease_ms", "on_non_zero"];
const STEP_LLM_FIELDS: &[&str] = &["prompt", "model", "cli", "cli_identity"];
const STEP_AGENT_FIELDS: &[&str] = &[
    "instruction",
    "cli",
    "cli_identity",
    "model",
    "cwd",
    "transport",
    "recovery_mode",
    "surfaces",
    "permissions",
];

fn reject_unknown_step_fields(value: &Value) -> Result<(), SpecError> {
    let Some(steps) = value.get("steps").and_then(Value::as_array) else {
        return Ok(()); // shape errors surface from serde with their own message
    };
    for (index, step) in steps.iter().enumerate() {
        let Some(object) = step.as_object() else {
            continue;
        };
        let kind_fields = match object.get("type").and_then(Value::as_str) {
            Some("deterministic") => STEP_DETERMINISTIC_FIELDS,
            Some("llm") => STEP_LLM_FIELDS,
            Some("agent") => {
                // `cwd` deserializes into `Option<String>`, where serde reads
                // an explicit null as absence — the step would then run in the
                // default directory under a spec that declared otherwise. The
                // shape is checked before serde so a null, a number or an
                // object is refused instead of silently defaulted.
                if let Some(cwd) = object.get("cwd")
                    && !cwd.is_string()
                {
                    return Err(SpecError::Malformed(format!(
                        "step {}: cwd must be a string",
                        object
                            .get("id")
                            .and_then(Value::as_str)
                            .unwrap_or("?")
                    )));
                }
                STEP_AGENT_FIELDS
            }
            // Missing/unknown type is rejected by serde's tagged-enum error.
            _ => continue,
        };
        if let Some(memory) = object.get("memory") {
            crate::memory::validate_shape(memory).map_err(|detail| SpecError::InvalidMemory {
                step: object
                    .get("id")
                    .and_then(Value::as_str)
                    .unwrap_or("?")
                    .into(),
                detail,
            })?;
        }
        if let Some(input) = object.get("input") {
            crate::input::validate_shape(input)?;
        }
        if let Some(requirements) = object.get("requirements") {
            crate::placement::validate_shape(requirements).map_err(SpecError::Malformed)?;
        }
        for key in object.keys() {
            if !STEP_COMMON_FIELDS.contains(&key.as_str()) && !kind_fields.contains(&key.as_str()) {
                return Err(SpecError::UnknownField {
                    at: format!("steps[{index}]"),
                    field: key.clone(),
                });
            }
        }
    }
    Ok(())
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct StepSpec {
    pub id: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub input: Option<crate::input::InputBindings>,
    #[serde(default)]
    pub depends_on: Vec<String>,
    #[serde(default = "default_max_iterations")]
    pub max_iterations: u32,
    #[serde(default)]
    pub retry: RetryPolicy,
    #[serde(default)]
    pub verification: VerificationSpec,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub memory: Option<crate::memory::MemorySpec>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub requirements: Option<crate::PlacementRequirements>,
    /// Host-proved authored name used to select an adapter when `cli` is the
    /// canonical target of a symlink with a generic basename.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub cli_identity: Option<String>,
    #[serde(flatten)]
    pub kind: StepKind,
}

fn default_max_iterations() -> u32 {
    1
}

impl StepSpec {
    pub fn step_type(&self) -> StepType {
        match self.kind {
            StepKind::Deterministic { .. } => StepType::Deterministic,
            StepKind::Llm { .. } => StepType::Llm,
            StepKind::Agent { .. } => StepType::Agent,
        }
    }
}

/// What a deterministic step's nonzero exit code means.
///
/// `Fail` is the kernel's long-standing implicit gate: `exit_code == 0` or the
/// step failed. `Record` is the repair-before-failure shape — the command is
/// allowed to be red, its exit code and output tails stay in the journal
/// exactly as executed, dependents run, and a later step reads the recorded
/// outcome instead of re-running the command. It is a policy for the step's
/// own exit code only; timeouts, worker errors, and declared content or schema
/// gates keep their existing fatal semantics.
#[derive(Debug, Clone, Copy, Default, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum OnNonZero {
    #[default]
    Fail,
    Record,
}

impl OnNonZero {
    fn is_default(&self) -> bool {
        matches!(self, OnNonZero::Fail)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum StepKind {
    Deterministic {
        command: CommandSpec,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        timeout_ms: Option<u64>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        lease_ms: Option<u64>,
        /// What a nonzero command exit means. Omitted on serialization when
        /// it is the default, so every spec written before this field exists
        /// keeps its exact canonical bytes and its exact hash.
        #[serde(default, skip_serializing_if = "OnNonZero::is_default")]
        on_non_zero: OnNonZero,
    },
    Llm {
        prompt: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        model: Option<String>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        cli: Option<String>,
    },
    Agent {
        instruction: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        cli: Option<String>,
        /// Model the declared CLI should use. The kernel never calls a model
        /// and never interprets this — it is carried and journaled so the
        /// choice is part of the run's record rather than ambient host state,
        /// then handed to the worker, which surfaces it to the CLI.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        model: Option<String>,
        /// Directory the attached worker spawns the declared CLI in, relative
        /// to the run root the worker executes under. The kernel performs no
        /// I/O: it checks the declaration lexically (the same canonical-path
        /// rule surfaces get, plus "relative, so it names a place inside the
        /// run's tree") and carries it verbatim, so the choice is part of the
        /// run's record rather than ambient host state. Resolving it against a
        /// real filesystem — existence, symlinks, containment — belongs to the
        /// worker that spawns the CLI, the one process that shares that
        /// filesystem. Absent means the run root itself.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        cwd: Option<String>,
        /// How the attached worker invokes the declared CLI. The kernel does
        /// not implement either transport; it journals and dispatches the
        /// choice so the worker can honor it deterministically.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        transport: Option<AgentTransport>,
        #[serde(default)]
        recovery_mode: RecoveryMode,
        /// Declared mutable surfaces (RFC Appendix A rule 1) — names only.
        /// Revision/offset *pins* are runtime facts journaled per attempt
        /// (Appendix A rule 2), never spec fields.
        #[serde(default, skip_serializing_if = "AgentSurfaces::is_empty")]
        surfaces: AgentSurfaces,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        permissions: Option<PermissionsSpec>,
    },
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(untagged)]
pub enum CommandSpec {
    Shell(String),
    Argv(Vec<String>),
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum StepType {
    Deterministic,
    Llm,
    Agent,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum AgentTransport {
    Direct,
    Relay,
}

#[derive(Debug, Clone, Copy, Default, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum RecoveryMode {
    #[default]
    Reset,
    Inspect,
    Manual,
}

/// Declared state surfaces for an agent step (RFC Appendix A rule 1):
/// workspace mounts/worktrees, writable streams, and external writeback paths.
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct AgentSurfaces {
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub workspace: Vec<WorkspaceSurface>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub streams: Vec<StreamSurface>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub external: Vec<String>,
}

impl AgentSurfaces {
    pub fn is_empty(&self) -> bool {
        self.workspace.is_empty() && self.streams.is_empty() && self.external.is_empty()
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct WorkspaceSurface {
    pub surface: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct StreamSurface {
    pub stream: String,
}

/// Permission model for an agent step (gate 8). Carried as data in gate 1;
/// enforcement lands with agent dispatch.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct PermissionsSpec {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub file_globs: Option<Vec<String>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub network_allowlist: Option<Vec<String>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub access_preset: Option<AccessPreset>,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum AccessPreset {
    Readonly,
    Readwrite,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct TriggerSpec {
    pub id: String,
    pub executor: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub event_type: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub pattern: Option<Value>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub dedupe_key_template: Option<String>,
    /// Silence budget for this subscription (RFC-0001 gate 2, "Native's
    /// silent-death" lesson). When set, the kernel's liveness sweep flags
    /// the subscription stale if no matching event arrives within this many
    /// milliseconds. Absent means the flow author has not declared a
    /// budget; the engine applies its default (see `submit_event`).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub stale_after_ms: Option<u64>,
}

impl TriggerSpec {
    /// Resolve the effective silence budget for this trigger, returning
    /// the value as `i64` (the type the liveness sweep stores). Applies
    /// the engine default when the spec omits `stale_after_ms`, and
    /// bounds-checks in one place so `spec::validate` and
    /// `engine::submit_event` cannot drift.
    ///
    /// Returns `Err(u64)` — the offending value — when the requested
    /// budget cannot fit in `i64`; callers turn that into their own
    /// domain error (`SpecError::TriggerStaleAfterMsOutOfRange` at parse
    /// time, an anyhow at submit time).
    pub fn effective_stale_after_ms(&self, default_ms: u64) -> Result<i64, u64> {
        let ms = self.stale_after_ms.unwrap_or(default_ms);
        i64::try_from(ms).map_err(|_| ms)
    }
}

/// Budget envelope: tokens are integers; money is a decimal string, never a
/// float (kernel DESIGN.md §1).
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct BudgetSpec {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub pricing: Option<BudgetPricing>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub prior_spend: Option<PriorSpend>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub max_tokens: Option<u64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub max_wallclock_ms: Option<u64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub window: Option<BudgetWindow>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub max_tokens_in: Option<u64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub max_tokens_out: Option<u64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub max_dollars: Option<String>,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum BudgetWindow {
    Day,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum BudgetPricing {
    Frozen,
}

/// Accounting imported into a run that continues an earlier one. The authored
/// TypeScript executor lowers each step to its own kernel run and carries the
/// previous run's totals here, so this shape must express everything a carried
/// [`Budget`](crate::entry::Budget) expresses — see the `From` impl below.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct PriorSpend {
    pub tokens_in: u64,
    pub tokens_out: u64,
    /// Metered dollars only; a lower bound when `dollars_unmetered` is set.
    pub dollars: String,
    pub wallclock_ms: u64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub day: Option<i64>,
    /// At least one carried charge spent tokens of unknown dollar cost, so
    /// `dollars` above is a lower bound rather than a measured total. This
    /// keeps `Budget::dollars_unmetered` sticky across the child-run boundary:
    /// without it an unpriced step followed by another step carried its tokens
    /// and a metered zero, and the later run's total looked fully measured.
    ///
    /// Compatibility is deliberate in both directions, and `PriorSpend` keeps
    /// `deny_unknown_fields`:
    ///
    /// - A **newer kernel** reading a payload **without** the key defaults it
    ///   to `false` — the pre-existing meaning — so an older SDK keeps working
    ///   unchanged.
    /// - An **older kernel** reading a payload **with** the key refuses the
    ///   spec as malformed. Because the key is omitted when false, that can
    ///   only happen for a flow that actually carried unknown cost, which is
    ///   exactly the case where silently dropping it would under-report the
    ///   total. A loud refusal is the fail-closed answer (AGENTS.md rule 4);
    ///   accepting and ignoring the key would be the fail-open bug this field
    ///   exists to prevent.
    #[serde(default, skip_serializing_if = "is_false")]
    pub dollars_unmetered: bool,
}

impl From<&PriorSpend> for crate::entry::Budget {
    /// Lossless by construction: every `Budget` field is named here and there
    /// is no `..Default::default()`, so a future accounting field fails to
    /// compile at this boundary instead of silently importing as zero/false.
    fn from(prior: &PriorSpend) -> Self {
        crate::entry::Budget {
            tokens_in: prior.tokens_in,
            tokens_out: prior.tokens_out,
            dollars: prior.dollars.clone(),
            dollars_unmetered: prior.dollars_unmetered,
        }
    }
}

fn is_false(value: &bool) -> bool {
    !*value
}

/// v0 verification gates (kernel DESIGN.md §4): `exit_code == 0` is implicit
/// for deterministic steps; these two are optional and combinable. Unknown
/// keys are a parse error — verification is control flow, and a dropped gate
/// is a fail-open bug, not a default.
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct VerificationSpec {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub output_contains: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub json_schema: Option<Value>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct RetryPolicy {
    #[serde(default = "default_initial_backoff_ms")]
    pub initial_backoff_ms: u64,
    #[serde(default = "default_max_backoff_ms")]
    pub max_backoff_ms: u64,
    #[serde(default = "default_multiplier")]
    pub multiplier: u32,
    #[serde(default = "default_jitter_percent")]
    pub jitter_percent: u8,
}

impl Default for RetryPolicy {
    fn default() -> Self {
        Self {
            initial_backoff_ms: default_initial_backoff_ms(),
            max_backoff_ms: default_max_backoff_ms(),
            multiplier: default_multiplier(),
            jitter_percent: default_jitter_percent(),
        }
    }
}

impl RetryPolicy {
    fn validate(&self, step_id: &str) -> Result<(), SpecError> {
        if self.multiplier == 0 || self.jitter_percent > 100 {
            return Err(SpecError::InvalidRetry(step_id.to_owned()));
        }
        if self.max_backoff_ms < self.initial_backoff_ms {
            return Err(SpecError::InvalidRetry(step_id.to_owned()));
        }
        Ok(())
    }
}

fn default_initial_backoff_ms() -> u64 {
    100
}

fn default_max_backoff_ms() -> u64 {
    60_000
}

fn default_multiplier() -> u32 {
    2
}

fn default_jitter_percent() -> u8 {
    20
}

#[derive(Debug, Error, PartialEq, Eq)]
pub enum SpecError {
    #[error("step {step} has invalid memory: {detail}")]
    InvalidMemory { step: String, detail: String },
    #[error("unsupported run spec version {0} (this kernel reads {SPEC_VERSION})")]
    UnsupportedVersion(String),
    #[error("unknown field \"{field}\" at {at} — refusing to guess (fail closed)")]
    UnknownField { at: String, field: String },
    #[error("malformed run spec: {0}")]
    Malformed(String),
    #[error("flow cli cannot be empty")]
    EmptyCli,
    #[error("trigger {0} must declare a non-empty id and executor")]
    InvalidTrigger(String),
    #[error(
        "trigger {id} declared stale_after_ms={ms} which does not fit in i64 (~292M years); the liveness sweep cannot represent that budget"
    )]
    TriggerStaleAfterMsOutOfRange { id: String, ms: u64 },
    #[error("duplicate trigger id: {0}")]
    DuplicateTrigger(String),
    #[error("step id cannot be empty")]
    EmptyStepId,
    #[error("step {0} cli cannot be empty")]
    EmptyStepCli(String),
    #[error(
        "agent step {step} declares working directory {cwd:?}, which is not a run-root-relative path (no absolute paths, empty components, \".\" or \"..\")"
    )]
    InvalidAgentCwd { step: String, cwd: String },
    #[error("agent step {step} declares non-canonical external surface {path:?}")]
    InvalidExternalSurface { step: String, path: String },
    #[error("agent step {step} declares non-canonical workspace surface {surface:?}")]
    InvalidWorkspaceSurface { step: String, surface: String },
    #[error("duplicate step id: {0}")]
    DuplicateStep(String),
    #[error("step {0} must allow at least one iteration")]
    ZeroIterations(String),
    #[error("step {step} declares an invalid JSON Schema: {detail}")]
    InvalidJsonSchema { step: String, detail: String },
    #[error("step {step} depends on unknown step {dependency}")]
    UnknownDependency { step: String, dependency: String },
    #[error("dependency cycle includes step {0}")]
    DependencyCycle(String),
    #[error("invalid retry policy for step {0}")]
    InvalidRetry(String),
}

#[cfg(test)]
mod tests;
