use std::collections::BTreeMap;

use serde::{Deserialize, Serialize};
use serde_json::Value;

use crate::spec::{RecoveryMode, StepType};

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum EntryType {
    #[serde(rename = "run.spawned")]
    RunSpawned,
    #[serde(rename = "run.cancel.requested")]
    RunCancelRequested,
    #[serde(rename = "event.received")]
    EventReceived,
    #[serde(rename = "subscription.registered")]
    SubscriptionRegistered,
    #[serde(rename = "subscription.matched")]
    SubscriptionMatched,
    /// The sweep noticed a subscription's `last_event_at_ms` fell farther
    /// behind wall-clock than its declared `stale_after_ms`. Emitted at
    /// least once per silence — a re-arrival re-arms the latch, and a
    /// crash between journal-append and latch can cause re-emission of
    /// the same silence with a different `detected_at_ms`. The RFC's
    /// "Native silent-death" answer at the journal level.
    #[serde(rename = "subscription.stale")]
    SubscriptionStale,
    /// The cell has recorded the exact subscription request but Cloud has not
    /// yet fenced its provider binding.  A prepared record is intentionally
    /// invisible to the authored body and never accepts frames.
    #[serde(rename = "subscription.prepared")]
    SubscriptionPrepared,
    /// A body-local event cursor. This is distinct from trigger-plane
    /// `subscription.registered`: it never creates a run.
    #[serde(rename = "subscription.opened")]
    SubscriptionOpened,
    #[serde(rename = "subscription.closed")]
    SubscriptionClosed,
    /// Local durable mirror of the router's `closing: overflow` fence. Cloud
    /// owns its provider binding; recovery uses this journal fact to finish
    /// the already-submitted close without ever reopening the cursor.
    #[serde(rename = "subscription.overflow.fenced")]
    SubscriptionOverflowFenced,
    /// The body has observed a normal activity wake. This advances only that
    /// cursor's unread boundary; it is not a provider acknowledgement.
    #[serde(rename = "subscription.acknowledged")]
    SubscriptionAcknowledged,
    #[serde(rename = "step.routed")]
    StepRouted,
    #[serde(rename = "step.attempt.started")]
    StepAttemptStarted,
    #[serde(rename = "step.completed")]
    StepCompleted,
    #[serde(rename = "wait.event")]
    WaitEvent,
    #[serde(rename = "wait.human")]
    WaitHuman,
    #[serde(rename = "sleep.until")]
    SleepUntil,
    #[serde(rename = "wait.completed")]
    WaitCompleted,
    #[serde(rename = "stream.appended")]
    StreamAppended,
    #[serde(rename = "memory.injected")]
    MemoryInjected,
    #[serde(rename = "channel.appended")]
    ChannelAppended,
    #[serde(rename = "channel.delivered")]
    ChannelDelivered,
    #[serde(rename = "channel.acknowledged")]
    ChannelAcknowledged,
    #[serde(rename = "effect.recorded")]
    EffectRecorded,
    #[serde(rename = "effect.confirmed")]
    EffectConfirmed,
    #[serde(rename = "epoch.summary")]
    EpochSummary,
    #[serde(rename = "segment.closed")]
    SegmentClosed,
    #[serde(rename = "run.completed")]
    RunCompleted,
}

impl EntryType {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::RunSpawned => "run.spawned",
            Self::RunCancelRequested => "run.cancel.requested",
            Self::EventReceived => "event.received",
            Self::SubscriptionRegistered => "subscription.registered",
            Self::SubscriptionMatched => "subscription.matched",
            Self::SubscriptionStale => "subscription.stale",
            Self::SubscriptionPrepared => "subscription.prepared",
            Self::SubscriptionOpened => "subscription.opened",
            Self::SubscriptionClosed => "subscription.closed",
            Self::SubscriptionOverflowFenced => "subscription.overflow.fenced",
            Self::SubscriptionAcknowledged => "subscription.acknowledged",
            Self::StepRouted => "step.routed",
            Self::StepAttemptStarted => "step.attempt.started",
            Self::StepCompleted => "step.completed",
            Self::WaitEvent => "wait.event",
            Self::WaitHuman => "wait.human",
            Self::SleepUntil => "sleep.until",
            Self::WaitCompleted => "wait.completed",
            Self::StreamAppended => "stream.appended",
            Self::MemoryInjected => "memory.injected",
            Self::ChannelAppended => "channel.appended",
            Self::ChannelDelivered => "channel.delivered",
            Self::ChannelAcknowledged => "channel.acknowledged",
            Self::EffectRecorded => "effect.recorded",
            Self::EffectConfirmed => "effect.confirmed",
            Self::EpochSummary => "epoch.summary",
            Self::SegmentClosed => "segment.closed",
            Self::RunCompleted => "run.completed",
        }
    }

    pub fn parse(value: &str) -> Option<Self> {
        Some(match value {
            "run.spawned" => Self::RunSpawned,
            "run.cancel.requested" => Self::RunCancelRequested,
            "event.received" => Self::EventReceived,
            "subscription.registered" => Self::SubscriptionRegistered,
            "subscription.matched" => Self::SubscriptionMatched,
            "subscription.stale" => Self::SubscriptionStale,
            "subscription.prepared" => Self::SubscriptionPrepared,
            "subscription.opened" => Self::SubscriptionOpened,
            "subscription.closed" => Self::SubscriptionClosed,
            "subscription.overflow.fenced" => Self::SubscriptionOverflowFenced,
            "subscription.acknowledged" => Self::SubscriptionAcknowledged,
            "step.routed" => Self::StepRouted,
            "step.attempt.started" => Self::StepAttemptStarted,
            "step.completed" => Self::StepCompleted,
            "wait.event" => Self::WaitEvent,
            "wait.human" => Self::WaitHuman,
            "sleep.until" => Self::SleepUntil,
            "wait.completed" => Self::WaitCompleted,
            "stream.appended" => Self::StreamAppended,
            "memory.injected" => Self::MemoryInjected,
            "channel.appended" => Self::ChannelAppended,
            "channel.delivered" => Self::ChannelDelivered,
            "channel.acknowledged" => Self::ChannelAcknowledged,
            "effect.recorded" => Self::EffectRecorded,
            "effect.confirmed" => Self::EffectConfirmed,
            "epoch.summary" => Self::EpochSummary,
            "segment.closed" => Self::SegmentClosed,
            "run.completed" => Self::RunCompleted,
            _ => return None,
        })
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct JournalEntry {
    /// Zero before persistence; the journal assigns a positive sequence.
    pub seq: i64,
    pub segment_id: i64,
    pub entry_type: EntryType,
    pub run_id: String,
    pub step_id: Option<String>,
    pub attempt: Option<u32>,
    pub at_ms: i64,
    pub payload: Value,
}

pub fn journal_dollars(value: &str) -> Result<serde_json::Number, serde_json::Error> {
    let (whole, fraction) = value.split_once('.').unwrap_or((value, ""));
    let whole = whole.trim_start_matches('0');
    let whole = if whole.is_empty() { "0" } else { whole };
    let normalized = if fraction.is_empty() {
        whole.to_owned()
    } else {
        format!("{whole}.{fraction}")
    };
    normalized.parse()
}

impl JournalEntry {
    pub fn new<T: Serialize>(
        entry_type: EntryType,
        run_id: impl Into<String>,
        step_id: Option<String>,
        attempt: Option<u32>,
        at_ms: i64,
        payload: T,
    ) -> Self {
        let mut payload = serde_json::to_value(payload).expect("journal payload must serialize");
        if entry_type == EntryType::StepCompleted {
            let budget: Budget =
                serde_json::from_value(payload["budget"].clone()).unwrap_or_default();
            payload["spend"] = serde_json::json!({
                "tokens_input": budget.tokens_in, "tokens_output": budget.tokens_out,
                "dollars": journal_dollars(&budget.dollars).expect("valid journal dollars"),
                "wallclock_ms": 0,
            });
            if budget.dollars_unmetered {
                payload["spend"]["dollars_unmetered"] = serde_json::Value::Bool(true);
            }
        }
        Self {
            seq: 0,
            segment_id: 0,
            entry_type,
            run_id: run_id.into(),
            step_id,
            attempt,
            at_ms,
            payload,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct RunSpawnedPayload {
    pub spec: Value,
    pub spec_hash: String,
    pub parent_run_id: Option<String>,
    pub journal_version: u32,
    pub created_by: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct RunCancelRequestedPayload {
    pub requested_by: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct AttemptStartedPayload {
    pub step_type: StepType,
    pub idempotency_key: String,
    pub lease_id: String,
    pub lease_deadline_ms: i64,
    pub executor: String,
    pub recovery_mode: Option<RecoveryMode>,
    pub pins: Pins,
    pub max_iterations: u32,
}

/// Runtime pins journaled per attempt (RFC Appendix A rules 2 and 6): the
/// revision id of each declared workspace surface and the offset of each
/// declared stream. Pins are journal facts, never spec fields — the spec only
/// *declares* surfaces (rule 1).
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq, Eq)]
pub struct Pins {
    #[serde(default)]
    pub workspace: Vec<WorkspacePin>,
    #[serde(default)]
    pub streams: Vec<StreamPin>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct WorkspacePin {
    pub surface: String,
    pub revision_id: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct StreamPin {
    pub stream: String,
    pub read_offset: u64,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum CompletionReason {
    Success,
    VerificationFailed,
    RetriesExhausted,
    LeaseExpired,
    Crashed,
    Timeout,
    WorkerError,
    BudgetExceeded,
    Canceled,
}

impl CompletionReason {
    /// The label journaled beside a `completionReason` field, and the only
    /// spelling any journal record renders. The match is deliberately
    /// wildcard-free: a new variant is a compile error here until given a
    /// label, so this boundary fails closed at build time rather than at
    /// runtime.
    ///
    /// These strings must stay identical to the `rename_all = "snake_case"`
    /// spellings serde emits, which `every_journal_label_matches_serialized`
    /// pins. The enum owns its label; nothing else does. #197 removed the
    /// duplicate table in `machine.rs` that made drift silently possible.
    pub fn journal_label(&self) -> &'static str {
        match self {
            Self::Success => "success",
            Self::VerificationFailed => "verification_failed",
            Self::RetriesExhausted => "retries_exhausted",
            Self::LeaseExpired => "lease_expired",
            Self::Crashed => "crashed",
            Self::Timeout => "timeout",
            Self::WorkerError => "worker_error",
            Self::BudgetExceeded => "budget_exceeded",
            Self::Canceled => "canceled",
        }
    }

    /// The canonical list of every variant, hand-maintained beside the enum
    /// so tests can iterate without pulling in `strum`. A new variant added
    /// above forces this list to be updated (via the pinning test); adding
    /// only there would be caught at the next `journal_label` call site.
    pub const ALL: &'static [Self] = &[
        Self::Success,
        Self::VerificationFailed,
        Self::RetriesExhausted,
        Self::LeaseExpired,
        Self::Crashed,
        Self::Timeout,
        Self::WorkerError,
        Self::BudgetExceeded,
        Self::Canceled,
    ];
}

#[cfg(test)]
mod completion_reason_tests {
    use super::CompletionReason;

    /// Owner-side drift check: journaled label must match serde output for
    /// every variant. The list lives on the enum's own `ALL` const, so
    /// `machine.rs` no longer has a second owner to keep in sync (#197).
    #[test]
    fn every_journal_label_matches_serialized() {
        for reason in CompletionReason::ALL {
            let serialized = serde_json::to_value(reason).unwrap();
            assert_eq!(
                serialized.as_str().expect("a string spelling"),
                reason.journal_label(),
                "journal label drifted from the serialized form for {reason:?}"
            );
        }
    }

    /// `ALL` must actually enumerate every variant. Serde's snake_case output
    /// gives us that check for free: if a new variant existed but was missing
    /// from `ALL`, this test's iteration would not observe it, which is why
    /// the pinning above is the load-bearing guard.
    ///
    /// The redundancy is deliberate: this test asserts `ALL` covers every
    /// label the enum's own labeler produces. Together with the compile-time
    /// exhaustiveness of `journal_label`, missing a variant becomes: (a) a
    /// build error if you skip `journal_label`, or (b) a test failure if you
    /// skip `ALL`.
    #[test]
    fn all_covers_every_serialized_label() {
        let labels: std::collections::HashSet<&str> =
            CompletionReason::ALL.iter().map(|r| r.journal_label()).collect();
        assert_eq!(
            labels.len(),
            CompletionReason::ALL.len(),
            "ALL must list each variant exactly once"
        );
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum Disposition {
    StepDone,
    Retry,
    Park,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct StepCompletedPayload {
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub human_intervention: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub step_spec_hash: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub input_hash: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub reused_from: Option<crate::memoization::ReusedFrom>,
    #[serde(rename = "completionReason")]
    pub completion_reason: CompletionReason,
    pub disposition: Disposition,
    pub output: Value,
    pub verification: Option<VerificationRecord>,
    pub end_pins: Option<Pins>,
    #[serde(default)]
    pub effects: Vec<EffectRef>,
    /// Worker-supplied execution context for `inspect` recovery. This is
    /// evidence from the failed attempt, not a command to replay it. The
    /// protocol boundary that admits it (`step.complete`) caps its size; the
    /// journal itself stores whatever was admitted.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub trajectory_tail: Option<Value>,
    #[serde(default)]
    pub budget: Budget,
    /// What the step actually cost, as reported by the CLI or estimated from
    /// its full token usage. Display only: it is never folded into the run's
    /// budget, so `budget` alone decides `maxDollars`. Absent when unknown.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub reported_cost: Option<ReportedCost>,
    pub completed_by: String,
    pub next_attempt_at_ms: Option<i64>,
}

/// A step attempt's actual cost, kept apart from the metered `Budget`.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ReportedCost {
    /// Non-negative decimal string, like `Budget::dollars`.
    pub dollars: String,
    pub source: ReportedCostSource,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ReportedCostSource {
    /// The agent CLI's own reported total (e.g. Claude `total_cost_usd`).
    Cli,
    /// Estimated from the step's full token usage at a frozen price.
    Priced,
    /// No model ran: an internal effect worker (provider helper, plugin, MCP)
    /// completed the step. `dollars` is zero.
    NoModel,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct VerificationRecord {
    pub gate: String,
    pub verdict: VerificationVerdict,
    pub detail: String,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum VerificationVerdict {
    Pass,
    Fail,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct EffectRef {
    pub surface_path: String,
    pub idempotency_key: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct Budget {
    #[serde(default)]
    pub tokens_in: u64,
    #[serde(default)]
    pub tokens_out: u64,
    /// Metered dollars: the priced cost of this charge. When
    /// `dollars_unmetered` is set this is a lower bound, not a total.
    #[serde(default = "zero_dollars")]
    pub dollars: String,
    /// The charge spent tokens whose dollar cost is unknown (an unpriced or
    /// undeclared model). On a running total it is sticky: at least one charge
    /// was unmetered. Dollar ceilings compare only metered `dollars`; token
    /// ceilings still count every token. Omitted when false, so journals
    /// without unmetered spend keep their exact bytes, and readers that predate
    /// the key ignore it.
    #[serde(default, skip_serializing_if = "is_false")]
    pub dollars_unmetered: bool,
}

impl Default for Budget {
    fn default() -> Self {
        Self {
            tokens_in: 0,
            tokens_out: 0,
            dollars: zero_dollars(),
            dollars_unmetered: false,
        }
    }
}

fn is_false(value: &bool) -> bool {
    !*value
}

fn zero_dollars() -> String {
    "0".to_owned()
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct SleepUntilPayload {
    pub wait_id: String,
    pub wake_at_ms: i64,
    pub reason: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct WaitEventPayload {
    pub wait_id: String,
    pub event_key: String,
    pub timeout_at_ms: Option<i64>,
    /// Body activities use a stream cursor; old exact-match event waits leave
    /// these additive fields absent.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub stream: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub from_offset: Option<u64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub settle_ms: Option<i64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub idle_at_ms: Option<i64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub deadline_at_ms: Option<i64>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct WaitHumanPayload {
    pub wait_id: String,
    pub prompt: String,
    pub requested_of: String,
    pub options: Option<Vec<String>>,
    pub timeout_at_ms: Option<i64>,
    pub diff_ref: Option<String>,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum WaitCompletionReason {
    EventReceived,
    HumanResponded,
    TimerFired,
    Timeout,
    Canceled,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct WaitCompletedPayload {
    pub wait_id: String,
    #[serde(rename = "completionReason")]
    pub completion_reason: WaitCompletionReason,
    pub result: Value,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct StreamAppendedPayload {
    pub stream: String,
    pub offset: u64,
    pub producer: String,
    pub message: Value,
    /// Provider delivery id for body-subscription frames. It is optional so
    /// existing generic streams retain their protocol shape.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub provider_delivery_id: Option<String>,
}

/// The kernel records the immutable, tenant-neutral part of an activity
/// opening. Cloud owns the provider installation/resource binding and fences
/// it before asking the cell to append this fact; `router_binding` is an opaque
/// receipt, never policy interpreted by the kernel.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct SubscriptionOpenedPayload {
    pub subscription_id: String,
    pub event_types: Vec<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub pattern: Option<Value>,
    pub stream: String,
    pub settle_ms: i64,
    pub idle_ms: i64,
    pub deadline_at_ms: i64,
    pub include_self: bool,
    #[serde(default)]
    pub ingress_offset: u64,
    #[serde(default)]
    pub router_binding: Value,
}

/// Immutable request handed to the Cloud router before it creates the
/// provider binding.  `subscription.opened` is appended only after Cloud
/// returns its fenced binding receipt and ingress offset.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct SubscriptionPreparedPayload {
    pub subscription_id: String,
    pub event_types: Vec<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub pattern: Option<Value>,
    pub stream: String,
    pub settle_ms: i64,
    pub idle_ms: i64,
    pub deadline_at_ms: i64,
    pub include_self: bool,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum SubscriptionCompletionReason {
    Closed,
    RunCompleted,
    Canceled,
    Deadline,
    Overflow,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct SubscriptionClosedPayload {
    pub subscription_id: String,
    #[serde(rename = "completionReason")]
    pub completion_reason: SubscriptionCompletionReason,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct SubscriptionOverflowFencedPayload {
    pub subscription_id: String,
    pub retained: u64,
    pub bytes: u64,
    pub from: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct SubscriptionAcknowledgedPayload {
    pub subscription_id: String,
    pub wait_id: String,
    /// Present only for an event wake; idle has no stream range to advance.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub next_offset: Option<u64>,
}

/// Appendix A rule 5. The record *elects* one attempt to perform the
/// writeback; this entry says the elected attempt performed it. Until it
/// exists the election is provisional, and a later attempt may reclaim it —
/// otherwise a worker that died between electing and calling the provider
/// would suppress an effect that never happened.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct EffectConfirmedPayload {
    pub surface_path: String,
    pub idempotency_key: String,
    pub agent_identity: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct EffectRecordedPayload {
    pub surface_path: String,
    pub idempotency_key: String,
    pub revision_before: String,
    pub revision_after: String,
    pub agent_identity: String,
    /// True when a *confirmed* election already covers this
    /// `(step_id, idempotency_key, surface_path)`: the writeback has provably
    /// happened, so this attempt must not call the provider. An election that
    /// was never confirmed does not dedupe — this attempt reclaims it.
    pub deduped: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct EpochSummaryPayload {
    pub epoch: i64,
    pub prev_segment_id: i64,
    pub journal_version: u32,
    #[serde(default)]
    pub steps_done: BTreeMap<String, StepDoneSummary>,
    #[serde(default)]
    pub steps_open: BTreeMap<String, StepOpenSummary>,
    #[serde(default)]
    pub open_waits: BTreeMap<String, Value>,
    #[serde(default)]
    pub stream_state: BTreeMap<String, StreamSummary>,
    #[serde(default)]
    pub pinned_revisions: BTreeMap<String, String>,
    #[serde(default)]
    pub budget_spent: Budget,
    /// Accepted packs are retained without charging them again at the epoch boundary.
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub memory: BTreeMap<String, crate::memory::MemoryInjectedPayload>,
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub routing: BTreeMap<String, crate::RoutingDecision>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct StepDoneSummary {
    #[serde(rename = "completionReason")]
    pub completion_reason: CompletionReason,
    pub output: Value,
}

/// An unfinished step carried across an epoch boundary. Each state uses its
/// own field: `running` carries the lease deadline and idempotency key,
/// `backoff` carries the wake time — no field is overloaded across states.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct StepOpenSummary {
    pub attempt: u32,
    pub state: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub lease_deadline_ms: Option<i64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub wake_at_ms: Option<i64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub idempotency_key: Option<String>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq, Eq)]
pub struct StreamSummary {
    pub length: u64,
    #[serde(default)]
    pub consumers: BTreeMap<String, u64>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct SegmentClosedPayload {
    pub next_segment_id: i64,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum RunCompletionReason {
    Success,
    StepFailed,
    Canceled,
    BudgetExceeded,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct RunCompletedPayload {
    #[serde(rename = "completionReason")]
    pub completion_reason: RunCompletionReason,
    pub failed_step_id: Option<String>,
    pub budget_total: Budget,
}

#[cfg(test)]
mod reported_cost_tests {
    use super::*;

    #[test]
    fn step_completed_without_reported_cost_round_trips_unchanged() {
        // A journal written before `reported_cost` existed must still decode,
        // and a payload without one must serialize exactly as it always did.
        let legacy = serde_json::json!({
            "completionReason": "success", "disposition": "step_done", "output": null,
            "verification": null, "end_pins": null, "effects": [],
            "budget": {"tokens_in": 1, "tokens_out": 2, "dollars": "0.1"},
            "completed_by": "w", "next_attempt_at_ms": null
        });
        let payload: StepCompletedPayload = serde_json::from_value(legacy.clone()).unwrap();
        assert_eq!(payload.reported_cost, None);
        let reserialized = serde_json::to_value(&payload).unwrap();
        assert!(reserialized.get("reported_cost").is_none());
        assert_eq!(reserialized["budget"], legacy["budget"]);
    }
}
