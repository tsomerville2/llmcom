use serde_json::json;

use super::*;
use crate::{Clock, SimClock, entry::AttemptStartedPayload, state::RunState};

fn retrying_spec() -> crate::RunSpec {
    serde_json::from_value(json!({
        "steps": [{
            "id": "hello",
            "type": "deterministic",
            "command": "printf hello",
            "max_iterations": 2,
            "retry": {"initial_backoff_ms": 100, "max_backoff_ms": 100, "multiplier": 2, "jitter_percent": 0},
            "verification": {"output_contains": "hello"}
        }]
    }))
    .unwrap()
}

#[test]
fn machine_starts_runnable_step_with_stable_effect_key() {
    let state = RunState::fold("run", retrying_spec(), &[]).unwrap();
    let actions = next_actions(&state, 10);
    let Action::Append(started) = &actions[0] else {
        panic!("first action must persist the lease")
    };
    let payload: AttemptStartedPayload = serde_json::from_value(started.payload.clone()).unwrap();
    assert_eq!(payload.idempotency_key, idempotency_key("run", "hello"));
    assert!(matches!(
        actions[1],
        Action::ExecDeterministic { attempt: 1, .. }
    ));
}

#[test]
fn verification_failure_schedules_a_durable_retry() {
    let spec = retrying_spec();
    let actions = completion_actions(
        "run",
        &spec.steps[0],
        1,
        0,
        AttemptResult::successful(json!({"exit_code": 0, "stdout_tail": "wrong"}), "kernel"),
        1_000,
    );
    let Action::Append(completed) = &actions[0] else {
        panic!()
    };
    let payload: StepCompletedPayload = serde_json::from_value(completed.payload.clone()).unwrap();
    assert_eq!(
        payload.completion_reason,
        CompletionReason::VerificationFailed
    );
    assert_eq!(payload.disposition, Disposition::Retry);
    assert_eq!(payload.next_attempt_at_ms, Some(1_100));
    assert!(matches!(
        actions[1],
        Action::Append(JournalEntry {
            entry_type: EntryType::SleepUntil,
            ..
        })
    ));
}

#[test]
fn failed_deterministic_completion_preserves_exit_code_and_stderr(
) {
    // #292: failed attempts used to journal `output: null`, so the CLI
    // could not surface the actual exit code or stderr excerpt. Both the
    // retry branch and the terminal branch must now preserve the captured
    // shape verbatim from `AttemptResult.output`.
    let spec = retrying_spec();
    let mut retryable_step = spec.steps[0].clone();
    retryable_step.max_iterations = 2;
    let retry_output = json!({
        "exit_code": 7,
        "stdout_tail": "",
        "stderr_tail": "shakedown intentional failure",
    });
    let retry_actions = completion_actions(
        "run",
        &retryable_step,
        1,
        0,
        AttemptResult::successful(retry_output.clone(), "kernel"),
        1_000,
    );
    let Action::Append(retry_completed) = &retry_actions[0] else {
        panic!("failed attempt must append a typed completion");
    };
    let retry_payload: StepCompletedPayload =
        serde_json::from_value(retry_completed.payload.clone())
            .expect("failed retry completion must deserialize");
    assert_eq!(retry_payload.disposition, Disposition::Retry);
    assert_eq!(
        retry_payload.output, retry_output,
        "retry path drops the captured exit_code/stderr_tail"
    );

    let mut terminal_step = spec.steps[0].clone();
    terminal_step.max_iterations = 1;
    let terminal_output = json!({
        "exit_code": 7,
        "stdout_tail": "",
        "stderr_tail": "final attempt failed",
    });
    let terminal_actions = completion_actions(
        "run",
        &terminal_step,
        1,
        0,
        AttemptResult::successful(terminal_output.clone(), "kernel"),
        2_000,
    );
    let Action::Append(terminal_completed) = &terminal_actions[0] else {
        panic!("terminal failure must append a typed completion");
    };
    let terminal_payload: StepCompletedPayload =
        serde_json::from_value(terminal_completed.payload.clone())
            .expect("terminal failure completion must deserialize");
    assert_eq!(terminal_payload.disposition, Disposition::StepDone);
    assert_eq!(
        terminal_payload.completion_reason,
        CompletionReason::RetriesExhausted
    );
    assert_eq!(
        terminal_payload.output, terminal_output,
        "terminal failure path drops the captured exit_code/stderr_tail"
    );
}

#[test]
fn every_failed_run_terminates_with_declared_completion_reasons() {
    let failure_reasons = [
        CompletionReason::VerificationFailed,
        CompletionReason::RetriesExhausted,
        CompletionReason::LeaseExpired,
        CompletionReason::Crashed,
        CompletionReason::Timeout,
        CompletionReason::WorkerError,
        CompletionReason::BudgetExceeded,
        CompletionReason::Canceled,
    ];

    for reason in failure_reasons {
        let spec = retrying_spec();
        let mut step = spec.steps[0].clone();
        step.max_iterations = 1;
        let mut result = AttemptResult::successful(Value::Null, "test");
        result.failure_reason = Some(reason);
        result.failure_detail = Some("declared test failure".to_owned());
        let Action::Append(completed) =
            completion_actions("run", &step, 1, 0, result, 10).remove(0)
        else {
            panic!("failed attempt must append a typed completion");
        };
        let payload: StepCompletedPayload = serde_json::from_value(completed.payload.clone())
            .expect("failed completion must deserialize to the closed payload");
        assert_eq!(payload.completion_reason, reason);

        let mut failed_spec = spec;
        failed_spec.steps[0] = step;
        let state = RunState::fold("run", failed_spec, &[completed]).unwrap();
        let Action::Append(run_completed) = next_actions(&state, 20).remove(0) else {
            panic!("failed step must terminate the run in its journal");
        };
        let terminal: RunCompletedPayload = serde_json::from_value(run_completed.payload)
            .expect("run completion reason must be a declared enum value");
        assert_eq!(terminal.completion_reason, RunCompletionReason::StepFailed);
    }
}

#[test]
fn successful_memo_is_never_scheduled_again() {
    let spec = retrying_spec();
    let Action::Append(completed) = completion_actions(
        "run",
        &spec.steps[0],
        1,
        0,
        AttemptResult::successful(json!({"exit_code": 0, "stdout_tail": "hello"}), "kernel"),
        1_000,
    )
    .remove(0) else {
        panic!()
    };
    let state = RunState::fold("run", spec, &[completed]).unwrap();
    let actions = next_actions(&state, 2_000);
    assert!(matches!(
        actions[0],
        Action::Append(JournalEntry {
            entry_type: EntryType::RunCompleted,
            ..
        })
    ));
    assert!(
        !actions
            .iter()
            .any(|action| matches!(action, Action::ExecDeterministic { .. }))
    );
}

#[test]
fn cancel_request_closes_the_active_lease_before_the_terminal_fact() {
    let clock = SimClock::new(10);
    let spec = crate::RunSpec::parse(&json!({
        "steps": [{"id": "model", "type": "llm", "prompt": "answer"}]
    }))
    .unwrap();
    let fresh = RunState::fold("run", spec.clone(), &[]).unwrap();
    let Action::Append(started) = next_actions(&fresh, clock.now_ms()).remove(0) else {
        panic!("the attempt lease must be durable");
    };
    let running = RunState::fold("run", spec.clone(), std::slice::from_ref(&started)).unwrap();
    clock.advance(10);
    let Action::Append(requested) =
        request_cancel_action(&running, "operator", clock.now_ms()).unwrap()
    else {
        panic!("cancel must first persist its request");
    };
    assert_eq!(requested.entry_type, EntryType::RunCancelRequested);

    let canceling = RunState::fold("run", spec, &[started, requested]).unwrap();
    clock.advance(10);
    let actions = next_actions(&canceling, clock.now_ms());
    let Action::Append(closed) = &actions[0] else {
        panic!("the active attempt must be closed first");
    };
    let closed: StepCompletedPayload = serde_json::from_value(closed.payload.clone()).unwrap();
    assert_eq!(closed.completion_reason, CompletionReason::Canceled);
    assert_eq!(closed.disposition, Disposition::StepDone);
    let Action::Append(terminal) = &actions[1] else {
        panic!("the run fact must follow the lease closure");
    };
    assert_eq!(terminal.entry_type, EntryType::RunCompleted);
    let terminal: RunCompletedPayload = serde_json::from_value(terminal.payload.clone()).unwrap();
    assert_eq!(terminal.completion_reason, RunCompletionReason::Canceled);
}

#[test]
fn repeated_cancel_request_is_idempotent() {
    let spec = retrying_spec();
    let state = RunState::fold("run", spec.clone(), &[]).unwrap();
    let Action::Append(requested) = request_cancel_action(&state, "operator", 10).unwrap() else {
        panic!();
    };
    let canceling = RunState::fold("run", spec.clone(), std::slice::from_ref(&requested)).unwrap();
    assert!(request_cancel_action(&canceling, "operator", 11).is_none());
    let terminal_entries = next_actions(&canceling, 12)
        .into_iter()
        .filter_map(|action| match action {
            Action::Append(entry) => Some(entry),
            _ => None,
        })
        .collect::<Vec<_>>();
    let terminal = RunState::fold("run", spec, &[requested, terminal_entries[0].clone()]).unwrap();
    assert!(request_cancel_action(&terminal, "operator", 13).is_none());
}

#[test]
fn durable_cancel_request_outranks_crash_recovery() {
    let clock = SimClock::new(10);
    let spec = crate::RunSpec::parse(&json!({
        "steps": [{"id": "model", "type": "llm", "prompt": "answer"}]
    }))
    .unwrap();
    let fresh = RunState::fold("run", spec.clone(), &[]).unwrap();
    let Action::Append(started) = next_actions(&fresh, clock.now_ms()).remove(0) else {
        panic!("the attempt lease must be durable");
    };
    let running = RunState::fold("run", spec.clone(), std::slice::from_ref(&started)).unwrap();
    clock.advance(10);
    let Action::Append(requested) =
        request_cancel_action(&running, "operator", clock.now_ms()).unwrap()
    else {
        panic!("the cancel request must be durable");
    };
    let canceling = RunState::fold("run", spec, &[started, requested]).unwrap();

    assert!(recovery_actions(&canceling, clock.now_ms()).is_empty());
    let Action::Append(closed) = &next_actions(&canceling, clock.now_ms())[0] else {
        panic!("cancellation must close the active lease");
    };
    let closed: StepCompletedPayload = serde_json::from_value(closed.payload.clone()).unwrap();
    assert_eq!(closed.completion_reason, CompletionReason::Canceled);
}

#[test]
fn crashed_attempt_does_not_consume_an_iteration() {
    // max_iterations 2: crash attempt 1, verification-fail the replacement
    // (attempt 2) — one semantic iteration must remain, so the step retries
    // instead of exhausting after a single semantic result.
    let spec = retrying_spec();
    let fresh = RunState::fold("run", spec.clone(), &[]).unwrap();
    let Action::Append(started) = next_actions(&fresh, 10).remove(0) else {
        panic!("attempt 1 must journal its lease");
    };

    // kill -9 between steps: attempt 1 is Running with no result. Recovery
    // must record the dead attempt as a retry, not a consumed iteration.
    let state = RunState::fold("run", spec.clone(), std::slice::from_ref(&started)).unwrap();
    assert_eq!(state.steps["hello"].semantic_executions, 0);
    let recovery = recovery_actions(&state, 1_000);
    let Action::Append(crashed) = &recovery[0] else {
        panic!("recovery must journal the dead attempt");
    };
    let crash_payload: StepCompletedPayload =
        serde_json::from_value(crashed.payload.clone()).unwrap();
    assert_eq!(crash_payload.disposition, Disposition::Retry);

    // The replacement (attempt 2) completes but fails verification. Raw
    // attempt number 2 == max_iterations, yet only one semantic execution has
    // happened — the step must still have an iteration remaining.
    let state = RunState::fold("run", spec.clone(), &[started, crashed.clone()]).unwrap();
    assert_eq!(state.steps["hello"].semantic_executions, 0);
    let actions = completion_actions(
        "run",
        &spec.steps[0],
        2,
        state.steps["hello"].semantic_executions,
        AttemptResult::successful(json!({"exit_code": 0, "stdout_tail": "wrong"}), "kernel"),
        2_000,
    );
    let Action::Append(completed) = &actions[0] else {
        panic!("completion must journal");
    };
    let payload: StepCompletedPayload = serde_json::from_value(completed.payload.clone()).unwrap();
    assert_eq!(
        payload.completion_reason,
        CompletionReason::VerificationFailed
    );
    assert_eq!(payload.disposition, Disposition::Retry);
    assert!(payload.next_attempt_at_ms.is_some());
}

#[test]
fn all_backing_off_steps_return_timers() {
    let spec = crate::RunSpec::parse(&json!({
        "steps": [
            {
                "id": "first",
                "type": "deterministic",
                "command": "false",
                "max_iterations": 2,
                "retry": {"initial_backoff_ms": 200, "max_backoff_ms": 200, "multiplier": 1, "jitter_percent": 0}
            },
            {
                "id": "second",
                "type": "deterministic",
                "command": "false",
                "max_iterations": 2,
                "retry": {"initial_backoff_ms": 100, "max_backoff_ms": 100, "multiplier": 1, "jitter_percent": 0}
            }
        ]
    }))
    .unwrap();
    let result = AttemptResult {
        human_intervention: false,
        output: Value::Null,
        budget: Budget::default(),
        completed_by: "kernel".to_owned(),
        end_pins: None,
        effects: Vec::new(),
        trajectory_tail: None,
        failure_reason: Some(CompletionReason::WorkerError),
        failure_detail: Some("stub rejection".to_owned()),
        reported_cost: None,
    };
    let mut entries = Vec::new();
    for step in &spec.steps {
        entries.extend(
            completion_actions("run", step, 1, 0, result.clone(), 1_000)
                .into_iter()
                .filter_map(|action| match action {
                    Action::Append(entry) => Some(entry),
                    _ => None,
                }),
        );
    }

    let state = RunState::fold("run", spec, &entries).unwrap();
    assert_eq!(
        next_actions(&state, 1_050),
        vec![
            Action::ArmTimer { at_ms: 1_100 },
            Action::ArmTimer { at_ms: 1_200 },
        ]
    );
}

fn agent_spec(mode: &str) -> crate::RunSpec {
    crate::RunSpec::parse(&json!({
        "steps": [{
            "id": "agent",
            "type": "agent",
            "instruction": "edit the workspace",
            "recovery_mode": mode,
            "max_iterations": 2,
            "retry": {"initial_backoff_ms": 0, "max_backoff_ms": 0, "multiplier": 1, "jitter_percent": 0},
            "surfaces": {"workspace": [{"surface": "repo"}]}
        }]
    }))
    .unwrap()
}

fn workspace_pins(revision_id: &str) -> Pins {
    Pins {
        workspace: vec![crate::WorkspacePin {
            surface: "repo".to_owned(),
            revision_id: revision_id.to_owned(),
        }],
        streams: vec![],
    }
}

fn started_agent(spec: &crate::RunSpec, pins: Pins) -> JournalEntry {
    let state = RunState::fold("run", spec.clone(), &[]).unwrap();
    let Action::Append(mut started) = next_actions(&state, 10).remove(0) else {
        panic!("agent start must be journaled")
    };
    let mut payload: AttemptStartedPayload =
        serde_json::from_value(started.payload.clone()).unwrap();
    payload.pins = pins;
    started.payload = serde_json::to_value(payload).unwrap();
    started
}

#[test]
fn reset_recovery_dispatches_the_original_pinned_revision() {
    let spec = agent_spec("reset");
    let pinned = workspace_pins("rev-clean");
    let started = started_agent(&spec, pinned.clone());
    let running = RunState::fold("run", spec.clone(), std::slice::from_ref(&started)).unwrap();
    let recovered = recovery_actions(&running, 20);
    let entries = vec![
        started,
        recovered[0].clone().into_append(),
        recovered[1].clone().into_append(),
    ];
    let backoff = RunState::fold("run", spec.clone(), &entries).unwrap();
    let Action::Append(timer_fired) = next_actions(&backoff, 20).remove(0) else {
        panic!("retry timer must fire")
    };
    let mut ready_entries = entries;
    ready_entries.push(timer_fired);
    let ready = RunState::fold("run", spec, &ready_entries).unwrap();
    let actions = next_actions(&ready, 20);
    let Action::Dispatch { pins, recovery, .. } = &actions[1] else {
        panic!("replacement attempt must dispatch")
    };
    assert_eq!(pins, &pinned);
    assert_eq!(
        recovery.as_ref().unwrap().restore_pins.as_ref(),
        Some(&pinned)
    );
    assert_eq!(
        recovery.as_ref().unwrap().previous_completion_reason,
        Some(CompletionReason::Crashed)
    );
}

#[test]
fn inspect_recovery_injects_the_dirty_pin_completion_reason_and_tail() {
    let spec = agent_spec("inspect");
    let clean = workspace_pins("rev-clean");
    let dirty = workspace_pins("rev-dirty");
    let started = started_agent(&spec, clean);
    let running = RunState::fold("run", spec.clone(), std::slice::from_ref(&started)).unwrap();
    let result = AttemptResult {
        human_intervention: false,
        output: Value::Null,
        budget: Budget::default(),
        completed_by: "worker".to_owned(),
        end_pins: Some(dirty.clone()),
        effects: vec![],
        trajectory_tail: Some(json!(["edited file"])),
        failure_reason: Some(CompletionReason::WorkerError),
        failure_detail: Some("stub rejection".to_owned()),
        reported_cost: None,
    };
    let completed = completion_actions(
        "run",
        &spec.steps[0],
        1,
        running.steps["agent"].semantic_executions,
        result,
        20,
    );
    let mut entries = vec![started];
    entries.extend(completed.into_iter().filter_map(|action| match action {
        Action::Append(entry) => Some(entry),
        _ => None,
    }));
    let backoff = RunState::fold("run", spec.clone(), &entries).unwrap();
    let Action::Append(timer_fired) = next_actions(&backoff, 20).remove(0) else {
        panic!("retry timer must fire")
    };
    entries.push(timer_fired);
    let ready = RunState::fold("run", spec, &entries).unwrap();
    let actions = next_actions(&ready, 20);
    let Action::Dispatch { pins, recovery, .. } = &actions[1] else {
        panic!("inspect retry must dispatch")
    };
    let recovery = recovery.as_ref().unwrap();
    assert_eq!(pins, &dirty);
    assert_eq!(
        recovery.previous_completion_reason,
        Some(CompletionReason::WorkerError)
    );
    assert_eq!(recovery.trajectory_tail, Some(json!(["edited file"])));
    assert!(recovery.restore_pins.is_none());
}

#[test]
fn manual_recovery_parks_needs_human_and_never_redispatches() {
    let spec = agent_spec("manual");
    let started = started_agent(&spec, workspace_pins("rev-clean"));
    let running = RunState::fold("run", spec.clone(), std::slice::from_ref(&started)).unwrap();
    let recovered = recovery_actions(&running, 20);
    let Action::Append(wait) = &recovered[1] else {
        panic!(
            "manual recovery must park on wait.human: {:?}",
            recovered[1]
        )
    };
    assert_eq!(wait.entry_type, EntryType::WaitHuman);
    // Appendix A rule 4: the human is handed a diff of the *pinned* revision vs.
    // current state, so the reference must name the surface and the revision the
    // attempt actually started from — not a constant.
    let human: crate::entry::WaitHumanPayload =
        serde_json::from_value(wait.payload.clone()).unwrap();
    assert_eq!(human.diff_ref.as_deref(), Some("repo@rev-clean..current"));
    assert!(
        human.prompt.contains("agent") && human.prompt.contains("run"),
        "the prompt must name the step and run it parked: {}",
        human.prompt
    );
    let mut entries = vec![started];
    entries.extend(recovered.into_iter().filter_map(|action| match action {
        Action::Append(entry) => Some(entry),
        _ => None,
    }));
    let parked = RunState::fold("run", spec, &entries).unwrap();
    assert!(matches!(
        parked.steps["agent"].state,
        StepState::NeedsHuman { .. }
    ));
    assert!(next_actions(&parked, 30).is_empty());
}

trait AppendAction {
    fn into_append(self) -> JournalEntry;
}

impl AppendAction for Action {
    fn into_append(self) -> JournalEntry {
        match self {
            Action::Append(entry) => entry,
            _ => panic!("expected journal append"),
        }
    }
}

/// Regression, 2026-09-06 (#195): a WORKER-reported failure carries no
/// `failure_detail` — that field is set only for kernel-side rejections — and
/// the completion used to map over it, journaling `verification: null`. The
/// reason then survived only as the taxonomy label, which is precisely what the
/// branch was written to prevent, and `output` is nulled for every non-success
/// so nothing else carried it either.
///
/// Every other row in this file sets `failure_detail: Some(..)`, so the whole
/// suite exercised the arm that worked and none of it touched the arm that did
/// not. This asserts the arm that did not.
#[test]
fn worker_reported_failure_without_detail_still_records_a_verification() {
    let spec: crate::RunSpec = serde_json::from_value(json!({
        "version": "0.1.0",
        "steps": [
            {
                "id": "only",
                "type": "deterministic",
                "command": "false",
                "max_iterations": 1
            }
        ]
    }))
    .unwrap();
    let result = AttemptResult {
        human_intervention: false,
        output: Value::Null,
        budget: Budget::default(),
        completed_by: "worker".to_owned(),
        end_pins: None,
        effects: Vec::new(),
        trajectory_tail: None,
        failure_reason: Some(CompletionReason::WorkerError),
        // The point of the case: the worker reported a failure and sent no
        // detail with it.
        failure_detail: None,
        reported_cost: None,
    };
    let entries: Vec<_> = completion_actions("run", &spec.steps[0], 1, 0, result, 1_000)
        .into_iter()
        .filter_map(|action| match action {
            Action::Append(entry) => Some(entry),
            _ => None,
        })
        .collect();

    let completed = entries
        .iter()
        .find(|entry| entry.entry_type == EntryType::StepCompleted)
        .expect("a step.completed entry");
    let payload: StepCompletedPayload =
        serde_json::from_value(serde_json::to_value(&completed.payload).unwrap()).unwrap();

    let record = payload
        .verification
        .expect("a worker-reported failure must journal WHY, not just its taxonomy label");
    assert_eq!(record.verdict, crate::VerificationVerdict::Fail);
    assert_eq!(record.gate, "execution");
    // The reason itself has to appear, or the record is present but empty of
    // information and the diagnostic is still gone.
    // The journal's own vocabulary, not Rust's Debug spelling: the same
    // `worker_error` a reader sees in `completionReason`. Pinning the string
    // keeps the two from drifting apart.
    assert!(
        record.detail.contains("worker_error"),
        "detail should name the reported reason in journal vocabulary, got {:?}",
        record.detail
    );
    // And the taxonomy label must still be the reason the worker gave, not
    // overwritten by the verification bookkeeping.
    assert_eq!(payload.completion_reason, CompletionReason::WorkerError);
}

/// `reason_label` hand-writes the journal spellings, so nothing but a test stops
/// it drifting from what `CompletionReason` actually serializes. Pins every
/// variant against serde rather than spot-checking one, so a rename in either
/// place fails here instead of silently showing a reader two names for one
/// completion.
///
/// #197 moved the drift test onto `CompletionReason` itself, beside the label.
/// This wrapper stays only to catch a rename of `journal_label()` at a
/// familiar call site — the real invariant lives in `entry.rs`'s
/// `completion_reason_tests::every_journal_label_matches_serialized`.
#[test]
fn every_reason_label_matches_its_serialized_form() {
    for reason in CompletionReason::ALL {
        let serialized = serde_json::to_value(reason).unwrap();
        assert_eq!(
            serialized.as_str().expect("a string spelling"),
            reason.journal_label(),
        );
    }
}

#[test]
fn deterministic_lease_override_and_default_are_journaled() {
    for (lease, duration) in [(None, 30_000), (Some(300_000), 300_000), (Some(10), 10)] {
        let mut value =
            json!({"steps": [{"id": "cmd", "type": "deterministic", "command": "true"}]});
        if let Some(ms) = lease {
            value["steps"][0]["lease_ms"] = json!(ms);
        }
        let spec = crate::RunSpec::parse(&value).unwrap();
        spec.validate().unwrap();
        let state = RunState::fold("run", spec, &[]).unwrap();
        let clock = SimClock::new(1000);
        let Action::Append(started) = &next_actions(&state, clock.now_ms())[0] else {
            panic!("expected journaled lease");
        };
        let payload: AttemptStartedPayload =
            serde_json::from_value(started.payload.clone()).unwrap();
        assert_eq!(payload.lease_deadline_ms, clock.now_ms() + duration);
    }
}

#[test]
fn deterministic_lease_rejects_invalid_and_foreign_fields() {
    for ms in [0, u64::MAX] {
        let spec = crate::RunSpec::parse(&json!({"steps": [{
            "id": "cmd", "type": "deterministic", "command": "true", "lease_ms": ms
        }]}))
        .unwrap();
        assert!(spec.validate().is_err());
    }
    for kind in ["llm", "agent"] {
        assert!(
            crate::RunSpec::parse(&json!({"steps": [{
                "id": "worker", "type": kind, "lease_ms": 1000
            }]}))
            .is_err()
        );
    }
}

/// Pin the journal contract the `retries_exhausted` diagnostic reads.
///
/// A retried step appends one `step.completed` PER ATTEMPT, each carrying its
/// own attempt envelope and — for a deterministic step — its own preserved
/// `{exit_code, stdout_tail, stderr_tail}`. Without that, the first attempt's
/// error would not exist to report and the reader could only ever show the
/// last one. Nothing about retry policy is asserted or changed here.
///
/// The two attempts below fail with the SAME exit code and DIFFERENT stderr,
/// which is the shape that matters: the kernel's own verification record is
/// byte-identical across them ("exit code was 1; output did not contain
/// \"hello\""), so a reader comparing only that record would call two
/// different failures the same failure. The distinguishing evidence lives in
/// the preserved output.
#[test]
fn each_failed_attempt_journals_its_own_output_beside_an_identical_verdict() {
    let spec = retrying_spec();
    let mut step = spec.steps[0].clone();
    step.max_iterations = 2;

    let first_output = json!({
        "exit_code": 1,
        "stdout_tail": "",
        "stderr_tail": "remote: GitLab: You cannot push commits for 'factory@example.com'",
    });
    let first = completion_actions(
        "run",
        &step,
        1,
        0,
        AttemptResult::successful(first_output.clone(), "kernel"),
        1_000,
    );
    let Action::Append(first_entry) = &first[0] else {
        panic!("a failed attempt must append its own completion");
    };
    let first_payload: StepCompletedPayload =
        serde_json::from_value(first_entry.payload.clone()).unwrap();
    assert_eq!(first_entry.attempt, Some(1));
    assert_eq!(first_payload.disposition, Disposition::Retry);
    assert_eq!(
        first_payload.completion_reason,
        CompletionReason::VerificationFailed
    );
    assert_eq!(first_payload.output, first_output);

    let second_output = json!({
        "exit_code": 1,
        "stdout_tail": "",
        "stderr_tail": "nothing staged inside the declared scope",
    });
    let second = completion_actions(
        "run",
        &step,
        2,
        1,
        AttemptResult::successful(second_output.clone(), "kernel"),
        2_000,
    );
    let Action::Append(second_entry) = &second[0] else {
        panic!("the terminal attempt must append its own completion");
    };
    let second_payload: StepCompletedPayload =
        serde_json::from_value(second_entry.payload.clone()).unwrap();
    assert_eq!(second_entry.attempt, Some(2));
    assert_eq!(second_payload.disposition, Disposition::StepDone);
    assert_eq!(
        second_payload.completion_reason,
        CompletionReason::RetriesExhausted
    );
    assert_eq!(second_payload.output, second_output);

    // Both attempts survive, and only the output tells them apart.
    assert_ne!(first_payload.output, second_payload.output);
    assert_eq!(first_payload.verification, second_payload.verification);
    let verification = first_payload.verification.expect("a failure names itself");
    assert_eq!(verification.gate, "exit_code+output_contains");
    assert_eq!(verification.verdict, crate::entry::VerificationVerdict::Fail);
}

/// The label change at the budget limit is POLICY, not a different cause.
///
/// Identical deterministic failures are labelled `verification_failed` while
/// an iteration remains and `retries_exhausted` once it does not, because
/// `completion_actions` picks the fallback reason from the branch it took. A
/// reader that compared the raw labels would report "the retry failed for a
/// different reason" on every ordinary repeated failure, so this pins that
/// the two labels can sit over byte-identical evidence.
#[test]
fn the_exhaustion_label_replaces_verification_failed_over_identical_evidence() {
    let spec = retrying_spec();
    let mut step = spec.steps[0].clone();
    step.max_iterations = 2;
    let output = json!({"exit_code": 1, "stdout_tail": "", "stderr_tail": "same failure"});

    let mut payloads = Vec::new();
    for (attempt, semantic_executions, now_ms) in [(1, 0, 1_000), (2, 1, 2_000)] {
        let actions = completion_actions(
            "run",
            &step,
            attempt,
            semantic_executions,
            AttemptResult::successful(output.clone(), "kernel"),
            now_ms,
        );
        let Action::Append(entry) = &actions[0] else {
            panic!("every attempt appends a completion");
        };
        assert_eq!(entry.attempt, Some(attempt));
        payloads.push(
            serde_json::from_value::<StepCompletedPayload>(entry.payload.clone()).unwrap(),
        );
    }

    assert_eq!(
        payloads[0].completion_reason,
        CompletionReason::VerificationFailed
    );
    assert_eq!(
        payloads[1].completion_reason,
        CompletionReason::RetriesExhausted
    );
    assert_eq!(payloads[0].output, payloads[1].output);
    assert_eq!(payloads[0].verification, payloads[1].verification);
}

/// A worker-reported failure keeps its OWN label on both attempts.
///
/// `failure_reason` is supplied, so neither fallback applies: the retry and
/// the terminal completion both read `worker_error`, and each carries the
/// worker's own detail. Only the `verification_failed` → `retries_exhausted`
/// pair is a policy-only transition; every other label difference across
/// attempts is a real difference in what the worker reported.
#[test]
fn a_worker_reported_reason_is_not_rewritten_by_the_retry_branch() {
    let spec = retrying_spec();
    let mut step = spec.steps[0].clone();
    step.max_iterations = 2;
    let result = |detail: &str| AttemptResult {
        failure_reason: Some(CompletionReason::WorkerError),
        failure_detail: Some(detail.to_owned()),
        ..AttemptResult::successful(Value::Null, "kernel")
    };

    let retry = completion_actions("run", &step, 1, 0, result("push rejected"), 1_000);
    let Action::Append(retry_entry) = &retry[0] else {
        panic!("a worker failure appends a completion");
    };
    let retry_payload: StepCompletedPayload =
        serde_json::from_value(retry_entry.payload.clone()).unwrap();
    assert_eq!(retry_payload.completion_reason, CompletionReason::WorkerError);
    assert_eq!(retry_payload.disposition, Disposition::Retry);
    assert_eq!(
        retry_payload.verification.as_ref().map(|v| v.detail.as_str()),
        Some("push rejected")
    );

    let terminal = completion_actions("run", &step, 2, 1, result("nothing staged"), 2_000);
    let Action::Append(terminal_entry) = &terminal[0] else {
        panic!("the terminal worker failure appends a completion");
    };
    let terminal_payload: StepCompletedPayload =
        serde_json::from_value(terminal_entry.payload.clone()).unwrap();
    assert_eq!(
        terminal_payload.completion_reason,
        CompletionReason::WorkerError
    );
    assert_eq!(terminal_payload.disposition, Disposition::StepDone);
    assert_eq!(
        terminal_payload
            .verification
            .as_ref()
            .map(|v| v.detail.as_str()),
        Some("nothing staged")
    );
}
