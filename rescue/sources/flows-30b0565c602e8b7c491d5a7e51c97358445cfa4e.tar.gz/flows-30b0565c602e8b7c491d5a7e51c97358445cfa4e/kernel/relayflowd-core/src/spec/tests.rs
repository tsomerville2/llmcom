use serde_json::{Value, json};

use super::*;

#[test]
fn zero_agent_flow_is_valid() {
    let spec = RunSpec::parse(&json!({
        "steps": [{"id": "hello", "type": "deterministic", "command": "printf hello"}]
    }))
    .unwrap();
    assert_eq!(spec.steps[0].max_iterations, 1);
    assert!(spec.validate().is_ok());
}

#[test]
fn cycles_are_rejected() {
    let spec = RunSpec::parse(&json!({
        "steps": [
            {"id": "a", "type": "deterministic", "command": "true", "depends_on": ["b"]},
            {"id": "b", "type": "deterministic", "command": "true", "depends_on": ["a"]}
        ]
    }))
    .unwrap();
    assert!(matches!(
        spec.validate(),
        Err(SpecError::DependencyCycle(_))
    ));
}

const DEEP_DEPENDENCY_GRAPH_LENGTH: usize = 10_000;

fn sdk_boundary_dependency_graph(cyclic: bool) -> RunSpec {
    let steps = (0..DEEP_DEPENDENCY_GRAPH_LENGTH)
        .map(|index| {
            let mut step = json!({
                "id": format!("s{index}"),
                "type": "deterministic",
                "command": "true",
            });
            if index + 1 < DEEP_DEPENDENCY_GRAPH_LENGTH {
                step["depends_on"] = json!([format!("s{}", index + 1)]);
            } else if cyclic {
                step["depends_on"] = json!(["s0"]);
            }
            step
        })
        .collect::<Vec<Value>>();

    RunSpec::parse(&json!({
        "version": "0.1.0",
        "steps": steps,
    }))
    .expect("the SDK-to-kernel boundary shape must parse")
}

#[test]
fn sdk_boundary_accepts_a_valid_10_000_step_reverse_chain() {
    assert_eq!(sdk_boundary_dependency_graph(false).validate(), Ok(()));
}

#[test]
fn sdk_boundary_rejects_a_10_000_step_cycle_with_a_typed_error() {
    assert_eq!(
        sdk_boundary_dependency_graph(true).validate(),
        Err(SpecError::DependencyCycle("s0".to_owned()))
    );
}

#[test]
fn a_misspelled_verification_gate_key_is_a_parse_error_not_a_dropped_gate() {
    // The fail-open refutation case: "output_contain" (typo) must never
    // silently deserialize to an empty VerificationSpec.
    let result = RunSpec::parse(&json!({
        "steps": [{
            "id": "hello",
            "type": "deterministic",
            "command": "printf hello",
            "verification": {"output_contain": "hello"}
        }]
    }));
    assert!(
        matches!(result, Err(SpecError::Malformed(ref message)) if message.contains("output_contain")),
        "{result:?}"
    );
}

#[test]
fn a_misspelled_step_level_key_is_a_parse_error() {
    // `#[serde(flatten)]` would silently eat "verifcation"; RunSpec::parse
    // must not.
    let result = RunSpec::parse(&json!({
        "steps": [{
            "id": "hello",
            "type": "deterministic",
            "command": "printf hello",
            "verifcation": {"output_contains": "hello"}
        }]
    }));
    assert_eq!(
        result,
        Err(SpecError::UnknownField {
            at: "steps[0]".to_owned(),
            field: "verifcation".to_owned(),
        })
    );
}

#[test]
fn unknown_root_and_nested_fields_are_rejected() {
    assert!(RunSpec::parse(&json!({"steps": [], "extra": true})).is_err());
    assert!(
        RunSpec::parse(&json!({
            "steps": [{
                "id": "a", "type": "agent", "instruction": "do",
                "surfaces": {"workspaces": [{"surface": "repo"}]}
            }]
        }))
        .is_err()
    );
}

#[test]
fn spec_version_is_semver_and_gated() {
    let spec = RunSpec::parse(&json!({
        "version": "9.9.9",
        "steps": [{"id": "a", "type": "deterministic", "command": "true"}]
    }))
    .unwrap();
    assert_eq!(
        spec.validate(),
        Err(SpecError::UnsupportedVersion("9.9.9".to_owned()))
    );
}

#[test]
fn the_full_ladder_parses_in_the_one_dialect() {
    let spec = RunSpec::parse(&json!({
        "version": "0.1.0",
        "name": "ladder",
        "cli": "claude",
        "triggers": [{"id": "hourly", "executor": "worker-a"}],
        "steps": [
            {"id": "a", "type": "deterministic", "command": "true", "timeout_ms": 5000},
            {"id": "b", "type": "llm", "prompt": "plan", "model": "claude-sonnet-5",
             "cli": "codex",
             "depends_on": ["a"], "verification": {"json_schema": {"type": "object"}}},
            {"id": "c", "type": "agent", "instruction": "edit", "depends_on": ["b"],
             "recovery_mode": "inspect",
             "surfaces": {"workspace": [{"surface": "repo"}], "streams": [{"stream": "results"}],
                          "external": ["pr://github/example"]},
             "permissions": {"access_preset": "readwrite", "file_globs": ["src/**"]}}
        ],
        "budget": {"max_tokens_out": 2000, "max_dollars": "1.50"}
    }))
    .unwrap();
    assert!(spec.validate().is_ok());
    assert_eq!(spec.steps[2].step_type(), StepType::Agent);
    assert_eq!(spec.cli.as_deref(), Some("claude"));
    assert_eq!(spec.triggers[0].executor, "worker-a");
}

#[test]
fn cli_identity_is_internal_to_provider_steps() {
    for step in [
        json!({
            "id": "llm",
            "type": "llm",
            "prompt": "plan",
            "cli": "/store/provider-cli.js",
            "cli_identity": "claude"
        }),
        json!({
            "id": "agent",
            "type": "agent",
            "instruction": "edit",
            "cli": "/store/provider-cli.js",
            "cli_identity": "codex"
        }),
    ] {
        let spec = RunSpec::parse(&json!({ "steps": [step] })).unwrap();
        assert!(spec.validate().is_ok());
    }

    assert!(matches!(
        RunSpec::parse(&json!({
            "steps": [{
                "id": "shell",
                "type": "deterministic",
                "command": "true",
                "cli_identity": "claude"
            }]
        })),
        Err(SpecError::UnknownField { field, .. }) if field == "cli_identity"
    ));
    let empty = RunSpec::parse(&json!({
        "steps": [{
            "id": "agent",
            "type": "agent",
            "instruction": "edit",
            "cli": "/store/provider-cli.js",
            "cli_identity": " "
        }]
    }))
    .unwrap();
    assert!(matches!(empty.validate(), Err(SpecError::Malformed(message))
        if message.contains("cli_identity")));
}

#[test]
fn external_surface_paths_must_have_one_canonical_spelling() {
    for path in [
        "",
        ".",
        "..",
        "//",
        "/provider/./item",
        "/provider/../item",
        "/provider//item",
        "/provider/item//",
        "/provider/item/",
        " pr://github/example",
    ] {
        let spec = RunSpec::parse(&json!({
            "steps": [{
                "id": "agent",
                "type": "agent",
                "instruction": "write",
                "surfaces": {"external": [path]}
            }]
        }))
        .unwrap();
        assert!(
            matches!(
                spec.validate(),
                Err(SpecError::InvalidExternalSurface { path: invalid, .. }) if invalid == path
            ),
            "accepted non-canonical surface {path:?}"
        );
    }
    for path in [
        "/provider/item",
        "pr://github/example",
        "provider/item",
    ] {
        let spec = RunSpec::parse(&json!({
            "steps": [{
                "id": "agent",
                "type": "agent",
                "instruction": "write",
                "surfaces": {"external": [path]}
            }]
        }))
        .unwrap();
        assert!(
            spec.validate().is_ok(),
            "rejected canonical surface {path:?}"
        );
    }
    assert!(external_surface_contains(
        "/provider/item",
        "/provider/item/child"
    ));
    // A non-canonical spelling is not a surface, so containment fails closed
    // rather than resolving to the canonical one.
    assert!(!external_surface_contains(
        "/provider/item/",
        "/provider/item"
    ));
    assert!(!external_surface_contains(
        "/provider/item",
        "/provider/other"
    ));
    assert!(!external_surface_contains(
        "/provider/item",
        "/provider/./item"
    ));
}

#[test]
fn workspace_mounts_and_worktrees_must_have_one_canonical_spelling() {
    for surface in [
        "",
        ".",
        "..",
        "//",
        "/mount/./repo",
        "/mount/repo/../repo",
        "/mount//repo",
        "/mount/repo//",
        "/mount/repo/",
        "repo/",
        " worktrees/repo",
        "worktrees/./repo",
    ] {
        let spec = RunSpec::parse(&json!({
            "steps": [{
                "id": "agent",
                "type": "agent",
                "instruction": "write",
                "surfaces": {"workspace": [{"surface": surface}]}
            }]
        }))
        .unwrap();
        assert!(
            matches!(
                spec.validate(),
                Err(SpecError::InvalidWorkspaceSurface { surface: invalid, .. })
                    if invalid == surface
            ),
            "accepted non-canonical workspace surface {surface:?}"
        );
    }
    for surface in ["/mount/repo", "worktrees/repo", "repo"] {
        let spec = RunSpec::parse(&json!({
            "steps": [{
                "id": "agent",
                "type": "agent",
                "instruction": "write",
                "surfaces": {"workspace": [{"surface": surface}]}
            }]
        }))
        .unwrap();
        assert!(spec.validate().is_ok(), "rejected {surface:?}");
    }
}

#[test]
fn preflight_data_is_fail_closed() {
    let malformed = RunSpec::parse(&json!({
        "triggers": [{"id": "hourly", "executor": "worker-a", "worker": "guessed"}],
        "steps": [{"id": "a", "type": "llm", "prompt": "p", "cli": ""}]
    }));
    assert!(
        matches!(malformed, Err(SpecError::Malformed(ref message)) if message.contains("unknown field `worker`")),
        "{malformed:?}"
    );

    let empty_flow_cli = RunSpec::parse(&json!({
        "cli": "",
        "steps": [{"id": "a", "type": "deterministic", "command": "true"}]
    }))
    .unwrap();
    assert_eq!(empty_flow_cli.validate(), Err(SpecError::EmptyCli));

    for (id, executor) in [("", "worker-a"), ("hourly", "")] {
        let invalid_trigger = RunSpec::parse(&json!({
            "triggers": [{"id": id, "executor": executor}],
            "steps": [{"id": "a", "type": "deterministic", "command": "true"}]
        }))
        .unwrap();
        assert_eq!(
            invalid_trigger.validate(),
            Err(SpecError::InvalidTrigger(id.to_owned()))
        );
    }

    let duplicate_trigger = RunSpec::parse(&json!({
        "triggers": [
            {"id": "hourly", "executor": "worker-a"},
            {"id": "hourly", "executor": "worker-b"}
        ],
        "steps": [{"id": "a", "type": "deterministic", "command": "true"}]
    }))
    .unwrap();
    assert_eq!(
        duplicate_trigger.validate(),
        Err(SpecError::DuplicateTrigger("hourly".to_owned()))
    );

    let empty_cli = RunSpec::parse(&json!({
        "steps": [{"id": "a", "type": "llm", "prompt": "p", "cli": ""}]
    }))
    .unwrap();
    assert_eq!(
        empty_cli.validate(),
        Err(SpecError::EmptyStepCli("a".to_owned()))
    );
}

/// `on_non_zero` is a declared policy, so it parses fail-closed like every
/// other spec field: an unrecognized value is a refusal, never a silent
/// fallback to the fatal default.
#[test]
fn on_non_zero_parses_the_two_declared_policies_and_refuses_anything_else() {
    let recorded = RunSpec::parse(&json!({
        "steps": [{
            "id": "tests", "type": "deterministic", "command": "npm test",
            "on_non_zero": "record"
        }]
    }))
    .unwrap();
    assert!(matches!(
        recorded.steps[0].kind,
        StepKind::Deterministic {
            on_non_zero: OnNonZero::Record,
            ..
        }
    ));
    assert_eq!(recorded.validate(), Ok(()));

    let explicit_fail = RunSpec::parse(&json!({
        "steps": [{
            "id": "tests", "type": "deterministic", "command": "npm test",
            "on_non_zero": "fail"
        }]
    }))
    .unwrap();
    assert!(matches!(
        explicit_fail.steps[0].kind,
        StepKind::Deterministic {
            on_non_zero: OnNonZero::Fail,
            ..
        }
    ));

    assert!(matches!(
        RunSpec::parse(&json!({
            "steps": [{
                "id": "tests", "type": "deterministic", "command": "npm test",
                "on_non_zero": "ignore"
            }]
        })),
        Err(SpecError::Malformed(_))
    ));

    // The policy belongs to the deterministic rung only; a worker step that
    // declares it is an unknown field, not an inert decoration.
    assert!(matches!(
        RunSpec::parse(&json!({
            "steps": [{
                "id": "ask", "type": "llm", "prompt": "p", "on_non_zero": "record"
            }]
        })),
        Err(SpecError::UnknownField { field, .. }) if field == "on_non_zero"
    ));
}

/// The boundary artifact is hashed. A step that does not declare the policy
/// must serialize to the exact bytes it did before the field existed, or every
/// committed canonical fixture and every memoized step hash moves at once.
#[test]
fn the_default_policy_is_absent_from_the_serialized_boundary_spec() {
    let spec = RunSpec::parse(&json!({
        "steps": [{"id": "a", "type": "deterministic", "command": "true"}]
    }))
    .unwrap();
    let serialized = serde_json::to_value(&spec).unwrap();
    assert!(
        serialized["steps"][0].get("on_non_zero").is_none(),
        "{serialized}"
    );

    let recorded = RunSpec::parse(&json!({
        "steps": [{
            "id": "a", "type": "deterministic", "command": "true",
            "on_non_zero": "record"
        }]
    }))
    .unwrap();
    assert_eq!(
        serde_json::to_value(&recorded).unwrap()["steps"][0]["on_non_zero"],
        json!("record")
    );
}

#[test]
fn agent_cwd_is_carried_and_must_be_run_root_relative() {
    let with_cwd = RunSpec::parse(&json!({
        "steps": [{"id": "a", "type": "agent", "instruction": "i", "cwd": ".wt/a"}]
    }))
    .unwrap();
    assert!(with_cwd.validate().is_ok());
    assert_eq!(
        serde_json::to_value(&with_cwd.steps[0]).unwrap()["cwd"],
        json!(".wt/a")
    );

    let absolute = RunSpec::parse(&json!({
        "steps": [{"id": "a", "type": "agent", "instruction": "i", "cwd": "/repo/.wt/a"}]
    }))
    .unwrap();
    assert_eq!(
        absolute.validate(),
        Err(SpecError::InvalidAgentCwd {
            step: "a".to_owned(),
            cwd: "/repo/.wt/a".to_owned()
        })
    );

    // `cwd` is agent-only: an llm step still refuses it as an unknown field.
    assert!(matches!(
        RunSpec::parse(&json!({
            "steps": [{"id": "a", "type": "llm", "prompt": "p", "cwd": "repo"}]
        })),
        Err(SpecError::UnknownField { .. })
    ));
}

#[test]
fn agent_without_cwd_hashes_as_before() {
    let spec = RunSpec::parse(&json!({
        "steps": [{"id": "a", "type": "agent", "instruction": "i", "cli": "claude"}]
    }))
    .unwrap();
    let serialized = serde_json::to_value(&spec.steps[0]).unwrap();
    assert!(serialized.get("cwd").is_none());
    // Pinned to the value main computes: journals recorded before `cwd`
    // existed must still memoize against this step.
    assert_eq!(
        crate::memoization::step_spec_hash(&spec.steps[0]),
        "f5e8e24cd23fb3ee42ae0e8ddb7d68b0c869720fed13adce3bd5b23a8a06704f"
    );
}
