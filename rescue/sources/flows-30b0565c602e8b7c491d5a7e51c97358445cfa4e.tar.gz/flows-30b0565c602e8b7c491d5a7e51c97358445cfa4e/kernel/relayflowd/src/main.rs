use std::path::PathBuf;

use anyhow::{Result, bail};
use clap::{Parser, Subcommand};
use relayflowd::{CancelOptions, DriveOptions, Engine, RunStatus, engine::read_spec, server};

#[derive(Debug, Parser)]
#[command(
    name = "relayflowd",
    version,
    about = "Relayflow durable execution kernel"
)]
struct Cli {
    #[arg(long, global = true, default_value = ".relayflowd")]
    data_dir: PathBuf,
    #[command(subcommand)]
    command: Command,
}

#[derive(Debug, Subcommand)]
enum Command {
    /// Start and execute a run spec JSON file.
    Run {
        spec: PathBuf,
        /// Submit an event to the flow's subscriptions instead of starting directly.
        #[arg(long)]
        event: Option<String>,
        #[arg(long, default_value = "cli")]
        created_by: String,
        /// Test/debug boundary: return after this many newly completed steps.
        #[arg(long, hide = true)]
        stop_after: Option<usize>,
        /// Test/debug boundary: pause before the named runnable step.
        #[arg(long, hide = true)]
        pause_before_step: Option<String>,
        /// Test/debug boundary: pause after all steps, before run completion.
        #[arg(long, hide = true)]
        pause_before_completion: bool,
    },
    /// Resume a run from its durable journal.
    Resume {
        run_id: String,
        #[arg(long, hide = true)]
        stop_after: Option<usize>,
    },
    /// Durably cancel a run and close any active lease.
    Cancel {
        run_id: String,
        /// Test/debug boundary: pause after intent is durable, before facts.
        #[arg(long, hide = true)]
        pause_after_request: bool,
    },
    /// Serve journal protocol v0 over a Unix socket.
    Serve,
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    let engine = Engine::new(&cli.data_dir);
    match cli.command {
        Command::Run {
            spec,
            event,
            created_by,
            stop_after,
            pause_before_step,
            pause_before_completion,
        } => {
            if let Some(event) = event {
                let submitted = engine.submit_event(
                    read_spec(&spec)?,
                    serde_json::from_str(&event)?,
                    &created_by,
                )?;
                println!("{}", serde_json::to_string(&submitted)?);
                return Ok(());
            }
            let outcome = engine.start_with_options(
                read_spec(&spec)?,
                &created_by,
                DriveOptions {
                    stop_after,
                    pause_before_step,
                    pause_before_completion,
                    ..DriveOptions::default()
                },
            )?;
            println!("{}", serde_json::to_string(&outcome)?);
            if outcome.status == RunStatus::Failed {
                bail!("run {} failed", outcome.run_id);
            }
        }
        Command::Resume { run_id, stop_after } => {
            let outcome = if stop_after.is_none() {
                if let Some(outcome) = server::resume_via_socket(&cli.data_dir, &run_id)? {
                    outcome
                } else {
                    engine.resume(&run_id, None)?
                }
            } else {
                engine.resume(&run_id, stop_after)?
            };
            println!("{}", serde_json::to_string(&outcome)?);
            if outcome.status == RunStatus::Failed {
                bail!("run {} failed", outcome.run_id);
            }
        }
        Command::Cancel {
            run_id,
            pause_after_request,
        } => {
            let outcome = if !pause_after_request {
                if let Some(outcome) = server::cancel_via_socket(&cli.data_dir, &run_id)? {
                    outcome
                } else {
                    engine.cancel(&run_id, "cli")?
                }
            } else {
                engine.cancel_with_options(
                    &run_id,
                    "cli",
                    CancelOptions {
                        pause_after_request: true,
                    },
                )?
            };
            println!("{}", serde_json::to_string(&outcome)?);
        }
        Command::Serve => server::serve(&cli.data_dir)?,
    }
    Ok(())
}
