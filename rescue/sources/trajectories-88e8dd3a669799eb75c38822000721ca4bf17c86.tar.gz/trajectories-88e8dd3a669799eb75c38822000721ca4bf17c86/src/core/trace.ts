/**
 * Agent Trace generation logic
 *
 * Captures git state before and after agent work to generate
 * trace records that attribute code contributions to agents.
 */

import { execSync } from "node:child_process";
import { createHash } from "node:crypto";
import type {
  TraceFile,
  TraceRange,
  TraceRecord,
  Trajectory,
  TrajectoryTraceRef,
} from "./types.js";

/**
 * Validate a git reference to prevent command injection
 * @param ref - Git reference to validate
 * @returns True if the ref is safe to use in git commands
 */
export function isValidGitRef(ref: string): boolean {
  // Allow HEAD, branch names, and commit hashes
  // Git refs can contain alphanumeric, -, _, /, and .
  // Commit hashes are 7-40 hex characters
  const validRefPattern = /^[a-zA-Z0-9_\-./]+$/;
  const commitHashPattern = /^[a-fA-F0-9]{7,40}$/;

  if (ref === "HEAD" || ref === "working") {
    return true;
  }

  if (commitHashPattern.test(ref)) {
    return true;
  }

  // For branch names, ensure no shell metacharacters
  if (validRefPattern.test(ref) && ref.length <= 255) {
    // Additional check: no consecutive dots (prevents .. traversal tricks)
    if (!ref.includes("..") || ref.split("..").every((p) => p.length > 0)) {
      return true;
    }
  }

  return false;
}

/**
 * Check if the current directory is inside a git repository
 * @returns True if in a git repo, false otherwise
 */
export function isGitRepo(): boolean {
  try {
    execSync("git rev-parse --is-inside-work-tree", {
      encoding: "utf-8",
      stdio: ["pipe", "pipe", "pipe"],
    });
    return true;
  } catch {
    return false;
  }
}

/**
 * Get the current git HEAD reference
 * @returns The current HEAD commit hash, or null if not in a git repo
 */
export function getGitHead(): string | null {
  if (!isGitRepo()) {
    return null;
  }

  try {
    const head = execSync("git rev-parse HEAD", {
      encoding: "utf-8",
      stdio: ["pipe", "pipe", "pipe"],
    }).trim();
    return head;
  } catch {
    return null;
  }
}

/**
 * Capture the current git state for trace tracking
 * @returns The start reference (commit hash) or null if not in git repo
 */
export function captureGitState(): string | null {
  return getGitHead();
}

/**
 * Parse git diff output to extract changed files and line ranges
 * @param diffOutput - Raw git diff output
 * @returns Array of file paths with their changed line ranges
 */
function parseDiffOutput(
  diffOutput: string,
): Array<{ path: string; ranges: TraceRange[] }> {
  const files: Array<{ path: string; ranges: TraceRange[] }> = [];
  const lines = diffOutput.split("\n");

  let currentFile: string | null = null;
  let currentRanges: TraceRange[] = [];

  for (const line of lines) {
    // Match diff header for file path
    // Format: diff --git a/path/to/file b/path/to/file
    const diffHeaderMatch = line.match(/^diff --git a\/.+ b\/(.+)$/);
    if (diffHeaderMatch) {
      // Save previous file if exists
      if (currentFile) {
        files.push({ path: currentFile, ranges: currentRanges });
      }
      currentFile = diffHeaderMatch[1];
      currentRanges = [];
      continue;
    }

    // Match hunk header for line ranges
    // Format: @@ -start,count +start,count @@ optional context
    const hunkMatch = line.match(/^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@/);
    if (hunkMatch && currentFile) {
      const startLine = Number.parseInt(hunkMatch[1], 10);
      const lineCount = hunkMatch[2] ? Number.parseInt(hunkMatch[2], 10) : 1;

      if (lineCount > 0) {
        currentRanges.push({
          start_line: startLine,
          end_line: startLine + lineCount - 1,
        });
      }
    }
  }

  // Don't forget the last file
  if (currentFile) {
    files.push({ path: currentFile, ranges: currentRanges });
  }

  return files;
}

/**
 * Get the list of changed files between two git refs
 * @param startRef - Starting commit reference
 * @param endRef - Ending commit reference (defaults to HEAD)
 * @returns Array of changed file paths with line ranges
 */
export function getChangedFiles(
  startRef: string,
  endRef = "HEAD",
): Array<{ path: string; ranges: TraceRange[] }> {
  if (!isGitRepo()) {
    return [];
  }

  // Validate git refs to prevent command injection
  if (!isValidGitRef(startRef) || !isValidGitRef(endRef)) {
    return [];
  }

  try {
    const diffOutput = execSync(`git diff ${startRef}..${endRef}`, {
      encoding: "utf-8",
      stdio: ["pipe", "pipe", "pipe"],
      maxBuffer: 10 * 1024 * 1024, // 10MB buffer for large diffs
    });

    return parseDiffOutput(diffOutput);
  } catch {
    return [];
  }
}

/**
 * Detect the model from environment variables
 * Returns model ID using models.dev convention (org/model-name)
 * @returns Model identifier or 'unknown'
 */
export function detectModel(): string {
  // Check custom env var first (pass through as-is if already org/model format)
  if (process.env.TRAIL_TRACE_MODEL) {
    return process.env.TRAIL_TRACE_MODEL;
  }

  // Check Anthropic model env var - normalize to models.dev convention
  if (process.env.ANTHROPIC_MODEL) {
    const model = process.env.ANTHROPIC_MODEL;
    return model.includes("/") ? model : `anthropic/${model}`;
  }

  // Check common AI provider model env vars - normalize to models.dev convention
  if (process.env.OPENAI_MODEL) {
    const model = process.env.OPENAI_MODEL;
    return model.includes("/") ? model : `openai/${model}`;
  }

  return "unknown";
}

/**
 * Generate a unique trace ID using UUID v4
 * Follows agent-trace.dev spec which requires UUID format
 * @returns UUID v4 string
 */
export function generateTraceId(): string {
  return crypto.randomUUID();
}

/**
 * Compute content hash for a given string
 * @param content - Content to hash
 * @returns SHA-256 hash (first 16 chars)
 */
export function computeContentHash(content: string): string {
  return createHash("sha256").update(content).digest("hex").slice(0, 16);
}

/**
 * Generate a trace record from a trajectory and git state
 * @param trajectory - The trajectory to generate trace for
 * @param startRef - The git ref from when work started
 * @returns TraceRecord with file contributions, or null if not in git repo
 */
export function generateTrace(
  trajectory: Trajectory,
  startRef: string,
): TraceRecord | null {
  if (!isGitRepo()) {
    return null;
  }

  const endRef = getGitHead();
  if (!endRef) {
    return null;
  }

  // Get changed files with line ranges
  const changedFiles = getChangedFiles(startRef, endRef);

  // Return null if no files changed
  if (changedFiles.length === 0) {
    return null;
  }

  // Detect the model used
  const model = detectModel();

  // Build trace files
  const traceFiles: TraceFile[] = changedFiles.map(({ path, ranges }) => ({
    path,
    conversations: [
      {
        contributor: {
          type: "ai",
          ...(model !== "unknown" ? { model_id: model } : {}),
        },
        ranges: ranges.map((range) => ({
          ...range,
          revision: endRef,
        })),
      },
    ],
  }));

  return {
    version: "1.0.0",
    id: generateTraceId(),
    timestamp: new Date().toISOString(),
    trajectory: trajectory.id,
    files: traceFiles,
  };
}

/**
 * Migrate a legacy trace record to the current spec format.
 * Handles records written before agent-trace 0.1.0 compliance:
 *   - version: 1 (number) → "1.0.0" (semver string)
 *   - contributor.type: "agent" → "ai"
 *   - contributor.model → contributor.model_id (omitted if "unknown")
 *
 * The trace ID (trace_xxx format) is intentionally left unchanged
 * to preserve the reference stored in the parent trajectory's _trace.traceId.
 *
 * @returns { record, migrated } — migrated=true means the caller should persist the updated record
 */
export function migrateTraceRecord(raw: unknown): {
  record: TraceRecord;
  migrated: boolean;
} {
  const data = raw as Record<string, unknown>;
  let migrated = false;

  // Migrate version: number → semver string
  if (typeof data.version === "number") {
    data.version = "1.0.0";
    migrated = true;
  }

  // Migrate contributor fields in each file's conversations
  if (Array.isArray(data.files)) {
    for (const file of data.files as Array<Record<string, unknown>>) {
      if (Array.isArray(file.conversations)) {
        for (const conv of file.conversations as Array<
          Record<string, unknown>
        >) {
          const contributor = conv.contributor as Record<string, unknown>;
          if (!contributor) continue;

          // Migrate type: "agent" → "ai"
          if (contributor.type === "agent") {
            contributor.type = "ai";
            migrated = true;
          }

          // Migrate model → model_id, drop if "unknown"
          if ("model" in contributor) {
            const modelValue = contributor.model;
            contributor.model = undefined;
            if (modelValue && modelValue !== "unknown") {
              contributor.model_id = modelValue;
            }
            migrated = true;
          }
        }
      }
    }
  }

  return { record: data as unknown as TraceRecord, migrated };
}

/**
 * Create a trace reference for embedding in a trajectory
 * @param startRef - Git ref when trace started
 * @param traceId - Optional ID of the generated trace record
 * @returns TrajectoryTraceRef object
 */
export function createTraceRef(
  startRef: string,
  traceId?: string,
): TrajectoryTraceRef {
  const endRef = getGitHead();

  return {
    startRef,
    endRef: endRef ?? undefined,
    traceId,
  };
}
