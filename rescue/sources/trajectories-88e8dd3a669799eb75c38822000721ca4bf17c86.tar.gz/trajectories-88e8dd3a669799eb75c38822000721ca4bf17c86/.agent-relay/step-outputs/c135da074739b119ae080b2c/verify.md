Spotlight integration files present
