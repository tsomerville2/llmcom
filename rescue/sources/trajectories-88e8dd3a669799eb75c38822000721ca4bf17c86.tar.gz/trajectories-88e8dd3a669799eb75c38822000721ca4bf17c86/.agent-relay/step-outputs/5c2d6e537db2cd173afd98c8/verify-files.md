All integration files present
